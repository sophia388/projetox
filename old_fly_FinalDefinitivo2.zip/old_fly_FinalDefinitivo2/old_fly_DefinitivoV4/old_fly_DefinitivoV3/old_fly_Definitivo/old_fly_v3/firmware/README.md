# Dispenser físico — ESP8266 e dois motores

A integração usa seu código de motores: `Stepper`, 2048 passos, 8 RPM, `yield()` a cada passo e bobinas desligadas depois do movimento. Cada horário válido autoriza **um ciclo do motor correspondente**, seguido da pausa de 3 segundos. O programa não fica girando os dois motores continuamente.

| Container do site | Motor | Ordem dos pinos no construtor Stepper |
| --- | --- | --- |
| 1 | Motor 1 | D1, D3, D2, D4 |
| 2 | Motor 2 | D5, D7, D6, D8 |

Este pacote atende **um ESP8266 por backend, vinculado a um idoso por vez**. O administrador pode trocar o idoso pela tela, sem regravar a placa. Os containers 3 a 8 existentes no sistema não possuem motor neste aparelho e são sinalizados na tela.

## Como funciona

1. Você cadastra os remédios e horários no site e escolhe o idoso dono do dispenser.
2. O ESP8266 consulta o backend pelo Wi-Fi aproximadamente a cada 2 segundos, quando está ocioso.
3. O backend consulta o horário de São Paulo, o vínculo, o estoque informado e o período do tratamento. Só oferece comandos do minuto atual e dos containers 1 e 2.
4. Antes do movimento, a placa grava o identificador na EEPROM e pede autorização para iniciar. O backend só concede essa autorização uma vez.
5. A placa faz o ciclo, desliga as bobinas, aguarda 3 segundos e envia o resultado. Se a confirmação se perder, repete apenas o envio do resultado.

Se dois remédios têm o mesmo horário, os motores trabalham em sequência. O navegador pode ficar fechado; **ESP8266, rede, computador, MySQL e backend precisam continuar ligados**. O som do alarme do site depende do navegador aberto.

Sem sensor de queda, o resultado comprova somente que o software terminou de enviar os passos. Não comprova deslocamento mecânico, saída de um comprimido ou ingestão. Por isso o estoque não é reduzido automaticamente e a dosagem escrita no cadastro não vira quantidade de voltas. Valide o mecanismo vazio antes de usar com comprimidos e confira manualmente o estoque após a retirada.

## 1. Preparar a rede e a configuração

Use a mesma rede local para computador e placa. O ESP8266 precisa alcançar a porta 8080 do computador. O endereço gravado na placa deve ser o IPv4 do computador, por exemplo `192.168.1.100`; `localhost` na placa não aponta para o computador.

No Windows, consulte `ipconfig` e copie o IPv4 da conexão usada. Se possível, reserve esse endereço no roteador para que ele não mude.

Abra um PowerShell na pasta `old_fly_24.08`, onde estão `backend`, `frontend` e `firmware`, e execute com seus dados:

```powershell
powershell -ExecutionPolicy Bypass -File .\firmware\configurar-dispenser.ps1 -Ssid "NOME_DO_WIFI" -IpComputador "192.168.1.100"
```

O script pede a senha sem exibi-la, gera um token aleatório e cria:

- `firmware/oldfly_dispenser/config.local.h`: Wi-Fi, endereço do backend, token e modo de simulação.
- `backend/AcessoBackEnd/dispenser.local.properties`: habilitação da integração e o mesmo token.

Esses arquivos são locais e contêm credenciais. Não os compartilhe. Executar o configurador novamente mantém o token existente e volta a placa para simulação. Nenhuma senha ou token precisa ser enviado pelo chat.

Alternativa manual: copie `config.example.h` para `config.local.h`, preencha os campos e crie o arquivo `dispenser.local.properties` com `oldfly.dispenser.habilitado=true` e `oldfly.dispenser.token=SEU_TOKEN_ALEATORIO`. O token precisa ter pelo menos 32 caracteres e ser exatamente igual nos dois arquivos.

O protótipo usa HTTP na rede local. Não exponha a porta 8080 à internet: o restante do CRUD do projeto não possui controle completo de acesso no servidor, e os cadastros determinam o acionamento físico. Use uma rede controlada durante os testes.

## 2. Gravar o ESP8266

Na Arduino IDE:

1. Nas preferências, adicione a URL de placas `https://arduino.esp8266.com/stable/package_esp8266com_index.json`.
2. No Gerenciador de Placas, instale **esp8266 by ESP8266 Community**, versão **3.1.2**, usada na validação.
3. Instale a biblioteca **Stepper by Arduino**, versão **1.1.3**, no Gerenciador de Bibliotecas. Wi-Fi, HTTP e EEPROM já acompanham o pacote ESP8266.
4. Abra `firmware/oldfly_dispenser/oldfly_dispenser.ino`.
5. Para uma NodeMCU com os pinos D1 a D8, selecione **NodeMCU 1.0 (ESP-12E Module)** e a porta USB correta. Se a sua placa for de outro modelo, selecione o modelo correspondente e confira o mapeamento D1–D8 antes de gravar.
6. Mantenha `MODO_SIMULACAO = true` em `config.local.h` e faça o upload.
7. Abra o Monitor Serial em **115200 baud**. O programa deve informar `Modo SIMULACAO`.

Os pinos foram preservados conforme seu circuito. D3, D4 e D8 participam da seleção de inicialização do ESP8266: se a placa não iniciar com os drivers conectados, confira os níveis desses pinos. Essa particularidade está descrita na [documentação oficial das placas ESP8266](https://arduino-esp8266.readthedocs.io/en/stable/boards.html). Use alimentação adequada para os motores e mantenha o terra comum com os drivers; a alimentação dos motores deve seguir o circuito do driver.

## 3. Iniciar o backend e selecionar o idoso

Pare a instância antiga do backend, se ela já estiver usando a porta 8080. Na pasta `old_fly_24.08`, execute:

```powershell
powershell -ExecutionPolicy Bypass -File .\firmware\iniciar-backend.ps1
```

Mantenha o terminal aberto. O script usa as configurações atuais do MySQL e inicia o backend com movimentos reais desabilitados. Não é necessário recriar o banco: o Hibernate cria as tabelas de comandos e vínculo.

Se preferir executar `AcessoBackEndApplication` pela IDE, defina o diretório de trabalho como `backend/AcessoBackEnd`, para que `dispenser.local.properties` seja carregado. Para habilitar movimentos reais pela IDE, use o argumento `--oldfly.dispenser.permitir-motores=true`; sem ele, o padrão é desabilitado.

Abra o `index.html` pelo Live Server. Use HTTP, não uma URL `file://`, pois a troca de vínculo utiliza um cookie de sessão. Entre novamente como administrador depois de reiniciar o backend.

Na Dashboard, no painel **Dispenser físico**:

1. Em **Este dispenser pertence a**, escolha o idoso.
2. Confira quais remédios estão nos containers 1 e 2 e marque a confirmação.
3. Clique em **Salvar vínculo**.

A seleção fica salva no banco. A troca entra em vigor no minuto seguinte, cancela comandos antigos ainda não iniciados e não exige alterar o firmware. A opção **Sem vínculo (pausado)** suspende novos comandos. A troca é bloqueada enquanto houver ciclo iniciado ou conferência pendente.

Para esse idoso, os novos remédios usam automaticamente os containers 1 e 2. Se ele já tiver remédios nos containers 3 a 8, esses cadastros permanecem no sistema, mas não movimentam este aparelho. Antes de carregar os containers físicos, confira os números exibidos no site.

## 4. Primeiro teste: simulação

Com a placa gravada em simulação e o backend iniciado pelo script sem opções:

1. Cadastre um remédio de teste para o idoso selecionado, com estoque maior que zero e horário dois ou três minutos à frente.
2. Confira que ele recebeu container 1 ou 2.
3. Aguarde o horário. O painel deve indicar **Conectado em simulação** e, depois, **Simulação concluída** no histórico. O Monitor Serial identifica o container; os motores ficam parados.
4. Cadastre o segundo remédio de teste para conferir o outro container.

O botão antigo **Testar alarme** continua sendo apenas uma simulação de som/tela. Ele não aciona o dispositivo físico.

## 5. Testar o movimento físico

Depois de conferir a simulação, teste o mecanismo vazio e acompanhado:

1. Em `config.local.h`, altere `MODO_SIMULACAO` para `false` e grave novamente a placa.
2. Pare o backend anterior e inicie:

```powershell
powershell -ExecutionPolicy Bypass -File .\firmware\iniciar-backend.ps1 -MotoresReais
```

3. Entre novamente no site e programe um **novo horário futuro**. Um horário já simulado não é reutilizado para movimento real no mesmo minuto.
4. No horário, o motor do container escolhido recebe 2048 passos a 8 RPM. O outro motor permanece parado. Depois aparece **Ciclo do motor concluído**.

Uma volta é o ciclo fornecido no seu código. A relação entre uma volta e a quantidade de comprimidos depende do mecanismo e precisa ser conferida fisicamente. Este software não implementa calibração automática nem sensor de posição.

## Falhas e recuperação

| Situação | Comportamento / ação |
| --- | --- |
| Placa ou servidor desconectado durante um horário | Horários anteriores não são liberados em lote quando a conexão volta. Um comando ainda dentro do minuto agendado pode ser autorizado. |
| Queda de energia ou resposta incerta durante o início | O ciclo não é repetido automaticamente. O painel solicita conferência. |
| Ciclo finalizado, mas confirmação não chegou | A placa tenta reenviar apenas o resultado, sem girar o motor novamente. |
| Conferência necessária | Confira mecanismo, posição e eventual comprimido retirado. No Monitor Serial, com final de linha **Nova linha**, envie `CONFERIDO`. Isso libera os próximos horários, sem repetir o anterior. |
| Usuário removido ou vínculo alterado enquanto a placa tinha um resultado pendente | O resultado antigo é bloqueado. Faça a conferência local pelo Serial antes de continuar com o novo vínculo. |
| Memória inválida | Os motores ficam bloqueados. Não apague a EEPROM para contornar uma pendência sem conferir primeiro o mecanismo e o estado do servidor. |
| HTTP 401 no Serial | O token da placa está diferente do token do backend. Confira os dois arquivos locais. |
| HTTP 503 no Serial | Integração desabilitada ou token ausente/curto no backend. Confira o diretório de trabalho e a configuração local. |
| Não conecta / HTTP negativo | Confira Wi-Fi, IP, alimentação, porta 8080 e regra do firewall para a rede privada. |
| Site pede novo login ao salvar vínculo | A sessão do administrador expirou ou o backend reiniciou. Saia e entre novamente. |
| Nenhum comando no horário | Confira idoso selecionado, container 1/2, estoque, relógio do computador, período do tratamento, modo real/simulação e histórico daquele minuto. |

Para conferir a rede, abra no celular conectado ao mesmo Wi-Fi `http://IP_DO_COMPUTADOR:8080/api/dispenser/status`. Essa consulta mostra somente o estado; não movimenta motores. Autorize o Java no firewall apenas para a rede privada usada pelo dispenser.

## Validação e limites

O firmware foi compilado para `esp8266:esp8266:nodemcuv2`, com ESP8266 core 3.1.2 e Stepper 1.1.3. Os testes do backend usam banco H2 isolado e simulam comandos, concorrência, reinício do serviço, troca de idoso, falhas e confirmação duplicada. A validação física depende da sua placa conectada, da alimentação e do mecanismo montado.

O protocolo utiliza os recursos do [cliente HTTP oficial do ESP8266](https://github.com/esp8266/Arduino/blob/3.1.2/libraries/ESP8266HTTPClient/examples/BasicHttpClient/BasicHttpClient.ino), da [EEPROM do ESP8266](https://arduino-esp8266.readthedocs.io/en/stable/libraries.html#eeprom) e da [biblioteca Stepper](https://docs.arduino.cc/libraries/stepper/).
