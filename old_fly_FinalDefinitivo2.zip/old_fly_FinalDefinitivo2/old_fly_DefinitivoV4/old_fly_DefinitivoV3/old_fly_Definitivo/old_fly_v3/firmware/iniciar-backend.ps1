param([switch] $MotoresReais)
$ErrorActionPreference = 'Stop'
$pastaBackend = Join-Path (Split-Path -Parent $PSScriptRoot) 'backend/AcessoBackEnd'
if (-not (Test-Path -LiteralPath (Join-Path $pastaBackend 'dispenser.local.properties'))) {
    throw 'Execute configurar-dispenser.ps1 primeiro, ou crie dispenser.local.properties conforme o guia.'
}
Push-Location -LiteralPath $pastaBackend
try {
    if ($MotoresReais) {
        Write-Host 'Modo REAL habilitado no backend. A placa tambem deve estar com MODO_SIMULACAO=false.'
        & .\mvnw.cmd spring-boot:run '-Dspring-boot.run.arguments=--oldfly.dispenser.permitir-motores=true'
    } else {
        Write-Host 'Modo de simulacao: o backend nao autoriza movimentos reais.'
        & .\mvnw.cmd spring-boot:run '-Dspring-boot.run.arguments=--oldfly.dispenser.permitir-motores=false'
    }
    if ($LASTEXITCODE -ne 0) { throw "O backend encerrou com codigo $LASTEXITCODE." }
} finally { Pop-Location }
