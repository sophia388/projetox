
#include <Stepper.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <EEPROM.h>
#include <stddef.h>

#if __has_include("config.local.h")
#include "config.local.h"
#else
#include "config.example.h"
#endif

const int passosPorVolta = 2048;
Stepper motor1(passosPorVolta, D1, D3, D2, D4);
Stepper motor2(passosPorVolta, D5, D7, D6, D0);

enum EstadoLocal : uint8_t { VAZIO = 0, INCERTO = 1, CONCLUIDO = 2, SIMULADO = 3 };

struct Registro {
  uint32_t magic;
  uint32_t versao;
  char comandoId[37];
  uint8_t estado;
  uint32_t checksum;
};

struct Comando {
  String id;
  int motor;
  int passos;
  bool simulacao;
  String estado;
};

const uint32_t MAGIC = 0x4F4C4446;
Registro registro = {};
bool memoriaOk = false;
bool configuracaoOk = false;
unsigned long ultimaConsulta = 0;
unsigned long ultimaReconexao = 0;
String entradaSerial;

void girarComSeguranca(Stepper &motor, int totalDePassos) {
  for (int i = 0; i < totalDePassos; i++) {
    motor.step(1);
    yield();
  }
}

void desligarBobinas() {
  digitalWrite(D1, LOW); digitalWrite(D2, LOW);
  digitalWrite(D3, LOW); digitalWrite(D4, LOW);
  digitalWrite(D5, LOW); digitalWrite(D6, LOW);
  digitalWrite(D7, LOW); digitalWrite(D0, LOW);
}

bool idValido(const String &id) {
  if (id.length() != 36) return false;
  for (unsigned int i = 0; i < id.length(); i++) {
    if (i == 8 || i == 13 || i == 18 || i == 23) {
      if (id[i] != '-') return false;
    } else if (!isxdigit(static_cast<unsigned char>(id[i]))) return false;
  }
  return true;
}

uint32_t checksumRegistro(const Registro &valor) {
  const uint8_t *bytes = reinterpret_cast<const uint8_t *>(&valor);
  uint32_t hash = 2166136261UL;
  for (size_t i = 0; i < offsetof(Registro, checksum); i++) hash = (hash ^ bytes[i]) * 16777619UL;
  return hash;
}

bool salvarRegistro(const String &id, uint8_t estado) {
  Registro novo;
  memset(&novo, 0, sizeof(novo));
  novo.magic = MAGIC;
  novo.versao = 1;
  id.toCharArray(novo.comandoId, sizeof(novo.comandoId));
  novo.estado = estado;
  novo.checksum = checksumRegistro(novo);
  EEPROM.put(0, novo);
  if (!EEPROM.commit()) {
    memoriaOk = false;
    desligarBobinas();
    Serial.println("Falha ao persistir estado. Motores bloqueados; confira a memoria antes de continuar.");
    return false;
  }
  registro = novo;
  return true;
}

bool carregarRegistro() {
  EEPROM.begin(128);
  bool virgem = true;
  for (size_t i = 0; i < sizeof(Registro); i++) if (EEPROM.read(i) != 0xFF) virgem = false;
  if (virgem) return salvarRegistro("", VAZIO);
  EEPROM.get(0, registro);
  if (registro.magic != MAGIC || registro.versao != 1 || registro.estado > SIMULADO
      || registro.checksum != checksumRegistro(registro) || registro.comandoId[36] != '\0') {
    Serial.println("EEPROM nao inicializada para o Old Fly. Formatando registro inicial...");
    return salvarRegistro("", VAZIO);
  }
  return registro.estado == VAZIO || idValido(String(registro.comandoId));
}

int requisicao(const String &rota, String &resposta) {
  resposta = "";
  if (WiFi.status() != WL_CONNECTED) return -1;
  WiFiClient client;
  HTTPClient http;
  http.setTimeout(5000);
  http.setReuse(false);
  if (!http.begin(client, String(BACKEND_URL) + rota)) return -1;
  http.addHeader("Authorization", String("Bearer ") + DISPENSER_TOKEN);
  int status = http.POST("");
  if (status > 0) {
    // O protocolo de comandos cabe em menos de 100 bytes. Nunca executar HTML/erro como comando.
    if (http.getSize() > 512) status = -2;
    else resposta = http.getString();
  }
  http.end();
  return status;
}

bool lerComando(const String &texto, Comando &comando) {
  if (texto.length() > 100) return false;
  int separadores[4];
  int anterior = -1;
  for (int i = 0; i < 4; i++) {
    separadores[i] = texto.indexOf(';', anterior + 1);
    if (separadores[i] < 0) return false;
    anterior = separadores[i];
  }
  comando.id = texto.substring(0, separadores[0]);
  String motor = texto.substring(separadores[0] + 1, separadores[1]);
  String passos = texto.substring(separadores[1] + 1, separadores[2]);
  String simulacao = texto.substring(separadores[2] + 1, separadores[3]);
  comando.estado = texto.substring(separadores[3] + 1);
  if (!idValido(comando.id) || (motor != "1" && motor != "2") || passos != "2048"
      || (simulacao != "0" && simulacao != "1")) return false;
  comando.motor = motor.toInt();
  comando.passos = 2048;
  comando.simulacao = simulacao == "1";
  return comando.estado == "OFERECIDO" || comando.estado == "INICIADO" || comando.estado == "INCERTO";
}

void enviarResultado() {
  if (registro.estado == VAZIO) return;
  String estado = registro.estado == CONCLUIDO ? "CONCLUIDO" : registro.estado == SIMULADO ? "SIMULADO" : "INCERTO";
  String resposta;
  int status = requisicao(String("/api/dispenser/comandos/") + registro.comandoId + "/resultado?estado=" + estado, resposta);
  if (status == 204 && registro.estado != INCERTO) {
    if (salvarRegistro("", VAZIO)) Serial.println("Resultado registrado. Aguardando o proximo horario.");
  } else if (status == 404 && registro.estado != INCERTO) {
    salvarRegistro(String(registro.comandoId), INCERTO);
    Serial.println("Comando removido ou vinculo alterado. Confira o dispenser antes de continuar.");
  } else if (registro.estado == INCERTO) {
    Serial.println("Execucao incerta: confira o mecanismo e o comprimido. Depois digite CONFERIDO no Serial.");
  } else if (status != 204) {
    Serial.printf("Confirmacao pendente (HTTP %d). O motor NAO sera repetido.\n", status);
  }
}

void confirmarConferencia() {
  if (!memoriaOk || !configuracaoOk || registro.estado != INCERTO) {
    Serial.println("Nao ha execucao incerta para conferir, ou a configuracao/memoria esta invalida.");
    return;
  }
  String resposta;
  int status = requisicao(String("/api/dispenser/comandos/") + registro.comandoId + "/resultado?estado=INCERTO", resposta);
  if (status == 204) status = requisicao(String("/api/dispenser/comandos/") + registro.comandoId + "/conferido", resposta);
  // 404: cadastro foi excluido ou o aparelho foi transferido; a conferencia local explicita permite liberar.
  if ((status == 204 || status == 404) && salvarRegistro("", VAZIO)) Serial.println("Conferencia registrada. Nenhuma dose antiga sera repetida.");
  else Serial.printf("Nao foi possivel registrar a conferencia (HTTP %d). Continua bloqueado.\n", status);
}

void consultarComando() {
  String resposta;
  int status = requisicao(String("/api/dispenser/proximo?simulacao=") + (MODO_SIMULACAO ? "true" : "false"), resposta);
  static unsigned long ultimoAviso = 0;
  if (status == 204) {
    if (millis() - ultimoAviso >= 15000) {
      ultimoAviso = millis();
      Serial.println("[OK] Comunicando com o Backend Spring Boot. Aguardando horario cadastrado...");
    }
    return;
  }
  if (status != 200) {
    Serial.printf("[AVISO] Consulta indisponivel (HTTP %d). Motores parados.\n", status);
    return;
  }
  Comando comando;
  if (!lerComando(resposta, comando)) {
    Serial.println("Resposta invalida. Nenhum motor acionado.");
    return;
  }
  // Uma reinicializacao nunca retoma um ciclo que ja recebeu autorizacao.
  if (comando.estado != "OFERECIDO") {
    if (salvarRegistro(comando.id, INCERTO)) enviarResultado();
    return;
  }
  if (comando.simulacao != MODO_SIMULACAO) return;

  // Grava ANTES de pedir autorizacao. Em caso de queda de energia, exige conferencia.
  if (!salvarRegistro(comando.id, INCERTO)) return;
  status = requisicao("/api/dispenser/comandos/" + comando.id + "/iniciar", resposta);
  Comando autorizado;
  if (status != 200 || !lerComando(resposta, autorizado) || autorizado.estado != "INICIADO"
      || autorizado.id != comando.id || autorizado.motor != comando.motor || autorizado.simulacao != MODO_SIMULACAO) {
    Serial.println("Autorizacao nao confirmada. Nenhum movimento; confira a pendencia pelo Serial.");
    return;
  }

  if (MODO_SIMULACAO) {
    Serial.printf("SIMULACAO: container %d, 2048 passos. Motores desligados.\n", comando.motor);
    if (salvarRegistro(comando.id, SIMULADO)) enviarResultado();
    return;
  }

  Serial.printf("\n[ >>> COMANDO RECEBIDO: GIRAR MOTOR %d <<< ]\n", comando.motor);
  Serial.printf("Iniciando Motor %d (1 volta = 2048 passos)...\n", comando.motor);

  // CORRECAO: MOTORES 1 E 2 INVERTIDOS
  if (comando.motor == 1)
    girarComSeguranca(motor2, passosPorVolta);
  else
    girarComSeguranca(motor1, passosPorVolta);

  desligarBobinas();
  delay(3000);
  Serial.println("Ciclo do motor concluido com sucesso.");
  if (salvarRegistro(comando.id, CONCLUIDO)) enviarResultado();
}

// Recuperacao opcional, apenas quando EEPROM invalida.
// Nao libera os motores: exige reinicio e conferência do backend.
bool recuperacaoEEPROMSolicitada = false;

void diagnosticoMemoria() {
  Serial.printf("EEPROM: magic=0x%08lX, versao=%lu, estado=%u\n",
                (unsigned long)registro.magic,
                (unsigned long)registro.versao,
                (unsigned int)registro.estado);
  Serial.printf("RAM livre: %lu bytes. Registro EEPROM: %u bytes (area reservada: 128 bytes).\n",
                (unsigned long)ESP.getFreeHeap(),
                (unsigned int)sizeof(Registro));
  Serial.println("A EEPROM guarda somente UM registro, nao um historico crescente.");
  Serial.println("Memoria invalida NAO significa memoria cheia.");
  if (!memoriaOk) {
    Serial.println("EEPROM invalida: nao apagar antes de criar backup e conferir as doses.");
  } else if (registro.estado == INCERTO) {
    Serial.println("Dose INCERTA: conferir o mecanismo e usar o fluxo CONFERIDO.");
  }
}

void tratarRecuperacaoEEPROM(const String &comandoSerial) {
  if (comandoSerial == "DIAGNOSTICO_MEMORIA") {
    diagnosticoMemoria();
    return;
  }

  if (comandoSerial == "SOLICITAR_RECUPERACAO_EEPROM") {
    if (memoriaOk) {
      Serial.println("EEPROM valida. Nao ha recuperacao a realizar.");
      return;
    }
    recuperacaoEEPROMSolicitada = true;
    Serial.println("ATENCAO: esta operacao substitui o registro local antigo.");
    Serial.println("So continue APOS backup da flash, conferencia fisica das doses");
    Serial.println("e verificacao dos comandos pendentes no backend.");
    Serial.println("Se tudo foi conferido, digite: CONFIRMAR_LIMPEZA_EEPROM");
    Serial.println("Para cancelar, digite: CANCELAR_RECUPERACAO_EEPROM");
    return;
  }

  if (comandoSerial == "CANCELAR_RECUPERACAO_EEPROM") {
    recuperacaoEEPROMSolicitada = false;
    Serial.println("Recuperacao cancelada: nenhuma gravacao efetuada.");
    return;
  }

  if (comandoSerial == "CONFIRMAR_LIMPEZA_EEPROM") {
    if (memoriaOk || !recuperacaoEEPROMSolicitada) {
      Serial.println("Recuperacao nao autorizada. Nenhuma alteracao feita.");
      return;
    }
    recuperacaoEEPROMSolicitada = false;
    if (salvarRegistro("", VAZIO)) {
      // Permanecer bloqueado ate reinicio intencional.
      memoriaOk = false;
      desligarBobinas();
      Serial.println("Novo registro vazio gravado. Registro anterior foi substituido.");
      Serial.println("Motores continuam BLOQUEADOS nesta sessao.");
      Serial.println("Depois de conferir o backend e as doses, reinicie manualmente.");
    } else {
      Serial.println("Falha na gravacao. Motores permanecem bloqueados.");
    }
  }
}

void setup() {
  desligarBobinas();
  motor1.setSpeed(8);
  motor2.setSpeed(8);
  Serial.begin(115200);
  delay(500);
  Serial.println("\n=========================================");
  Serial.println("Old Fly - Dispenser Duplo");
  Serial.printf("Modo: %s\n", MODO_SIMULACAO ? "SIMULACAO" : "REAL (Motores Ativos)");
  memoriaOk = carregarRegistro();
  configuracaoOk = strlen(DISPENSER_TOKEN) >= 32 && String(WIFI_SSID) != "PREENCHA_SUA_REDE"
      && String(BACKEND_URL).startsWith("http://") && !String(BACKEND_URL).endsWith("/");
  if (!configuracaoOk) {
    Serial.println("[ERRO] Preencha config.local.h com Wi-Fi, IP e token antes de conectar.");
  }

  WiFi.persistent(false);
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  if (configuracaoOk) {
    Serial.printf("Conectando ao Wi-Fi '%s'...\n", WIFI_SSID);
    WiFi.begin(WIFI_SSID, WIFI_SENHA);
    int espera = 0;
    while (WiFi.status() != WL_CONNECTED && espera < 30) {
      delay(500);
      Serial.print(".");
      espera++;
    }
    if (WiFi.status() == WL_CONNECTED) {
      Serial.println("\n[OK] Wi-Fi Conectado com Sucesso!");
      Serial.print("IP do ESP8266: ");
      Serial.println(WiFi.localIP());
      Serial.print("Backend Spring Boot: ");
      Serial.println(BACKEND_URL);
      Serial.println("Aguardando comandos...");
      Serial.println("=========================================\n");
    } else {
      Serial.println("\n[AVISO] Conexao Wi-Fi em segundo plano...");
    }
  }
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') {
      entradaSerial.trim();
      if (entradaSerial == "CONFERIDO") confirmarConferencia();
      else tratarRecuperacaoEEPROM(entradaSerial);
      entradaSerial = "";
    } else if (entradaSerial.length() < 48) entradaSerial += c;
  }
  if (!memoriaOk || !configuracaoOk) { delay(50); return; }
  if (WiFi.status() != WL_CONNECTED) {
    static unsigned long ultimoAvisoWifi = 0;
    if (millis() - ultimoAvisoWifi >= 10000) {
      ultimoAvisoWifi = millis();
      Serial.println("[AVISO] Aguardando reconexao com a rede Wi-Fi...");
    }
    if (millis() - ultimaReconexao >= 10000) {
      ultimaReconexao = millis();
      WiFi.reconnect();
    }
    delay(20);
    return;
  }
  if (millis() - ultimaConsulta >= 2000) {
    ultimaConsulta = millis();
    if (registro.estado != VAZIO) enviarResultado();
    else consultarComando();
  }
  delay(10);
}
