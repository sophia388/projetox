#pragma once

const char* WIFI_SSID = "Internet Rafaella Linda";
const char* WIFI_SENHA = "qualquer4coisa";
const char* BACKEND_URL = "http://10.172.235.112:8080";
const char* DISPENSER_TOKEN = "f0f8bbd098556c29d6efb1732ef9a4ad5d935d04507e00c3fc074aca3f425f25";
const bool MODO_SIMULACAO = false;
