param(
    [Parameter(Mandatory = $true)] [string] $Ssid,
    [Parameter(Mandatory = $true)] [string] $IpComputador
)

$ErrorActionPreference = 'Stop'
$endereco = $null
if (-not [System.Net.IPAddress]::TryParse($IpComputador, [ref] $endereco) -or
    $endereco.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork -or
    [System.Net.IPAddress]::IsLoopback($endereco)) {
    throw 'Informe o IPv4 do computador na rede local, por exemplo 192.168.1.100.'
}
if ([Text.Encoding]::UTF8.GetByteCount($Ssid) -lt 1 -or [Text.Encoding]::UTF8.GetByteCount($Ssid) -gt 32) {
    throw 'O nome da rede deve ter entre 1 e 32 bytes.'
}

$pastaProjeto = Split-Path -Parent $PSScriptRoot
$arquivoBackend = Join-Path $pastaProjeto 'backend/AcessoBackEnd/dispenser.local.properties'
$arquivoPlaca = Join-Path $PSScriptRoot 'oldfly_dispenser/config.local.h'
$tokenDispenser = $null
if (Test-Path -LiteralPath $arquivoBackend) {
    $linhaToken = Get-Content -LiteralPath $arquivoBackend | Where-Object { $_ -match '^oldfly\.dispenser\.token=([a-f0-9]{64})$' } | Select-Object -First 1
    if ($linhaToken) { $tokenDispenser = $linhaToken.Split('=', 2)[1] }
}
if (-not $tokenDispenser) {
    $bytesToken = New-Object byte[] 32
    $geradorToken = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $geradorToken.GetBytes($bytesToken) } finally { $geradorToken.Dispose() }
    $tokenDispenser = ([BitConverter]::ToString($bytesToken)).Replace('-', '').ToLowerInvariant()
}

function Converter-CppString([string] $valor) {
    if ($valor.Contains("`n") -or $valor.Contains("`r")) { throw 'O valor nao pode conter quebras de linha.' }
    return $valor.Replace('\', '\\').Replace('"', '\"')
}

$senhaSegura = Read-Host 'Senha do Wi-Fi (nao sera exibida)' -AsSecureString
$ponteiroSenha = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($senhaSegura)
try {
    $senhaWifi = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ponteiroSenha)
    $ssidCpp = Converter-CppString $Ssid
    $senhaCpp = Converter-CppString $senhaWifi
    $linhasPlaca = @(
        '#pragma once',
        ('const char* WIFI_SSID = "' + $ssidCpp + '";'),
        ('const char* WIFI_SENHA = "' + $senhaCpp + '";'),
        ('const char* BACKEND_URL = "http://' + $IpComputador + ':8080";'),
        ('const char* DISPENSER_TOKEN = "' + $tokenDispenser + '";'),
        'const bool MODO_SIMULACAO = true;'
    )
    $utf8 = New-Object Text.UTF8Encoding $false
    [IO.File]::WriteAllLines($arquivoPlaca, $linhasPlaca, $utf8)
    [IO.File]::WriteAllLines($arquivoBackend, @(
        '# Configuracao local. Nao compartilhe este arquivo.',
        'oldfly.dispenser.habilitado=true',
        ('oldfly.dispenser.token=' + $tokenDispenser)
    ), $utf8)
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ponteiroSenha)
    $senhaWifi = $null
    $senhaCpp = $null
}

Write-Host 'Configuracao criada para simulacao. Senha e token foram salvos somente nos arquivos locais.'
Write-Host 'Grave oldfly_dispenser/oldfly_dispenser.ino no ESP8266 e execute firmware/iniciar-backend.ps1.'
Write-Host 'Escolha o idoso no painel Dispenser fisico do site, entrando novamente como administrador.'
