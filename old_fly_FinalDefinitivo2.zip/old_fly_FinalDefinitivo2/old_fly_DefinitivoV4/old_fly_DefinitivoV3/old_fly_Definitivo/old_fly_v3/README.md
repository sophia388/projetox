# Old Fly - Dispenser Inteligente

Projeto integrado com frontend HTML/CSS/JS, backend Spring Boot e banco MySQL.

A integração com ESP8266 e os dois motores está em [`firmware/README.md`](firmware/README.md), com configuração do Wi-Fi, gravação da placa, seleção do idoso pela tela e teste em simulação antes de habilitar os motores.

## O que esta versão possui

- Login conectado ao backend.
- Cadastro inicial com botão de olho para visualizar senha.
- CRUD completo de usuários no backend.
- Exclusão transacional: remove sessões e dispositivos de cuidadores; ao excluir um idoso, remove também seus remédios, estoques, receitas e dispositivos. Contas de outras pessoas são preservadas e desvinculadas.
- Container de 1 a 8 escolhido automaticamente ao cadastrar remédios, com manutenção do número na edição e reutilização de posições liberadas.
- Dispenser físico duplo: motor 1 no container 1 e motor 2 no container 2; o idoso vinculado pode ser escolhido e trocado pelo administrador.
- Comandos persistidos, confirmação de ciclo, modo de simulação e bloqueio de repetição após uma execução incerta.
- Tela de usuários para admin com cadastrar, editar, excluir e filtrar por perfil.
- Senhas ocultas na listagem de usuários.
- Entidade `Medicamento` com CRUD completo.
- Dashboard carregando remédios reais do banco.
- Seletor visual de horários com inclusão manual, remoção e geração automática por intervalo.
- Painel na Dashboard com relógio ao vivo, contagem regressiva e os dois próximos alarmes.
- Teste automático de 1 minuto com confirmação de remédio tomado; depois da confirmação, a agenda real volta ao painel.
- Simulação visual, vibratória e sonora com `Homecoming.mp3` no horário programado enquanto o sistema está aberto.
- Entidade `Receita` com cadastro, listagem e exclusão.
- Entidade `Estoque` integrada ao medicamento.
- Página de estoque atualizando quantidade e horários no banco.
- Mensagens visuais no lugar de `alert()` e confirmação personalizada no lugar de ações diretas.
- Melhorias de acessibilidade visual: botões maiores, contraste e responsividade.

## Como rodar

### 1. Banco

Abra o MySQL Workbench e execute:

```sql
CREATE DATABASE IF NOT EXISTS sistema_usuarios;
USE sistema_usuarios;
```

O Spring Boot cria as tabelas automaticamente por causa de:

```properties
spring.jpa.hibernate.ddl-auto=update
```

### 2. Backend

Abra a pasta:

```text
backend/AcessoBackEnd
```

Rode a classe:

```text
AcessoBackEndApplication
```

O backend deve subir em:

```text
http://localhost:8080
```

Se sua senha do MySQL for diferente, altere em:

```text
backend/AcessoBackEnd/src/main/resources/application.properties
```

### 3. Frontend

Abra o projeto no VS Code e rode o Live Server no arquivo:

```text
index.html
```

Ou diretamente em:

```text
frontend/old-fly-com-acessos/index.html
```

### Testes

Para validar a normalização e a geração de horários:

```text
cd frontend/old-fly-com-acessos
node tests/schedule.test.js
node tests/alarm.test.js
node tests/validation.test.js
node --test tests/api.test.js
node --test tests/dispenser.test.js
```

Os testes do backend usam H2 em memória, sem depender do MySQL da aplicação:

```text
cd backend/AcessoBackEnd
.\mvnw.cmd test
```

Após alterar o código Java, reinicie `AcessoBackEndApplication` e atualize a página com Ctrl+F5.
O limite geral é de oito containers por idoso. Para o idoso vinculado ao dispenser físico habilitado, novos cadastros usam somente os containers 1 e 2. Medicamentos sem vínculo usam um grupo separado.
Os dados de demonstração só são inseridos quando a base está vazia. Para desativá-los, configure `oldfly.dados-iniciais.enabled=false`.

O alarme roda globalmente enquanto o Old Fly estiver aberto no navegador, inclusive ao navegar entre Dashboard, Receitas, Sobre, cadastro e estoque. O histórico e a última verificação ficam persistidos para sobreviver a F5 e pequenas interrupções de navegação. O botão **Testar alarme** permite conferir som, vibração e modal sem aguardar o próximo horário.

## Acessos iniciais

```text
Admin: admin.oldfly / admin123
Cuidador: cuidador.ana / cuidado123
Idoso: idoso.joao / joao123
```

## Principais rotas do backend

### Login e usuários

```text
POST   /auth/login
GET    /auth/usuarios
POST   /admin
GET    /admin
GET    /admin/{id}
PUT    /admin/{id}
DELETE /admin/{id}
POST   /cuidador
GET    /cuidador
GET    /cuidador/{id}
PUT    /cuidador/{id}
DELETE /cuidador/{id}
POST   /idoso
GET    /idoso
GET    /idoso/{id}
PUT    /idoso/{id}
DELETE /idoso/{id}
```

### Medicamentos e estoque

```text
POST   /medicamentos
GET    /medicamentos
GET    /medicamentos/{id}
PUT    /medicamentos/{id}
DELETE /medicamentos/{id}
GET    /estoque/medicamento/{medicamentoId}
PUT    /estoque/medicamento/{medicamentoId}
```

### Receitas

```text
POST   /receitas
GET    /receitas
GET    /receitas/{id}
PUT    /receitas/{id}
DELETE /receitas/{id}
```
