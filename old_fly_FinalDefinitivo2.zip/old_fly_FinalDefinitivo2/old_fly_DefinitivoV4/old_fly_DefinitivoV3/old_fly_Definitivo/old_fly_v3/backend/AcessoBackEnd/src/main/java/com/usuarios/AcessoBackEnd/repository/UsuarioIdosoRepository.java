package com.usuarios.AcessoBackEnd.repository;

import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;

import java.util.List;
import java.util.Optional;

public interface UsuarioIdosoRepository extends JpaRepository<UsuarioIdoso, Integer> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select i from UsuarioIdoso i where i.id = :id")
    Optional<UsuarioIdoso> findByIdForUpdate(@Param("id") int id);
    Optional<UsuarioIdoso> findByUsuario(String usuario);
    Optional<UsuarioIdoso> findByEmail(String email);
    Optional<UsuarioIdoso> findByUsuarioAndSenha(String usuario, String senha);
    List<UsuarioIdoso> findByAdminId(int adminId);
}
