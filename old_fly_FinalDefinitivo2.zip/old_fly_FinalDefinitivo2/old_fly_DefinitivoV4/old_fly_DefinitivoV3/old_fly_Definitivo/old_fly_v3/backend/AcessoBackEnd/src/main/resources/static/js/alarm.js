(function (global) {
    'use strict';

    const INTERVALO_BUSCA_MS = 60 * 1000;
    const INTERVALO_VERIFICACAO_MS = 1000;
    const PREFIXO_HISTORICO = 'oldfly_alarm:';
    const PREFIXO_ULTIMA_VERIFICACAO = 'oldfly_alarm_last_check:';
    const JANELA_RECUPERACAO_MS = 15 * 60 * 1000;
    const PADRAO_DATA_ISO = /^\d{4}-\d{2}-\d{2}$/;
    const URL_AUDIO_ALARME = (() => {
        try {
            const documento = global && global.document;
            const scriptAtual = documento && documento.currentScript;
            const base = scriptAtual && scriptAtual.src
                ? scriptAtual.src
                : global.location && global.location.href;
            return new URL('../assents/Homecoming.mp3', base).href;
        } catch (erro) {
            return '../assents/Homecoming.mp3';
        }
    })();

    let medicamentos = [];
    let emExecucao = false;
    let timerBusca = null;
    let timerVerificacao = null;
    let cicloExecucao = 0;
    let promessaInicial = null;
    let dataUltimaLimpeza = '';
    let audioAlarme = null;
    let alarmeAtivo = false;
    let preparacaoAudioInstalada = false;
    let escapeDocumentoInstalado = false;
    let referenciasModal = null;
    let focoAnterior = null;
    let testeAgendado = null;
    let testeConcluido = false;
    let modalEhTesteAgendado = false;
    const historicoMemoria = new Set();

    function obterDocumento() {
        return global && global.document ? global.document : null;
    }

    function obterStorageSessao() {
        try {
            const storage = global && (global.localStorage || global.sessionStorage);
            if (!storage || typeof storage.getItem !== 'function') return null;
            return storage;
        } catch (erro) {
            return null;
        }
    }

    function obterSchedule() {
        const schedule = global && global.OldFlySchedule;
        return schedule && typeof schedule === 'object' ? schedule : null;
    }

    function paraData(valor) {
        if (typeof valor === 'undefined' || valor === null) return new Date();

        try {
            const data = valor instanceof Date ? new Date(valor.getTime()) : new Date(valor);
            return Number.isNaN(data.getTime()) ? null : data;
        } catch (erro) {
            return null;
        }
    }

    function doisDigitos(valor) {
        return String(valor).padStart(2, '0');
    }

    function horaLocal(data) {
        return `${doisDigitos(data.getHours())}:${doisDigitos(data.getMinutes())}`;
    }

    function dataLocalISOInterna(data) {
        return `${data.getFullYear()}-${doisDigitos(data.getMonth() + 1)}-${doisDigitos(data.getDate())}`;
    }

    function obterHoraNormalizada(data, obrigarHelper) {
        const schedule = obterSchedule();

        if (schedule && typeof schedule.horaAtual === 'function' && typeof schedule.normalizarHorario === 'function') {
            try {
                return schedule.normalizarHorario(schedule.horaAtual(data));
            } catch (erro) {
                return obrigarHelper ? '' : horaLocal(data);
            }
        }

        return obrigarHelper ? '' : horaLocal(data);
    }

    function obterDataLocalISO(data) {
        const schedule = obterSchedule();

        if (schedule && typeof schedule.dataLocalISO === 'function') {
            try {
                const valor = schedule.dataLocalISO(data);
                if (PADRAO_DATA_ISO.test(valor)) return valor;
            } catch (erro) {
                // A data local interna mantém o alarme funcional se o helper falhar.
            }
        }

        return dataLocalISOInterna(data);
    }

    function mesmoId(primeiro, segundo) {
        if (primeiro === null || typeof primeiro === 'undefined') return false;
        if (segundo === null || typeof segundo === 'undefined') return false;
        return String(primeiro) === String(segundo);
    }

    function obterUsuarioAtual() {
        if (!global || typeof global.getViewingUser !== 'function') return null;

        try {
            const usuario = global.getViewingUser();
            return usuario && typeof usuario === 'object' ? usuario : null;
        } catch (erro) {
            return null;
        }
    }

    function filtrarMedicamentosDoUsuario(lista) {
        const usuario = obterUsuarioAtual();
        if (!usuario) return [];

        const perfil = String(usuario.perfil || '').trim().toLowerCase();
        const validos = lista.filter(item => item && typeof item === 'object');

        if (perfil === 'admin') return validos;
        if (perfil === 'idoso') {
            return validos.filter(item => mesmoId(item.idosoId, usuario.id));
        }
        if (perfil === 'cuidador') {
            return validos.filter(item => mesmoId(item.idosoId, usuario.idosoId));
        }

        return [];
    }

    function identificadorMedicamento(medicamento, indice) {
        if (medicamento && medicamento.id !== null && typeof medicamento.id !== 'undefined') {
            return String(medicamento.id);
        }

        const nome = medicamento && medicamento.nome ? String(medicamento.nome) : 'medicamento';
        return `sem-id-${indice}-${nome}`;
    }

    function criarChaveHistorico(dataISO, medicamento, horario, indice) {
        const id = encodeURIComponent(identificadorMedicamento(medicamento, indice));
        return `${PREFIXO_HISTORICO}${dataISO}:${id}:${horario}`;
    }

    function dataDaChaveHistorico(chave) {
        if (typeof chave !== 'string' || !chave.startsWith(PREFIXO_HISTORICO)) return '';
        const dataISO = chave.slice(PREFIXO_HISTORICO.length, PREFIXO_HISTORICO.length + 10);
        return PADRAO_DATA_ISO.test(dataISO) ? dataISO : '';
    }

    function limparHistoricoAntigo(dataReferencia) {
        if (!PADRAO_DATA_ISO.test(dataReferencia) || dataUltimaLimpeza === dataReferencia) return;
        dataUltimaLimpeza = dataReferencia;

        Array.from(historicoMemoria).forEach(chave => {
            const dataChave = dataDaChaveHistorico(chave);
            if (!dataChave || dataChave < dataReferencia) historicoMemoria.delete(chave);
        });

        const storage = obterStorageSessao();
        if (!storage || typeof storage.key !== 'function' || typeof storage.removeItem !== 'function') return;

        try {
            for (let indice = storage.length - 1; indice >= 0; indice -= 1) {
                const chave = storage.key(indice);
                if (typeof chave !== 'string' || !chave.startsWith(PREFIXO_HISTORICO)) continue;

                const dataChave = dataDaChaveHistorico(chave);
                if (!dataChave || dataChave < dataReferencia) storage.removeItem(chave);
            }
        } catch (erro) {
            // O armazenamento pode ser bloqueado por privacidade ou política do navegador.
        }
    }

    function jaFoiDisparado(chave) {
        if (historicoMemoria.has(chave)) return true;

        const storage = obterStorageSessao();
        if (!storage) return false;

        try {
            const valor = storage.getItem(chave);
            if (valor !== null && typeof valor !== 'undefined') {
                historicoMemoria.add(chave);
                return true;
            }
        } catch (erro) {
            return false;
        }

        return false;
    }

    function registrarDisparo(chave) {
        historicoMemoria.add(chave);

        const storage = obterStorageSessao();
        if (!storage || typeof storage.setItem !== 'function') return;

        try {
            storage.setItem(chave, String(Date.now()));
        } catch (erro) {
            // A memória ainda evita repetições durante esta execução.
        }
    }

    function aplicarEstilos(elemento, estilos) {
        if (!elemento || !elemento.style) return;
        Object.assign(elemento.style, estilos);
    }

    function criarElemento(documento, tag, texto) {
        const elemento = documento.createElement(tag);
        if (typeof texto === 'string') elemento.textContent = texto;
        return elemento;
    }

    function fecharComEscapeNoDocumento(evento) {
        if (evento.key !== 'Escape') return;
        if (!referenciasModal || !referenciasModal.modal || referenciasModal.modal.hidden) return;

        evento.preventDefault();
        confirmarMedicamentoTomado();
    }

    function instalarEscapeNoDocumento(documento) {
        if (escapeDocumentoInstalado || typeof documento.addEventListener !== 'function') return;
        escapeDocumentoInstalado = true;
        documento.addEventListener('keydown', fecharComEscapeNoDocumento);
    }

    function criarModal() {
        const documento = obterDocumento();
        if (!documento || !documento.body || typeof documento.createElement !== 'function') return null;

        let modal = documento.getElementById('alarm-modal');
        if (!modal) {
            modal = criarElemento(documento, 'div');
            modal.id = 'alarm-modal';
            documento.body.appendChild(modal);
        } else {
            modal.textContent = '';
        }

        modal.hidden = true;
        modal.className = 'modal-overlay alarm-overlay';
        modal.setAttribute('role', 'alertdialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-labelledby', 'alarm-modal-title');
        modal.setAttribute('aria-describedby', 'alarm-modal-description alarm-modal-open-note');
        modal.setAttribute('data-old-fly-alarm', 'true');
        aplicarEstilos(modal, {
            position: 'fixed',
            inset: '0',
            zIndex: '10000',
            display: 'none',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '20px',
            background: 'rgba(15, 23, 42, 0.72)'
        });

        const cartao = criarElemento(documento, 'section');
        cartao.className = 'modal-card alarm-card';
        cartao.setAttribute('aria-live', 'assertive');
        aplicarEstilos(cartao, {
            width: 'min(560px, 100%)',
            maxHeight: 'min(82vh, 720px)',
            overflowY: 'auto',
            boxSizing: 'border-box',
            padding: '28px',
            border: '3px solid #f59e0b',
            borderRadius: '18px',
            background: '#ffffff',
            color: '#172033',
            boxShadow: '0 24px 70px rgba(0, 0, 0, 0.35)'
        });

        const sino = criarElemento(documento, 'div');
        sino.className = 'alarm-bell';
        sino.setAttribute('aria-hidden', 'true');
        const iconeSino = criarElemento(documento, 'i');
        iconeSino.className = 'fa-solid fa-bell';
        sino.appendChild(iconeSino);

        const selo = criarElemento(documento, 'p', 'Alarme de medicamento');
        selo.className = 'alarm-label';
        aplicarEstilos(selo, {
            display: 'inline-block',
            margin: '0 0 12px',
            padding: '6px 10px',
            borderRadius: '999px',
            background: '#fef3c7',
            color: '#92400e',
            fontSize: '0.82rem',
            fontWeight: '800',
            letterSpacing: '0.04em',
            textTransform: 'uppercase'
        });

        const titulo = criarElemento(documento, 'h2', 'Hora do medicamento');
        titulo.id = 'alarm-modal-title';
        aplicarEstilos(titulo, {
            margin: '0 0 8px',
            color: '#172033',
            fontSize: 'clamp(1.5rem, 4vw, 2rem)'
        });

        const horarioDestaque = criarElemento(documento, 'p', '--:--');
        horarioDestaque.className = 'alarm-time';
        horarioDestaque.setAttribute('aria-label', 'Horário do alarme');

        const descricao = criarElemento(documento, 'p', 'Confira os medicamentos programados para este horário.');
        descricao.id = 'alarm-modal-description';
        aplicarEstilos(descricao, {
            margin: '0 0 18px',
            color: '#475569',
            lineHeight: '1.5'
        });

        const lista = criarElemento(documento, 'ul');
        lista.id = 'alarm-modal-list';
        lista.className = 'alarm-medications';
        aplicarEstilos(lista, {
            display: 'grid',
            gap: '12px',
            margin: '0',
            padding: '0',
            listStyle: 'none'
        });

        const avisoAberto = criarElemento(
            documento,
            'p',
            'O alarme continua ativo ao navegar pelas páginas do Old Fly. Mantenha o sistema aberto no navegador.'
        );
        avisoAberto.id = 'alarm-modal-open-note';
        avisoAberto.className = 'alarm-note';
        aplicarEstilos(avisoAberto, {
            margin: '18px 0',
            padding: '12px',
            borderRadius: '10px',
            background: '#eff6ff',
            color: '#1e3a8a',
            fontSize: '0.92rem',
            lineHeight: '1.45'
        });

        const fechar = criarElemento(documento, 'button', 'Confirmar remédio tomado');
        fechar.id = 'alarm-modal-close';
        fechar.type = 'button';
        fechar.className = 'btn btn-primary';
        fechar.setAttribute('aria-label', 'Confirmar que o remédio foi tomado');
        aplicarEstilos(fechar, {
            width: '100%',
            minHeight: '48px',
            padding: '12px 18px',
            border: '0',
            borderRadius: '10px',
            background: '#2563eb',
            color: '#ffffff',
            font: 'inherit',
            fontWeight: '700',
            cursor: 'pointer'
        });

        const acoes = criarElemento(documento, 'div');
        acoes.className = 'modal-actions';
        acoes.appendChild(fechar);

        cartao.appendChild(sino);
        cartao.appendChild(selo);
        cartao.appendChild(titulo);
        cartao.appendChild(horarioDestaque);
        cartao.appendChild(descricao);
        cartao.appendChild(lista);
        cartao.appendChild(avisoAberto);
        cartao.appendChild(acoes);
        modal.appendChild(cartao);

        referenciasModal = { modal, cartao, selo, titulo, horarioDestaque, descricao, lista, fechar };
        instalarEscapeNoDocumento(documento);

        fechar.addEventListener('click', confirmarMedicamentoTomado);
        modal.addEventListener('keydown', evento => {
            if (evento.key === 'Escape') {
                evento.preventDefault();
                confirmarMedicamentoTomado();
                return;
            }

            if (evento.key === 'Tab') {
                evento.preventDefault();
                fechar.focus();
            }
        });

        return referenciasModal;
    }

    function obterReferenciasModal() {
        if (referenciasModal && referenciasModal.modal && referenciasModal.modal.isConnected !== false) {
            return referenciasModal;
        }
        return criarModal();
    }

    function adicionarDetalhe(documento, destino, rotulo, valor) {
        const linha = criarElemento(documento, 'p');
        aplicarEstilos(linha, { margin: '4px 0', lineHeight: '1.4' });

        const etiqueta = criarElemento(documento, 'strong', `${rotulo}: `);
        const conteudo = criarElemento(documento, 'span', valor);
        linha.appendChild(etiqueta);
        linha.appendChild(conteudo);
        destino.appendChild(linha);
    }

    function textoContainer(medicamento) {
        const numero = medicamento && medicamento.containerNumero;
        if (numero === null || typeof numero === 'undefined' || String(numero).trim() === '') {
            return 'Não informado';
        }
        return `#${numero}`;
    }

    function preencherModal(listaMedicamentos, horario, opcoes = {}) {
        const referencias = obterReferenciasModal();
        const documento = obterDocumento();
        if (!referencias || !documento) return null;

        modalEhTesteAgendado = opcoes.testeAgendado === true;
        referencias.lista.textContent = '';
        referencias.selo.textContent = modalEhTesteAgendado ? 'Teste de alarme' : 'Alarme de medicamento';
        referencias.horarioDestaque.textContent = horario || '--:--';
        referencias.descricao.textContent = listaMedicamentos.length === 1
            ? 'Há 1 medicamento programado para este horário.'
            : `Há ${listaMedicamentos.length} medicamentos programados para este horário.`;

        listaMedicamentos.forEach(medicamento => {
            const item = criarElemento(documento, 'li');
            item.className = 'alarm-medication';
            aplicarEstilos(item, {
                padding: '14px',
                border: '1px solid #cbd5e1',
                borderLeft: '5px solid #f59e0b',
                borderRadius: '10px',
                background: '#f8fafc'
            });

            const nome = criarElemento(
                documento,
                'h3',
                medicamento && medicamento.nome ? String(medicamento.nome) : 'Medicamento sem nome'
            );
            aplicarEstilos(nome, { margin: '0 0 8px', color: '#172033', fontSize: '1.08rem' });
            item.appendChild(nome);

            adicionarDetalhe(documento, item, 'Horário', horario || 'Não informado');
            adicionarDetalhe(
                documento,
                item,
                'Dosagem',
                medicamento && medicamento.dosagem ? String(medicamento.dosagem) : 'Não informada'
            );
            adicionarDetalhe(documento, item, 'Container', textoContainer(medicamento));
            referencias.lista.appendChild(item);
        });

        return referencias;
    }

    function abrirModal(listaMedicamentos, horario, opcoes = {}) {
        const referencias = preencherModal(listaMedicamentos, horario, opcoes);
        const documento = obterDocumento();
        if (!referencias || !documento) return;

        const estavaFechado = referencias.modal.hidden || referencias.modal.style.display === 'none';
        if (estavaFechado) focoAnterior = documento.activeElement;

        referencias.modal.hidden = false;
        referencias.modal.style.display = 'flex';

        if (estavaFechado && typeof referencias.fechar.focus === 'function') {
            try {
                referencias.fechar.focus({ preventScroll: true });
            } catch (erro) {
                referencias.fechar.focus();
            }
        }
    }

    function fecharModal() {
        pararAudioAlarme();
        const referencias = referenciasModal;
        if (!referencias || !referencias.modal || referencias.modal.hidden) return;

        referencias.modal.hidden = true;
        referencias.modal.style.display = 'none';
        modalEhTesteAgendado = false;

        const elemento = focoAnterior;
        focoAnterior = null;
        if (!elemento || typeof elemento.focus !== 'function' || elemento.isConnected === false) return;

        try {
            elemento.focus({ preventScroll: true });
        } catch (erro) {
            try {
                elemento.focus();
            } catch (erroFoco) {
                // O elemento anterior pode ter sido removido enquanto o modal estava aberto.
            }
        }
    }

    function confirmarMedicamentoTomado() {
        if (modalEhTesteAgendado && testeAgendado) {
            testeAgendado = null;
            testeConcluido = true;
        }
        fecharModal();
    }

    function obterAudioAlarme() {
        if (audioAlarme) return audioAlarme;
        if (!global || typeof global.Audio !== 'function') return null;

        try {
            audioAlarme = new global.Audio(URL_AUDIO_ALARME);
            audioAlarme.preload = 'auto';
            audioAlarme.loop = true;
            audioAlarme.volume = 0.9;
            return audioAlarme;
        } catch (erro) {
            audioAlarme = null;
            return null;
        }
    }

    function pararAudioAlarme() {
        alarmeAtivo = false;
        if (!audioAlarme) return;
        try {
            audioAlarme.pause();
            audioAlarme.currentTime = 0;
        } catch (erro) {
            // O alerta visual e a vibração continuam disponíveis se o áudio falhar.
        }
    }

    function removerPreparacaoAudio() {
        const documento = obterDocumento();
        if (!documento || !preparacaoAudioInstalada) return;

        preparacaoAudioInstalada = false;
        documento.removeEventListener('pointerdown', prepararAudioNaInteracao, true);
        documento.removeEventListener('keydown', prepararAudioNaInteracao, true);
    }

    function prepararAudioNaInteracao() {
        removerPreparacaoAudio();
        const audio = obterAudioAlarme();
        if (!audio || typeof audio.play !== 'function') return;

        try {
            audio.muted = true;
            const preparacao = audio.play();
            const finalizar = () => {
                if (!alarmeAtivo) {
                    audio.pause();
                    audio.currentTime = 0;
                }
                audio.muted = false;
            };

            if (preparacao && typeof preparacao.then === 'function') {
                preparacao.then(finalizar).catch(() => {
                    audio.muted = false;
                });
            } else {
                finalizar();
            }
        } catch (erro) {
            audio.muted = false;
        }
    }

    function instalarPreparacaoAudio() {
        const documento = obterDocumento();
        if (!documento || preparacaoAudioInstalada) return;

        preparacaoAudioInstalada = true;
        documento.addEventListener('pointerdown', prepararAudioNaInteracao, {
            once: true,
            capture: true,
            passive: true
        });
        documento.addEventListener('keydown', prepararAudioNaInteracao, { once: true, capture: true });
    }

    function tocarAudioAlarme() {
        const audio = obterAudioAlarme();
        if (!audio || typeof audio.play !== 'function') return;

        try {
            alarmeAtivo = true;
            audio.muted = false;
            audio.currentTime = 0;
            const reproducao = audio.play();
            if (reproducao && typeof reproducao.catch === 'function') {
                reproducao.catch(() => {
                    alarmeAtivo = false;
                    instalarPreparacaoAudio();
                });
            }
        } catch (erro) {
            alarmeAtivo = false;
            instalarPreparacaoAudio();
        }
    }

    function vibrar() {
        try {
            if (global.navigator && typeof global.navigator.vibrate === 'function') {
                global.navigator.vibrate([160, 100, 160, 100, 160]);
            }
        } catch (erro) {
            // Vibração não está disponível em todos os dispositivos/navegadores.
        }
    }

    function dispararAlerta(listaMedicamentos, horario, opcoes = {}) {
        if (!Array.isArray(listaMedicamentos) || !listaMedicamentos.length) return;
        modalEhTesteAgendado = opcoes.testeAgendado === true;
        abrirModal(listaMedicamentos, horario, opcoes);
        tocarAudioAlarme();
        vibrar();
    }

    function medicamentosNoHorario(lista, horario) {
        const schedule = obterSchedule();
        if (!schedule || typeof schedule.normalizarHorario !== 'function') return [];

        let horarioNormalizado = '';
        try {
            horarioNormalizado = schedule.normalizarHorario(horario);
        } catch (erro) {
            return [];
        }
        if (!horarioNormalizado) return [];

        if (typeof schedule.medicamentosNoHorario === 'function') {
            try {
                const encontrados = schedule.medicamentosNoHorario(lista, horarioNormalizado);
                return Array.isArray(encontrados) ? encontrados : [];
            } catch (erro) {
                return [];
            }
        }

        if (typeof schedule.extrairHorarios !== 'function') return [];
        return lista.filter(medicamento => {
            try {
                const horarios = schedule.extrairHorarios(medicamento.horario);
                return Array.isArray(horarios) && horarios.includes(horarioNormalizado);
            } catch (erro) {
                return false;
            }
        });
    }

    function setMedicamentos(lista) {
        medicamentos = Array.isArray(lista)
            ? lista.filter(item => item && typeof item === 'object').slice()
            : [];
        return medicamentos.slice();
    }

    function obterTesteAgendado() {
        if (!testeAgendado) return null;
        return {
            medicamento: testeAgendado.medicamento,
            disparoEm: new Date(testeAgendado.disparoEm.getTime()),
            disparado: testeAgendado.disparado
        };
    }

    function agendarTesteEmUmMinuto(medicamento, dataReferencia) {
        if (testeAgendado) return obterTesteAgendado();
        if (testeConcluido) return null;

        const candidato = medicamento && typeof medicamento === 'object'
            ? medicamento
            : filtrarMedicamentosDoUsuario(medicamentos)[0];
        const inicio = paraData(dataReferencia);
        if (!candidato || !inicio) return null;

        testeAgendado = {
            medicamento: candidato,
            disparoEm: new Date(inicio.getTime() + 60 * 1000),
            disparado: false
        };
        return obterTesteAgendado();
    }

    function verificarAgora(data) {
        const momento = paraData(data);
        if (!momento) return [];

        if (testeAgendado && !testeConcluido) {
            if (momento.getTime() >= testeAgendado.disparoEm.getTime()) {
                if (!testeAgendado.disparado) {
                    testeAgendado.disparado = true;
                    dispararAlerta(
                        [testeAgendado.medicamento],
                        obterHoraNormalizada(testeAgendado.disparoEm, false),
                        { testeAgendado: true }
                    );
                    return [testeAgendado.medicamento];
                }
            }
            return [];
        }

        const horario = obterHoraNormalizada(momento, true);
        if (!horario) return [];

        const dataISO = obterDataLocalISO(momento);
        limparHistoricoAntigo(dataISO);

        const permitidos = filtrarMedicamentosDoUsuario(medicamentos);
        const agendados = medicamentosNoHorario(permitidos, horario);
        const novos = [];

        agendados.forEach((medicamento, indice) => {
            const chave = criarChaveHistorico(dataISO, medicamento, horario, indice);
            if (jaFoiDisparado(chave)) return;

            registrarDisparo(chave);
            novos.push(medicamento);
        });

        if (novos.length) dispararAlerta(novos, horario);
        return novos;
    }

    function testar(medicamento) {
        let listaTeste = [];

        if (Array.isArray(medicamento)) {
            listaTeste = medicamento.filter(item => item && typeof item === 'object');
        } else if (medicamento && typeof medicamento === 'object') {
            listaTeste = [medicamento];
        } else {
            const permitidos = filtrarMedicamentosDoUsuario(medicamentos);
            if (permitidos.length) listaTeste = [permitidos[0]];
        }

        if (!listaTeste.length) {
            listaTeste = [{
                nome: 'Medicamento de teste',
                dosagem: 'Dosagem de exemplo',
                containerNumero: 'Exemplo'
            }];
        }

        const agora = new Date();
        const horario = obterHoraNormalizada(agora, false);
        dispararAlerta(listaTeste, horario);
        return listaTeste.slice();
    }

    function criarIntervalo(funcao, intervalo) {
        if (!global || typeof global.setInterval !== 'function') return null;
        try {
            return global.setInterval(funcao, intervalo);
        } catch (erro) {
            return null;
        }
    }

    function chaveUltimaVerificacao() {
        const usuario = obterUsuarioAtual();
        const perfil = usuario && usuario.perfil ? usuario.perfil : 'anonimo';
        const id = usuario && usuario.id != null ? usuario.id : '0';
        return `${PREFIXO_ULTIMA_VERIFICACAO}${perfil}:${id}`;
    }

    function verificarComRecuperacao() {
        const agora = new Date();
        const storage = obterStorageSessao();
        let ultima = null;

        if (storage) {
            const valor = Number(storage.getItem(chaveUltimaVerificacao()));
            if (Number.isFinite(valor) && valor > 0) ultima = new Date(valor);
        }

        const disparados = [];
        if (ultima && agora.getTime() - ultima.getTime() <= JANELA_RECUPERACAO_MS) {
            const cursor = new Date(ultima.getTime());
            cursor.setSeconds(0, 0);
            cursor.setMinutes(cursor.getMinutes() + 1);
            while (cursor.getTime() < agora.getTime()) {
                disparados.push(...verificarAgora(cursor));
                cursor.setMinutes(cursor.getMinutes() + 1);
            }
        }

        disparados.push(...verificarAgora(agora));
        if (storage) {
            try {
                storage.setItem(chaveUltimaVerificacao(), String(agora.getTime()));
            } catch (erro) {
                // O alarme continua em memória quando o armazenamento não está disponível.
            }
        }
        return disparados;
    }

    function limparIntervalo(timer) {
        if (timer === null || !global || typeof global.clearInterval !== 'function') return;
        try {
            global.clearInterval(timer);
        } catch (erro) {
            // O timer já pode ter sido encerrado pelo ambiente.
        }
    }

    function buscarMedicamentos(ciclo) {
        if (!global || typeof global.buscarMedicamentosBackend !== 'function') {
            return Promise.resolve(false);
        }

        let requisicao;
        try {
            requisicao = global.buscarMedicamentosBackend();
        } catch (erro) {
            return Promise.resolve(false);
        }

        return Promise.resolve(requisicao)
            .then(lista => {
                if (!emExecucao || ciclo !== cicloExecucao) return false;
                setMedicamentos(Array.isArray(lista) ? lista : []);
                return true;
            })
            .catch(() => false);
    }

    function start() {
        if (emExecucao) return promessaInicial || Promise.resolve(medicamentos.slice());

        emExecucao = true;
        cicloExecucao += 1;
        dataUltimaLimpeza = '';
        instalarPreparacaoAudio();

        const ciclo = cicloExecucao;
        timerBusca = criarIntervalo(() => {
            buscarMedicamentos(ciclo);
        }, INTERVALO_BUSCA_MS);
        timerVerificacao = criarIntervalo(() => {
            verificarComRecuperacao();
        }, INTERVALO_VERIFICACAO_MS);

        promessaInicial = buscarMedicamentos(ciclo).then(() => {
            if (emExecucao && ciclo === cicloExecucao) verificarComRecuperacao();
            return medicamentos.slice();
        });

        promessaInicial.finally(() => {
            if (ciclo === cicloExecucao) promessaInicial = null;
        });

        return promessaInicial;
    }

    function stop() {
        emExecucao = false;
        cicloExecucao += 1;
        limparIntervalo(timerBusca);
        limparIntervalo(timerVerificacao);
        timerBusca = null;
        timerVerificacao = null;
        promessaInicial = null;
        testeAgendado = null;
        testeConcluido = false;
        modalEhTesteAgendado = false;
        removerPreparacaoAudio();
        fecharModal();
    }

    instalarPreparacaoAudio();

    global.OldFlyAlarm = {
        start,
        stop,
        setMedicamentos,
        testar,
        verificarAgora,
        agendarTesteEmUmMinuto,
        obterTesteAgendado,
        confirmarMedicamentoTomado
    };
})(typeof window !== 'undefined' ? window : globalThis);
