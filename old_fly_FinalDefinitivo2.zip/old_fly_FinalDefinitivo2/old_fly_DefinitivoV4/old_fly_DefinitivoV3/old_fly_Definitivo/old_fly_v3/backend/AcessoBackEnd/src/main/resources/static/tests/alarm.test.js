'use strict';

const assert = require('node:assert/strict');

global.OldFlySchedule = require('../js/schedule.js');

let audioCriado = null;
global.Audio = class AudioFake {
    constructor(src) {
        this.src = src;
        this.currentTime = 0;
        this.reproducoes = 0;
        this.pausas = 0;
        audioCriado = this;
    }

    play() {
        this.reproducoes += 1;
        return Promise.resolve();
    }

    pause() {
        this.pausas += 1;
    }
};

let usuarioAtual = { id: 10, perfil: 'idoso' };
global.getViewingUser = () => usuarioAtual;

const itensStorage = new Map();
const sessionStorageFake = {
    get length() { return itensStorage.size; },
    getItem(chave) { return itensStorage.has(chave) ? itensStorage.get(chave) : null; },
    setItem(chave, valor) { itensStorage.set(chave, String(valor)); },
    removeItem(chave) { itensStorage.delete(chave); },
    key(indice) { return Array.from(itensStorage.keys())[indice] ?? null; }
};
Object.defineProperty(global, 'sessionStorage', { value: sessionStorageFake, configurable: true });

require('../js/alarm.js');
const alarm = global.OldFlyAlarm;

function teste(nome, executar) {
    executar();
    console.log('\u2713 ' + nome);
}

teste('dispara apenas o medicamento do idoso no minuto programado', () => {
    alarm.setMedicamentos([
        { id: 1, idosoId: 10, nome: 'Losartana', horario: '08:00' },
        { id: 2, idosoId: 20, nome: 'Outro paciente', horario: '08:00' },
        { id: 3, idosoId: 10, nome: 'Mais tarde', horario: '09:00' }
    ]);

    const disparados = alarm.verificarAgora(new Date(2026, 7, 24, 8, 0));
    assert.deepEqual(disparados.map(item => item.id), [1]);
});

teste('não repete o mesmo alarme no mesmo dia e minuto', () => {
    const repetidos = alarm.verificarAgora(new Date(2026, 7, 24, 8, 0, 45));
    assert.deepEqual(repetidos, []);
});

teste('rearma o mesmo medicamento no dia seguinte', () => {
    const disparados = alarm.verificarAgora(new Date(2026, 7, 25, 8, 0));
    assert.deepEqual(disparados.map(item => item.id), [1]);
});

teste('cuidador recebe somente alarmes do idoso vinculado', () => {
    usuarioAtual = { id: 30, perfil: 'cuidador', idosoId: 20 };
    alarm.setMedicamentos([
        { id: 4, idosoId: 10, nome: 'Idoso A', horario: '12:00' },
        { id: 5, idosoId: 20, nome: 'Idoso B', horario: '12:00' }
    ]);

    const disparados = alarm.verificarAgora(new Date(2026, 7, 26, 12, 0));
    assert.deepEqual(disparados.map(item => item.id), [5]);
});

teste('administrador recebe os medicamentos simultâneos em um único ciclo', () => {
    usuarioAtual = { id: 99, perfil: 'admin' };
    alarm.setMedicamentos([
        { id: 6, idosoId: 10, nome: 'A', horario: '18:30' },
        { id: 7, idosoId: 20, nome: 'B', horario: '06:30, 18:30' }
    ]);

    const disparados = alarm.verificarAgora(new Date(2026, 7, 27, 18, 30));
    assert.deepEqual(disparados.map(item => item.id), [6, 7]);
});

teste('não dispara fora do minuto programado', () => {
    const disparados = alarm.verificarAgora(new Date(2026, 7, 28, 18, 29));
    assert.deepEqual(disparados, []);
});

teste('o teste manual não consome o alarme real', () => {
    usuarioAtual = { id: 10, perfil: 'idoso' };
    const medicamento = { id: 8, idosoId: 10, nome: 'Teste', horario: '21:15' };
    alarm.setMedicamentos([medicamento]);
    alarm.testar(medicamento);

    const disparados = alarm.verificarAgora(new Date(2026, 7, 29, 21, 15));
    assert.deepEqual(disparados.map(item => item.id), [8]);
});

teste('agenda o teste para um minuto e o remove ao confirmar o remédio', () => {
    const medicamento = { id: 9, idosoId: 10, nome: 'Teste de um minuto', horario: '22:00' };
    const inicio = new Date(2026, 7, 30, 10, 0, 15);
    const agendado = alarm.agendarTesteEmUmMinuto(medicamento, inicio);

    assert.equal(agendado.disparoEm.getTime() - inicio.getTime(), 60 * 1000);
    assert.deepEqual(alarm.verificarAgora(new Date(2026, 7, 30, 10, 1, 14)), []);
    assert.deepEqual(
        alarm.verificarAgora(new Date(2026, 7, 30, 10, 1, 15)).map(item => item.id),
        [9]
    );
    assert.equal(alarm.obterTesteAgendado().disparado, true);

    alarm.confirmarMedicamentoTomado();
    assert.equal(alarm.obterTesteAgendado(), null);
    assert.equal(medicamento.horario, '22:00');
});

teste('usa Homecoming.mp3 em repetição como som do alarme', () => {
    assert.ok(audioCriado);
    assert.match(audioCriado.src, /assents\/Homecoming\.mp3$/);
    assert.equal(audioCriado.loop, true);
    assert.equal(audioCriado.volume, 0.9);
    assert.ok(audioCriado.reproducoes >= 1);
});

alarm.stop();
assert.ok(audioCriado.pausas >= 1);
console.log('Todos os testes de alarme passaram.');
