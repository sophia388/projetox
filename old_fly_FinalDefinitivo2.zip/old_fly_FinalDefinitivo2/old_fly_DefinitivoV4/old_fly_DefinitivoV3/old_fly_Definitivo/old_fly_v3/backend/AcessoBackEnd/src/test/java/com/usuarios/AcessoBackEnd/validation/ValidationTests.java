package com.usuarios.AcessoBackEnd.validation;

import com.usuarios.AcessoBackEnd.dto.AdminDTO;
import com.usuarios.AcessoBackEnd.dto.EstoqueDTO;
import com.usuarios.AcessoBackEnd.dto.LoginDTO;
import com.usuarios.AcessoBackEnd.dto.MedicamentoDTO;
import com.usuarios.AcessoBackEnd.dto.ReceitaDTO;
import com.usuarios.AcessoBackEnd.dto.UsuarioCuidadorDTO;
import com.usuarios.AcessoBackEnd.dto.UsuarioIdosoDTO;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

public class ValidationTests {

    private static Validator validator;

    @BeforeAll
    public static void setUp() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    @DisplayName("AdminDTO válido não deve ter violações")
    public void testAdminDTOValido() {
        AdminDTO dto = new AdminDTO();
        dto.setNome("Carlos Silva");
        dto.setIdade(45);
        dto.setUsuario("carlos.silva");
        dto.setEmail("carlos@teste.com");
        dto.setSenha("senha123");

        Set<ConstraintViolation<AdminDTO>> violations = validator.validate(dto);
        assertTrue(violations.isEmpty(), "Não deveria haver violações para AdminDTO válido");
    }

    @Test
    @DisplayName("AdminDTO com dados inválidos deve falhar nas validações")
    public void testAdminDTOInvalido() {
        AdminDTO dto = new AdminDTO();
        dto.setNome("Carlos123 #!"); // números e símbolos
        dto.setIdade(-5); // negativa
        dto.setUsuario("ab"); // menos de 3 chars
        dto.setEmail("email_invalido"); // sem @ e sem domínio
        dto.setSenha("123"); // menos de 6 chars

        Set<ConstraintViolation<AdminDTO>> violations = validator.validate(dto);
        assertFalse(violations.isEmpty());
        assertEquals(5, violations.size(), "Deve conter violação para todos os 5 campos inválidos");
    }

    @Test
    @DisplayName("UsuarioCuidadorDTO com idade acima de 130 deve falhar")
    public void testCuidadorIdadeInvalida() {
        UsuarioCuidadorDTO dto = new UsuarioCuidadorDTO();
        dto.setNome("Ana Paula");
        dto.setIdade(150);
        dto.setUsuario("ana.paula");
        dto.setEmail("ana@teste.com");
        dto.setSenha("segredo123");

        Set<ConstraintViolation<UsuarioCuidadorDTO>> violations = validator.validate(dto);
        assertFalse(violations.isEmpty());
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("idade")));
    }

    @Test
    @DisplayName("UsuarioIdosoDTO com nome em branco deve falhar")
    public void testIdosoNomeEmBranco() {
        UsuarioIdosoDTO dto = new UsuarioIdosoDTO();
        dto.setNome("   ");
        dto.setIdade(70);
        dto.setUsuario("idoso.joao");
        dto.setEmail("joao@teste.com");
        dto.setSenha("segredo123");

        Set<ConstraintViolation<UsuarioIdosoDTO>> violations = validator.validate(dto);
        assertFalse(violations.isEmpty());
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("nome")));
    }

    @Test
    @DisplayName("LoginDTO com campos em branco deve falhar")
    public void testLoginDTOEmBranco() {
        LoginDTO dto = new LoginDTO();
        dto.setUsuario("");
        dto.setSenha("");

        Set<ConstraintViolation<LoginDTO>> violations = validator.validate(dto);
        assertEquals(2, violations.size());
    }

    @Test
    @DisplayName("MedicamentoDTO válido deve passar")
    public void testMedicamentoDTOValido() {
        MedicamentoDTO dto = new MedicamentoDTO();
        dto.setNome("Losartana Potássica 50mg");
        dto.setDosagem("50mg");
        dto.setCategoria("Cardiovascular");
        dto.setHorario("08:00, 20:00");
        dto.setTipoUso("Contínuo");
        dto.setContainerNumero(1);
        dto.setQuantidadeAtual(10);
        dto.setQuantidadeMinima(5);

        Set<ConstraintViolation<MedicamentoDTO>> violations = validator.validate(dto);
        assertTrue(violations.isEmpty(), "Medicamento válido não deve ter violações");
    }

    @Test
    @DisplayName("MedicamentoDTO com container fora do intervalo 1-8 deve falhar")
    public void testMedicamentoDTOContainerInvalido() {
        MedicamentoDTO dto = new MedicamentoDTO();
        dto.setNome("Dipirona");
        dto.setDosagem("500mg");
        dto.setCategoria("Analgésico");
        dto.setHorario("08:00");
        dto.setTipoUso("Contínuo");
        dto.setContainerNumero(9); // inválido (máx 8)
        dto.setQuantidadeAtual(-2); // negativo
        dto.setQuantidadeMinima(0); // menor que 1

        Set<ConstraintViolation<MedicamentoDTO>> violations = validator.validate(dto);
        assertFalse(violations.isEmpty());
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("containerNumero")));
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("quantidadeAtual")));
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("quantidadeMinima")));
    }

    @Test
    @DisplayName("EstoqueDTO com quantidade negativa deve falhar")
    public void testEstoqueDTOMinimo() {
        EstoqueDTO dto = new EstoqueDTO();
        dto.setQuantidadeAtual(-1);
        dto.setQuantidadeMinima(0);

        Set<ConstraintViolation<EstoqueDTO>> violations = validator.validate(dto);
        assertEquals(2, violations.size());
    }

    @Test
    @DisplayName("ReceitaDTO com médico inválido e data inválida deve falhar")
    public void testReceitaDTOInvalida() {
        ReceitaDTO dto = new ReceitaDTO();
        dto.setMedico("Dr. 12345"); // contém números
        dto.setDataReceita("data-invalida");
        dto.setMedicamentos("");

        Set<ConstraintViolation<ReceitaDTO>> violations = validator.validate(dto);
        assertFalse(violations.isEmpty());
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("medico")));
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("dataReceita")));
        assertTrue(violations.stream().anyMatch(v -> v.getPropertyPath().toString().equals("medicamentos")));
    }
}
