package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.dto.ReceitaDTO;
import com.usuarios.AcessoBackEnd.dto.ReceitaResponseDTO;
import com.usuarios.AcessoBackEnd.entity.Receita;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.ReceitaRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ReceitaService {

    @Autowired
    private ReceitaRepository repository;

    @Autowired
    private UsuarioIdosoRepository idosoRepository;

    public ReceitaResponseDTO cadastrar(ReceitaDTO dto) {
        Receita receita = new Receita();
        preencher(receita, dto);
        return toDTO(repository.save(receita));
    }

    public List<ReceitaResponseDTO> listar() {
        return repository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public ReceitaResponseDTO buscarPorId(int id) {
        return toDTO(buscarEntidade(id));
    }

    public ReceitaResponseDTO atualizar(int id, ReceitaDTO dto) {
        Receita receita = buscarEntidade(id);
        preencher(receita, dto);
        return toDTO(repository.save(receita));
    }

    public void remover(int id) {
        repository.delete(buscarEntidade(id));
    }

    private Receita buscarEntidade(int id) {
        return repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Receita não encontrada"));
    }

    private void preencher(Receita receita, ReceitaDTO dto) {
        UsuarioIdoso idoso = null;
        if (dto.getIdosoId() > 0) {
            idoso = idosoRepository.findById(dto.getIdosoId())
                    .orElseThrow(() -> new IllegalArgumentException("O idoso selecionado para a receita não foi encontrado."));
        }

        if (dto.getDataReceita() == null || dto.getDataReceita().isBlank()) {
            throw new IllegalArgumentException("A data da receita é obrigatória.");
        }

        LocalDate dataParsed;
        try {
            dataParsed = LocalDate.parse(dto.getDataReceita().trim());
        } catch (Exception e) {
            throw new IllegalArgumentException("Data da receita inválida. Formato esperado: AAAA-MM-DD.");
        }

        if (dataParsed.getYear() < 1900 || dataParsed.getYear() > 2100) {
            throw new IllegalArgumentException("O ano da receita deve estar entre 1900 e 2100.");
        }

        receita.setMedico(dto.getMedico());
        receita.setMedicamentos(dto.getMedicamentos());
        receita.setObservacoes(dto.getObservacoes());
        receita.setArquivoNome(dto.getArquivoNome());
        receita.setIdoso(idoso);
        receita.setDataReceita(dataParsed);
    }


    private ReceitaResponseDTO toDTO(Receita receita) {
        Integer idosoId = receita.getIdoso() != null ? receita.getIdoso().getId() : null;
        String nomeIdoso = receita.getIdoso() != null ? receita.getIdoso().getNome() : "Sem vínculo";
        return new ReceitaResponseDTO(
                receita.getId(),
                receita.getMedico(),
                receita.getDataReceita(),
                receita.getMedicamentos(),
                receita.getObservacoes(),
                receita.getArquivoNome(),
                idosoId,
                nomeIdoso
        );
    }
}
