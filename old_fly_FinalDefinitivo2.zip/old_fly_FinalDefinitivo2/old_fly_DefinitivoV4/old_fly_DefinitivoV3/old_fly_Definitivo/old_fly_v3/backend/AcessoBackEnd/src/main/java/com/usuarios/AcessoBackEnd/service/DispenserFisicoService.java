package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.config.DispenserProperties;
import com.usuarios.AcessoBackEnd.entity.ComandoDispenser;
import com.usuarios.AcessoBackEnd.entity.Medicamento;
import com.usuarios.AcessoBackEnd.repository.ComandoDispenserRepository;
import com.usuarios.AcessoBackEnd.repository.MedicamentoRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;

import static com.usuarios.AcessoBackEnd.entity.ComandoDispenser.Estado.*;

@Service
@SuppressWarnings("null")
public class DispenserFisicoService {
    private final DispenserProperties config;
    private final ComandoDispenserRepository comandos;
    private final MedicamentoRepository medicamentos;
    private final UsuarioIdosoRepository idosos;
    private final Clock clock;
    private final VinculoDispenserService vinculos;
    private volatile Instant ultimoContato;
    private volatile Boolean ultimaSimulacao;

    public DispenserFisicoService(DispenserProperties config, ComandoDispenserRepository comandos,
                                 MedicamentoRepository medicamentos, UsuarioIdosoRepository idosos, Clock clock,
                                 VinculoDispenserService vinculos) {
        this.config = config;
        this.comandos = comandos;
        this.medicamentos = medicamentos;
        this.idosos = idosos;
        this.clock = clock;
        this.vinculos = vinculos;
    }

    private void autenticar(String authorization) {
        if (!config.configurado()) throw falha(HttpStatus.SERVICE_UNAVAILABLE, "Dispenser ainda não configurado.");
        String recebido = authorization != null && authorization.startsWith("Bearer ") ? authorization.substring(7) : "";
        if (!MessageDigest.isEqual(config.getToken().getBytes(StandardCharsets.UTF_8), recebido.getBytes(StandardCharsets.UTF_8))) {
            throw falha(HttpStatus.UNAUTHORIZED, "Credencial do dispenser inválida.");
        }
        ultimoContato = clock.instant();
    }

    private void bloquearIdoso() {
        int idosoId = vinculos.bloquear().getIdosoId();
        idosos.findByIdForUpdate(idosoId)
                .orElseThrow(() -> falha(HttpStatus.CONFLICT, "O idoso do dispenser não está cadastrado."));
    }

    private LocalDateTime agora() { return LocalDateTime.now(clock); }

    @Transactional
    public void trocarIdoso(int idosoId) {
        var vinculo = vinculos.bloquear();
        if (vinculo.getIdosoId() == idosoId) return;
        if (idosoId < 0 || (idosoId > 0 && !idosos.existsById(idosoId))) {
            throw falha(HttpStatus.BAD_REQUEST, "Selecione um idoso cadastrado.");
        }
        if (comandos.findFirstByIdosoIdAndEstadoInOrderByAgendadoParaAsc(vinculo.getIdosoId(), List.of(INICIADO, INCERTO)).isPresent()) {
            throw falha(HttpStatus.CONFLICT, "Conclua ou confira o ciclo pendente antes de trocar o idoso do dispenser.");
        }
        for (var comando : comandos.findByIdosoIdAndEstado(vinculo.getIdosoId(), OFERECIDO)) {
            comando.mudarEstado(CANCELADO, agora());
        }
        vinculo.setIdosoId(idosoId);
        // Trocar o dono não libera imediatamente doses do minuto já em andamento.
        vinculo.setAtivarAPartirDe(agora().truncatedTo(ChronoUnit.MINUTES).plusMinutes(1));
    }

    @Transactional
    public ComandoDispenser proximo(String authorization, boolean simulacao) {
        autenticar(authorization);
        var configuracaoAtual = vinculos.bloquear();
        if (configuracaoAtual.getIdosoId() == 0) return null;
        bloquearIdoso();
        ultimaSimulacao = simulacao;
        var vinculo = vinculos.bloquear();
        if (vinculo.getAtivarAPartirDe() != null && agora().isBefore(vinculo.getAtivarAPartirDe())) return null;

        // Nunca entrega outro ciclo enquanto há execução sem confirmação ou conferência pendente.
        var pendente = comandos.findFirstByIdosoIdAndEstadoInOrderByAgendadoParaAsc(
                vinculos.idosoId(), List.of(INICIADO, INCERTO));
        if (pendente.isPresent()) return pendente.get();
        if (!simulacao && !config.isPermitirMotores()) return null;

        LocalDateTime minuto = agora().truncatedTo(ChronoUnit.MINUTES);
        var lista = medicamentos.findByIdosoId(vinculos.idosoId()).stream()
                .sorted(Comparator.comparingInt(Medicamento::getContainerNumero)).toList();
        for (Medicamento medicamento : lista) {
            if (!apto(medicamento, minuto)) continue;
            int motor = medicamento.getContainerNumero();
            // Um container deve identificar exatamente um medicamento.
            if (lista.stream().filter(m -> m.getContainerNumero() == motor).count() != 1) continue;
            var existente = comandos.findByMedicamentoIdAndAgendadoPara(medicamento.getId(), minuto);
            if (existente.isPresent()) {
                if (existente.get().getEstado() == OFERECIDO && existente.get().isSimulacao() == simulacao) return existente.get();
                continue;
            }
            ComandoDispenser comando = new ComandoDispenser();
            comando.setMedicamentoId(medicamento.getId());
            comando.setIdosoId(vinculos.idosoId());
            comando.setMotor(motor);
            comando.setSimulacao(simulacao);
            comando.setAgendadoPara(minuto);
            comando.mudarEstado(OFERECIDO, agora());
            return comandos.saveAndFlush(comando);
        }
        return null;
    }

    @Transactional
    public ComandoDispenser iniciar(String authorization, String id) {
        autenticar(authorization);
        bloquearIdoso();
        ComandoDispenser comando = buscar(id);
        if (comando.getEstado() != OFERECIDO) throw falha(HttpStatus.CONFLICT, "Este comando não pode ser iniciado novamente.");
        if (!comando.isSimulacao() && !config.isPermitirMotores()) throw falha(HttpStatus.CONFLICT, "Motores desabilitados.");
        if (!comando.getAgendadoPara().equals(agora().truncatedTo(ChronoUnit.MINUTES))) {
            throw falha(HttpStatus.CONFLICT, "O horário deste comando expirou.");
        }
        var outro = comandos.findFirstByIdosoIdAndEstadoInOrderByAgendadoParaAsc(vinculos.idosoId(), List.of(INICIADO, INCERTO));
        if (outro.isPresent()) throw falha(HttpStatus.CONFLICT, "Há uma execução pendente de conferência.");
        Medicamento medicamento = medicamentos.findById(comando.getMedicamentoId())
                .orElseThrow(() -> falha(HttpStatus.CONFLICT, "Remédio removido; comando cancelado."));
        if (!apto(medicamento, comando.getAgendadoPara()) || medicamento.getContainerNumero() != comando.getMotor()) {
            throw falha(HttpStatus.CONFLICT, "O cadastro mudou; este comando não será executado.");
        }
        if (medicamentos.findByIdosoId(vinculos.idosoId()).stream()
                .filter(m -> m.getContainerNumero() == comando.getMotor()).count() != 1) {
            throw falha(HttpStatus.CONFLICT, "Há mais de um remédio no mesmo container.");
        }
        comando.mudarEstado(INICIADO, agora());
        return comandos.saveAndFlush(comando);
    }

    @Transactional
    public void resultado(String authorization, String id, String estado) {
        autenticar(authorization);
        vinculos.bloquear();
        ComandoDispenser comando = buscar(id);
        if (!Set.of("CONCLUIDO", "SIMULADO", "INCERTO").contains(estado)) {
            throw falha(HttpStatus.BAD_REQUEST, "Resultado inválido.");
        }
        ComandoDispenser.Estado novo = ComandoDispenser.Estado.valueOf(estado);
        if (comando.getEstado() == novo || comando.getEstado() == CONFERIDO) return;
        if (novo == INCERTO && comando.getEstado() != INICIADO && comando.getEstado() != OFERECIDO) return;
        if (novo != INCERTO && (comando.getEstado() != INICIADO
                || (novo == SIMULADO) != comando.isSimulacao())) {
            throw falha(HttpStatus.CONFLICT, "Resultado incompatível com o comando.");
        }
        comando.mudarEstado(novo, agora());
        comandos.saveAndFlush(comando);
        // Movimento do motor não comprova queda nem ingestão: o estoque não é baixado aqui.
    }

    @Transactional
    public void conferir(String authorization, String id) {
        autenticar(authorization);
        vinculos.bloquear();
        ComandoDispenser comando = buscar(id);
        if (Set.of(CONFERIDO, CANCELADO, CONCLUIDO, SIMULADO).contains(comando.getEstado())) return;
        if (comando.getEstado() != INCERTO) throw falha(HttpStatus.CONFLICT, "O comando não aguarda conferência.");
        comando.mudarEstado(CONFERIDO, agora());
    }

    private ComandoDispenser buscar(String id) {
        return comandos.findById(id).filter(c -> c.getIdosoId() == vinculos.idosoId())
                .orElseThrow(() -> falha(HttpStatus.NOT_FOUND, "Comando não encontrado para este dispenser."));
    }

    private boolean apto(Medicamento medicamento, LocalDateTime minuto) {
        if (medicamento.getIdoso() == null || medicamento.getIdoso().getId() != vinculos.idosoId()
                || medicamento.getContainerNumero() < 1 || medicamento.getContainerNumero() > 2
                || medicamento.getEstoque() == null || medicamento.getEstoque().getQuantidadeAtual() <= 0
                || medicamento.getHorario() == null) return false;
        if (medicamento.isAntibiotico() || MedicamentoRegras.ehAntibiotico(medicamento.getCategoria())) {
            LocalDate inicio = medicamento.getDataInicioTratamento();
            Integer dias = medicamento.getDuracaoTratamentoDias();
            if (inicio == null || !MedicamentoRegras.duracaoPermitida(dias)
                    || minuto.toLocalDate().isBefore(inicio) || !minuto.toLocalDate().isBefore(inicio.plusDays(dias))) return false;
        }
        for (String horario : medicamento.getHorario().split(",")) {
            try {
                if (LocalTime.parse(horario.trim()).equals(minuto.toLocalTime())) return true;
            } catch (java.time.format.DateTimeParseException ignored) { }
        }
        return false;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> status() {
        Map<String, Object> dados = new LinkedHashMap<>();
        boolean cadastrado = config.configurado() && idosos.existsById(vinculos.idosoId());
        dados.put("habilitado", config.isHabilitado());
        dados.put("configurado", cadastrado);
        dados.put("idosoId", vinculos.idosoId());
        dados.put("permitirMotores", config.isPermitirMotores());
        dados.put("online", cadastrado && ultimoContato != null && Duration.between(ultimoContato, clock.instant()).getSeconds() < 30);
        dados.put("simulacao", ultimaSimulacao);
        dados.put("ultimoContato", ultimoContato);
        dados.put("containers", List.of(1, 2));
        dados.put("containersSemMotor", cadastrado ? medicamentos.findByIdosoId(vinculos.idosoId()).stream()
                .map(Medicamento::getContainerNumero).filter(n -> n < 1 || n > 2).distinct().sorted().toList() : List.of());
        var historico = cadastrado ? comandos.findTop10ByIdosoIdOrderByAgendadoParaDesc(vinculos.idosoId()) : List.<ComandoDispenser>of();
        dados.put("historico", historico.stream().map(c -> Map.of(
                "id", c.getId(), "medicamentoId", c.getMedicamentoId(), "container", c.getMotor(),
                "estado", c.getEstado() == OFERECIDO && c.getAgendadoPara().isBefore(agora().truncatedTo(ChronoUnit.MINUTES))
                        ? "EXPIRADO" : c.getEstado().name(), "horario", c.getAgendadoPara().toString())).toList());
        var pendencia = cadastrado ? comandos.findFirstByIdosoIdAndEstadoInOrderByAgendadoParaAsc(
                vinculos.idosoId(), List.of(INICIADO, INCERTO)) : Optional.<ComandoDispenser>empty();
        boolean emExecucao = pendencia.filter(c -> c.getEstado() == INICIADO
                && c.getAtualizadoEm().isAfter(agora().minusSeconds(30))).isPresent();
        dados.put("emExecucao", emExecucao);
        dados.put("conferenciaPendente", pendencia.isPresent() && !emExecucao);
        return dados;
    }

    private ResponseStatusException falha(HttpStatus status, String mensagem) { return new ResponseStatusException(status, mensagem); }
}
