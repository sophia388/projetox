document.addEventListener('DOMContentLoaded', async () => {
    const usuarioLogado = getLoggedUser();
    const voltarDashboard = () => {
        window.location.href = '../index.html?dashboard=1';
    };

    if (!usuarioLogado) {
        window.location.href = '../index.html';
        return;
    }

    if (usuarioLogado.perfil === 'idoso') {
        voltarDashboard();
        return;
    }

    const form = document.getElementById('form-medicamento');
    const formMsg = document.getElementById('medicamento-form-msg');
    const pageTitle = document.getElementById('medicamento-page-title');
    const medicamentoId = document.getElementById('medicamento-id');
    const medicamentoNome = document.getElementById('medicamento-nome');
    const medicamentoDosagem = document.getElementById('medicamento-dosagem');
    const medicamentoCategoria = document.getElementById('medicamento-categoria');
    const medicamentoTipo = document.getElementById('medicamento-tipo');
    const medicamentoCor = document.getElementById('medicamento-cor');
    const medicamentoCorAjuda = document.getElementById('medicamento-cor-ajuda');
    const medicamentoContainer = document.getElementById('medicamento-container');
    const medicamentoIdosoId = document.getElementById('medicamento-idoso-id');
    const medicamentoEstoque = document.getElementById('medicamento-estoque');
    const medicamentoMinimo = document.getElementById('medicamento-minimo');
    const medicamentoAntibiotico = document.getElementById('medicamento-antibiotico');
    const medicamentoAntibioticoCampos = document.getElementById('medicamento-antibiotico-campos');
    const medicamentoDataInicio = document.getElementById('medicamento-data-inicio');
    const medicamentoDuracao = document.getElementById('medicamento-duracao');
    const medicamentoExclusaoPreview = document.getElementById('medicamento-exclusao-preview');
    const medicamentoHorario = document.getElementById('medicamento-horario');
    const medicamentoHorarioNovo = document.getElementById('medicamento-horario-novo');
    const medicamentoHorariosLista = document.getElementById('medicamento-horarios-lista');
    const medicamentoIntervalo = document.getElementById('medicamento-intervalo');
    const scheduleBuilder = medicamentoHorarioNovo.closest('.schedule-builder');
    let horariosSelecionados = [];
    let usuariosCache = [];
    let salvando = false;
    let formularioPronto = false;
    const botaoSalvar = form.querySelector('[type="submit"]');
    botaoSalvar.disabled = true;

    function escapeHTML(valor) {
        return String(valor ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function mostrarToast(mensagem, tipo = 'ok') {
        const toast = document.getElementById('toast');
        toast.innerText = mensagem;
        toast.className = `toast show ${tipo}`;
        setTimeout(() => toast.className = 'toast', 3000);
    }

    function dataLocalISO(data = new Date()) {
        const ano = data.getFullYear();
        const mes = String(data.getMonth() + 1).padStart(2, '0');
        const dia = String(data.getDate()).padStart(2, '0');
        return `${ano}-${mes}-${dia}`;
    }

    function formatarData(dataISO) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(String(dataISO ?? ''))) return 'data não informada';
        const [ano, mes, dia] = dataISO.split('-');
        return `${dia}/${mes}/${ano}`;
    }

    function calcularDataExclusao(dataInicio, duracaoDias) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(String(dataInicio ?? ''))) return '';
        const [ano, mes, dia] = dataInicio.split('-').map(Number);
        const dataExclusao = new Date(ano, mes - 1, dia);
        dataExclusao.setDate(dataExclusao.getDate() + Number(duracaoDias || 5));
        return dataLocalISO(dataExclusao);
    }

    async function carregarUsuarios() {
        usuariosCache = await buscarUsuariosBackend();
    }

    function primeiroIdosoId() {
        if (usuarioLogado.perfil === 'cuidador') {
            const cuidador = usuariosCache.find(usuario => usuario.perfil === 'cuidador' && usuario.id === usuarioLogado.id);
            return cuidador ? cuidador.idosoId || 0 : 0;
        }
        const idoso = usuariosCache.find(usuario => usuario.perfil === 'idoso');
        return idoso ? idoso.id : 0;
    }

    function preencherSelectIdosos(selecionado) {
        const idosos = usuariosCache.filter(usuario => usuario.perfil === 'idoso');
        medicamentoIdosoId.innerHTML = '<option value="0">Sem idoso vinculado</option>' + idosos.map(idoso => `
            <option value="${Number(idoso.id)}" ${Number(selecionado) === Number(idoso.id) ? 'selected' : ''}>${escapeHTML(idoso.nome)}</option>
        `).join('');
        medicamentoIdosoId.disabled = usuarioLogado.perfil === 'cuidador';
    }

    function atualizarCor() {
        const status = classificarEstoque(
            medicamentoEstoque.value,
            medicamentoMinimo.value,
            medicamentoAntibiotico.checked
        );
        medicamentoCor.value = status.cor;
        medicamentoCorAjuda.innerText = `${status.rotulo}: cor definida automaticamente pela quantidade em estoque.`;
    }

    function atualizarAntibiotico() {
        const antibiotico = medicamentoAntibiotico.checked;
        medicamentoAntibioticoCampos.style.display = antibiotico ? 'flex' : 'none';
        medicamentoDataInicio.disabled = !antibiotico;
        medicamentoDuracao.disabled = !antibiotico;
        medicamentoDataInicio.required = antibiotico;
        medicamentoDuracao.required = antibiotico;

        if (antibiotico) {
            if (!medicamentoDataInicio.value) medicamentoDataInicio.value = dataLocalISO();
            medicamentoTipo.value = 'Programado';
            medicamentoTipo.disabled = true;
            const exclusao = calcularDataExclusao(medicamentoDataInicio.value, medicamentoDuracao.value);
            medicamentoExclusaoPreview.innerText = `Exclusão automática prevista para ${formatarData(exclusao)}.`;
            medicamentoExclusaoPreview.style.display = 'block';
        } else {
            medicamentoTipo.disabled = false;
            medicamentoExclusaoPreview.style.display = 'none';
        }
        atualizarCor();
    }

    function limparErroHorarios() {
        scheduleBuilder.classList.remove('has-error');
        medicamentoHorarioNovo.removeAttribute('aria-invalid');
        if (formMsg.dataset.erroHorario === 'true') {
            formMsg.innerText = '';
            delete formMsg.dataset.erroHorario;
        }
    }

    function mostrarErroHorarios(mensagem) {
        formMsg.innerText = mensagem;
        formMsg.dataset.erroHorario = 'true';
        scheduleBuilder.classList.add('has-error');
        medicamentoHorarioNovo.setAttribute('aria-invalid', 'true');
        medicamentoHorarioNovo.focus();
    }

    function renderizarHorarios() {
        horariosSelecionados = OldFlySchedule.extrairHorarios(horariosSelecionados.join(', '));
        medicamentoHorario.value = OldFlySchedule.serializarHorarios(horariosSelecionados);

        if (!horariosSelecionados.length) {
            medicamentoHorariosLista.innerHTML = '<span class="schedule-empty"><i class="fa-regular fa-clock"></i> Nenhum horário adicionado</span>';
            return;
        }

        medicamentoHorariosLista.innerHTML = horariosSelecionados.map(horario => `
            <span class="schedule-chip" role="listitem">
                <i class="fa-regular fa-clock"></i> ${horario}
                <button type="button" data-horario="${horario}" aria-label="Remover o horário ${horario}" title="Remover ${horario}">
                    <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                </button>
            </span>
        `).join('');

        medicamentoHorariosLista.querySelectorAll('button[data-horario]').forEach(botao => {
            botao.addEventListener('click', () => {
                horariosSelecionados = horariosSelecionados.filter(horario => horario !== botao.dataset.horario);
                renderizarHorarios();
            });
        });
    }

    function definirHorarios(valor) {
        horariosSelecionados = OldFlySchedule.extrairHorarios(valor || '');
        limparErroHorarios();
        renderizarHorarios();
    }

    function adicionarHorario() {
        const horario = OldFlySchedule.normalizarHorario(medicamentoHorarioNovo.value);
        if (!horario) {
            mostrarErroHorarios('Escolha um horário válido no relógio.');
            return;
        }
        horariosSelecionados = [...horariosSelecionados, horario];
        limparErroHorarios();
        renderizarHorarios();
        medicamentoHorarioNovo.value = '';
        medicamentoHorarioNovo.focus();
    }

    function gerarHorarios() {
        const gerados = OldFlySchedule.gerarHorarios(medicamentoHorarioNovo.value, medicamentoIntervalo.value);
        if (!gerados.length) {
            mostrarErroHorarios('Informe o primeiro horário e escolha um intervalo para gerar o dia.');
            return;
        }
        horariosSelecionados = gerados;
        limparErroHorarios();
        renderizarHorarios();
        mostrarToast(`${gerados.length} horário(s) gerado(s) automaticamente.`);
    }

    function preencherFormulario(medicamento) {
        medicamentoId.value = medicamento.id;
        medicamentoNome.value = medicamento.nome || '';
        medicamentoDosagem.value = medicamento.dosagem || '';
        medicamentoCategoria.value = medicamento.categoria || '';
        medicamentoTipo.value = medicamento.tipoUso === 'Programado' ? 'Programado' : 'Contínuo';
        medicamentoContainer.value = medicamento.containerNumero || '';
        medicamentoEstoque.value = medicamento.quantidadeAtual ?? 0;
        medicamentoMinimo.value = medicamento.quantidadeMinima || 5;
        medicamentoAntibiotico.checked = typeof medicamento.antibiotico === 'boolean'
            ? medicamento.antibiotico
            : ehAntibiotico(medicamento.categoria);
        medicamentoDataInicio.value = medicamento.dataInicioTratamento || '';
        medicamentoDuracao.value = String(medicamento.duracaoTratamentoDias || 5);
        preencherSelectIdosos(medicamento.idosoId || 0);
        definirHorarios(medicamento.horario);
        atualizarAntibiotico();
    }

    document.getElementById('btn-voltar-dashboard').addEventListener('click', voltarDashboard);
    document.getElementById('btn-cancelar-medicamento').addEventListener('click', voltarDashboard);
    document.getElementById('btn-sair-medicamento').addEventListener('click', (evento) => {
        evento.preventDefault();
        if (window.OldFlyAlarm) OldFlyAlarm.stop();
        clearLoggedUser();
        window.location.href = '../index.html';
    });
    document.getElementById('btn-adicionar-horario').addEventListener('click', adicionarHorario);
    document.getElementById('btn-gerar-horarios').addEventListener('click', gerarHorarios);
    document.getElementById('btn-testar-alarme').addEventListener('click', () => {
        if (!window.OldFlyAlarm) return;
        OldFlyAlarm.testar({
            id: medicamentoId.value || 'teste',
            nome: medicamentoNome.value.trim() || 'Medicamento de teste',
            dosagem: medicamentoDosagem.value.trim() || 'Dosagem cadastrada',
            containerNumero: medicamentoContainer.value || '-',
            horario: OldFlySchedule.horaAtual()
        });
    });

    medicamentoHorarioNovo.addEventListener('change', limparErroHorarios);
    medicamentoIdosoId.addEventListener('change', () => {
        medicamentoContainer.value = '';
    });
    medicamentoHorarioNovo.addEventListener('keydown', (evento) => {
        if (evento.key !== 'Enter') return;
        evento.preventDefault();
        if (salvando || !formularioPronto) return;
        adicionarHorario();
    });
    medicamentoEstoque.addEventListener('input', atualizarCor);
    medicamentoMinimo.addEventListener('input', atualizarCor);
    medicamentoAntibiotico.addEventListener('change', atualizarAntibiotico);
    medicamentoDataInicio.addEventListener('change', atualizarAntibiotico);
    medicamentoDuracao.addEventListener('change', atualizarAntibiotico);
    medicamentoCategoria.addEventListener('change', () => {
        if (ehAntibiotico(medicamentoCategoria.value)) {
            medicamentoAntibiotico.checked = true;
            atualizarAntibiotico();
        }
    });

    form.addEventListener('submit', async (evento) => {
        evento.preventDefault();
        if (salvando || !formularioPronto) return;
        if (!horariosSelecionados.length) {
            mostrarErroHorarios('Adicione pelo menos um horário antes de salvar.');
            return;
        }

        limparErroHorarios();
        salvando = true;
        botaoSalvar.disabled = true;
        formMsg.innerText = 'Salvando...';
        try {
            const salvo = await salvarMedicamentoBackend({
                nome: medicamentoNome.value.trim(),
                dosagem: medicamentoDosagem.value.trim(),
                categoria: medicamentoCategoria.value.trim(),
                horario: medicamentoHorario.value,
                tipoUso: medicamentoTipo.value,
                idosoId: medicamentoIdosoId.value,
                quantidadeAtual: medicamentoEstoque.value,
                quantidadeMinima: medicamentoMinimo.value,
                antibiotico: medicamentoAntibiotico.checked,
                dataInicioTratamento: medicamentoDataInicio.value || null,
                duracaoTratamentoDias: medicamentoDuracao.value
            }, medicamentoId.value || null);
            sessionStorage.setItem('oldfly_medicamento_salvo', `Remédio ${medicamentoId.value ? 'atualizado' : 'cadastrado'} com sucesso no container #${salvo.containerNumero}.`);
            voltarDashboard();
        } catch (erro) {
            formMsg.innerText = mensagemDaOperacao(erro, 'Não foi possível salvar o remédio. Confira os dados e tente novamente.');
        } finally {
            salvando = false;
            botaoSalvar.disabled = false;
        }
    });

    try {
        await carregarUsuarios();
        preencherSelectIdosos(primeiroIdosoId());
        definirHorarios('');
        atualizarAntibiotico();
        const idEdicao = new URLSearchParams(window.location.search).get('medicamentoId');
        if (idEdicao) {
            pageTitle.innerText = 'Editar remédio';
            document.title = 'Old Fly - Editar remédio';
            preencherFormulario(await buscarMedicamentoBackend(idEdicao));
        }
        formularioPronto = true;
        botaoSalvar.disabled = false;
    } catch (erro) {
        formMsg.innerText = mensagemDaOperacao(erro, 'Não foi possível carregar o formulário. Atualize a página para tentar novamente.');
    }

    if (window.OldFlyAlarm) OldFlyAlarm.start();
});
