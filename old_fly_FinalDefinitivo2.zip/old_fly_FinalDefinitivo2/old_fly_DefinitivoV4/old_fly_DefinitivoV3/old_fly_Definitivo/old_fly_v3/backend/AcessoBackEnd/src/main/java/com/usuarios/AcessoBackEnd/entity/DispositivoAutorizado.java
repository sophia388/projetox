package com.usuarios.AcessoBackEnd.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "dispositivo_autorizado")
public class DispositivoAutorizado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false, unique = true, length = 64)
    private String tokenHash;

    @ManyToOne(optional = false)
    @JoinColumn(name = "idoso_id", nullable = false)
    private UsuarioIdoso idoso;

    @ManyToOne(optional = false)
    @JoinColumn(name = "cuidador_id", nullable = false)
    private UsuarioCuidador cuidador;

    @Column(nullable = false)
    private boolean ativo = true;

    @Column(nullable = false)
    private LocalDateTime criadoEm;

    private LocalDateTime ultimoAcessoEm;

    public int getId() { return id; }
    public String getTokenHash() { return tokenHash; }
    public void setTokenHash(String tokenHash) { this.tokenHash = tokenHash; }
    public UsuarioIdoso getIdoso() { return idoso; }
    public void setIdoso(UsuarioIdoso idoso) { this.idoso = idoso; }
    public UsuarioCuidador getCuidador() { return cuidador; }
    public void setCuidador(UsuarioCuidador cuidador) { this.cuidador = cuidador; }
    public boolean isAtivo() { return ativo; }
    public void setAtivo(boolean ativo) { this.ativo = ativo; }
    public LocalDateTime getCriadoEm() { return criadoEm; }
    public void setCriadoEm(LocalDateTime criadoEm) { this.criadoEm = criadoEm; }
    public LocalDateTime getUltimoAcessoEm() { return ultimoAcessoEm; }
    public void setUltimoAcessoEm(LocalDateTime ultimoAcessoEm) { this.ultimoAcessoEm = ultimoAcessoEm; }
}
