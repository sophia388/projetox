package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.dto.EstoqueDTO;
import com.usuarios.AcessoBackEnd.dto.MedicamentoDTO;
import com.usuarios.AcessoBackEnd.dto.MedicamentoResponseDTO;
import com.usuarios.AcessoBackEnd.entity.Estoque;
import com.usuarios.AcessoBackEnd.entity.Medicamento;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.MedicamentoRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import com.usuarios.AcessoBackEnd.config.DispenserProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MedicamentoService {

    private static final ZoneId FUSO_HORARIO = ZoneId.of("America/Sao_Paulo");

    @Autowired
    private MedicamentoRepository repository;

    @Autowired
    private UsuarioIdosoRepository idosoRepository;

    @Autowired
    private DispenserProperties dispenserConfig;

    @Autowired
    private VinculoDispenserService vinculoDispenser;

    @Transactional
    public MedicamentoResponseDTO cadastrar(MedicamentoDTO dto) {
        bloquearDispenser(dto.getIdosoId());
        Medicamento medicamento = new Medicamento();
        preencher(medicamento, dto);
        medicamento.setContainerNumero(escolherContainer(dto.getIdosoId(), 0, 0));
        return toDTO(repository.save(medicamento));
    }

    public List<MedicamentoResponseDTO> listar() {
        return repository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<MedicamentoResponseDTO> listarPorIdoso(int idosoId) {
        return repository.findByIdosoId(idosoId).stream().map(this::toDTO).collect(Collectors.toList());
    }

    public Medicamento buscarEntidade(int id) {
        return repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Medicamento não encontrado"));
    }

    public MedicamentoResponseDTO buscarPorId(int id) {
        return toDTO(buscarEntidade(id));
    }

    @Transactional
    public MedicamentoResponseDTO atualizar(int id, MedicamentoDTO dto) {
        bloquearDispenser(dto.getIdosoId());
        Medicamento medicamento = buscarEntidade(id);
        int idosoAnterior = medicamento.getIdoso() == null ? 0 : medicamento.getIdoso().getId();
        int containerAnterior = idosoAnterior == dto.getIdosoId() ? medicamento.getContainerNumero() : 0;
        preencher(medicamento, dto);
        medicamento.setContainerNumero(escolherContainer(dto.getIdosoId(), id, containerAnterior));
        return toDTO(repository.save(medicamento));
    }

    @Transactional
    public MedicamentoResponseDTO atualizarEstoque(int id, EstoqueDTO dto) {
        if (dto.getQuantidadeAtual() < 0) {
            throw new IllegalArgumentException("A quantidade atual não pode ser negativa.");
        }
        if (dto.getQuantidadeMinima() < 1) {
            throw new IllegalArgumentException("A quantidade mínima deve ser pelo menos 1.");
        }
        Medicamento medicamento = buscarEntidade(id);
        Estoque estoque = medicamento.getEstoque();
        if (estoque == null) {
            estoque = new Estoque();
            medicamento.setEstoque(estoque);
        }
        int quantidadeAtual = Math.max(0, dto.getQuantidadeAtual());
        int quantidadeMinima = normalizarQuantidadeMinima(dto.getQuantidadeMinima());
        estoque.setQuantidadeAtual(quantidadeAtual);
        estoque.setQuantidadeMinima(quantidadeMinima);
        estoque.setDataAtualizacao(LocalDateTime.now());
        medicamento.setCor(MedicamentoRegras.classificarCorEstoque(
                quantidadeAtual, quantidadeMinima, medicamentoEhAntibiotico(medicamento)));
        return toDTO(repository.save(medicamento));
    }

    @Transactional
    public void remover(int id) {
        repository.delete(buscarEntidade(id));
    }

    private void preencher(Medicamento medicamento, MedicamentoDTO dto) {
        UsuarioIdoso idoso = null;
        if (dto.getIdosoId() > 0) {
            idoso = idosoRepository.findById(dto.getIdosoId())
                    .orElseThrow(() -> new IllegalArgumentException("O idoso selecionado para o medicamento não foi encontrado."));
        }
        medicamento.setNome(dto.getNome());
        medicamento.setDosagem(dto.getDosagem());
        medicamento.setCategoria(dto.getCategoria());
        medicamento.setHorario(validarENormalizarHorarios(dto.getHorario()));
        medicamento.setTipoUso(validarTipoUso(dto.getTipoUso()));
        medicamento.setIdoso(idoso);
        configurarTratamentoAntibiotico(medicamento, dto);

        if (dto.getQuantidadeAtual() < 0) {
            throw new IllegalArgumentException("O estoque atual não pode ser negativo.");
        }
        if (dto.getQuantidadeMinima() < 1) {
            throw new IllegalArgumentException("O estoque mínimo deve ser pelo menos 1.");
        }

        Estoque estoque = medicamento.getEstoque();
        if (estoque == null) {
            estoque = new Estoque();
            medicamento.setEstoque(estoque);
        }
        int quantidadeAtual = Math.max(0, dto.getQuantidadeAtual());
        int quantidadeMinima = normalizarQuantidadeMinima(dto.getQuantidadeMinima());
        estoque.setQuantidadeAtual(quantidadeAtual);
        estoque.setQuantidadeMinima(quantidadeMinima);
        estoque.setDataAtualizacao(LocalDateTime.now());
        medicamento.setCor(MedicamentoRegras.classificarCorEstoque(
                quantidadeAtual, quantidadeMinima, medicamentoEhAntibiotico(medicamento)));
    }

    private void bloquearDispenser(int idosoId) {
        if (dispenserConfig != null && dispenserConfig.configurado() && vinculoDispenser != null) {
            vinculoDispenser.bloquear();
        }
        if (idosoId > 0) {
            // Serializa cadastros simultâneos no mesmo dispenser, inclusive quando vazio.
            idosoRepository.findByIdForUpdate(idosoId)
                    .orElseThrow(() -> new IllegalArgumentException("O idoso selecionado não está mais cadastrado. Atualize a lista e selecione outro idoso."));
        }
    }

    private int escolherContainer(int idosoId, int medicamentoIdAtual, int containerAnterior) {
        int capacidade = dispenserConfig != null && dispenserConfig.configurado()
                && vinculoDispenser != null && vinculoDispenser.idosoId() == idosoId ? 2 : 8;
        List<Medicamento> medicamentos = idosoId > 0
                ? repository.findByIdosoId(idosoId) : repository.findByIdosoIsNull();
        boolean[] ocupados = new boolean[9];
        for (Medicamento outro : medicamentos) {
            int numero = outro.getContainerNumero();
            if (outro.getId() != medicamentoIdAtual && numero >= 1 && numero <= 8) {
                ocupados[numero] = true;
            }
        }
        if (containerAnterior >= 1 && containerAnterior <= capacidade && !ocupados[containerAnterior]) {
            return containerAnterior;
        }
        for (int numero = 1; numero <= capacidade; numero++) {
            if (!ocupados[numero]) return numero;
        }
        throw new IllegalArgumentException("Os " + capacidade + " containers estão ocupados. Exclua um remédio que não será mais utilizado para liberar espaço.");
    }

    private String validarENormalizarHorarios(String horario) {
        if (horario == null || horario.isBlank()) {
            throw new IllegalArgumentException("Informe pelo menos um horário para o medicamento.");
        }
        String[] partes = horario.split(",");
        java.util.Set<String> normalizados = new java.util.TreeSet<>();
        for (String parte : partes) {
            String p = parte.trim();
            if (p.isEmpty()) continue;
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\d{1,2}):(\\d{2})$").matcher(p);
            if (!m.matches()) {
                throw new IllegalArgumentException("Horário inválido: '" + p + "'. Utilize o formato HH:mm.");
            }
            int h = Integer.parseInt(m.group(1));
            int min = Integer.parseInt(m.group(2));
            if (h < 0 || h > 23 || min < 0 || min > 59) {
                throw new IllegalArgumentException("Horário impossível: '" + p + "'. Horas devem ser 00-23 e minutos 00-59.");
            }
            normalizados.add(String.format("%02d:%02d", h, min));
        }
        if (normalizados.isEmpty()) {
            throw new IllegalArgumentException("Informe pelo menos um horário válido no formato HH:mm.");
        }
        return String.join(", ", normalizados);
    }


    private MedicamentoResponseDTO toDTO(Medicamento medicamento) {
        Estoque estoque = medicamento.getEstoque();
        int quantidadeAtual = estoque != null ? Math.max(0, estoque.getQuantidadeAtual()) : 0;
        int quantidadeMinima = estoque != null ? normalizarQuantidadeMinima(estoque.getQuantidadeMinima()) : 5;
        LocalDateTime dataAtualizacao = estoque != null ? estoque.getDataAtualizacao() : null;
        Integer idosoId = medicamento.getIdoso() != null ? medicamento.getIdoso().getId() : null;
        String nomeIdoso = medicamento.getIdoso() != null ? medicamento.getIdoso().getNome() : "Sem vínculo";
        boolean antibiotico = medicamentoEhAntibiotico(medicamento);
        LocalDate dataInicioTratamento = antibiotico
                ? (medicamento.getDataInicioTratamento() != null
                    ? medicamento.getDataInicioTratamento()
                    : LocalDate.now(FUSO_HORARIO))
                : null;
        Integer duracaoTratamentoDias = antibiotico
                ? (MedicamentoRegras.duracaoPermitida(medicamento.getDuracaoTratamentoDias())
                    ? medicamento.getDuracaoTratamentoDias()
                    : Integer.valueOf(5))
                : null;
        LocalDate dataExclusao = antibiotico
                ? MedicamentoRegras.calcularDataExclusao(dataInicioTratamento, duracaoTratamentoDias)
                : null;

        return new MedicamentoResponseDTO(
                medicamento.getId(),
                medicamento.getNome(),
                medicamento.getDosagem(),
                medicamento.getCategoria(),
                medicamento.getHorario(),
                normalizarTipoUsoParaResposta(medicamento.getTipoUso()),
                medicamento.getContainerNumero(),
                MedicamentoRegras.classificarCorEstoque(
                        quantidadeAtual, quantidadeMinima, antibiotico),
                idosoId,
                nomeIdoso,
                quantidadeAtual,
                quantidadeMinima,
                dataAtualizacao,
                antibiotico,
                dataInicioTratamento,
                duracaoTratamentoDias,
                dataExclusao
        );
    }

    private int normalizarQuantidadeMinima(int quantidadeMinima) {
        return quantidadeMinima > 0 ? quantidadeMinima : 5;
    }

    static String classificarCorEstoque(int quantidadeAtual, int quantidadeMinima) {
        return MedicamentoRegras.classificarCorEstoque(quantidadeAtual, quantidadeMinima, null);
    }

    static String classificarCorEstoque(int quantidadeAtual, int quantidadeMinima, String categoria) {
        return MedicamentoRegras.classificarCorEstoque(quantidadeAtual, quantidadeMinima, categoria);
    }

    static String classificarCorEstoque(int quantidadeAtual, int quantidadeMinima, boolean antibiotico) {
        return MedicamentoRegras.classificarCorEstoque(quantidadeAtual, quantidadeMinima, antibiotico);
    }

    private String validarTipoUso(String tipoUso) {
        String tipo = tipoUso == null ? "" : tipoUso.trim();
        if ("Contínuo".equalsIgnoreCase(tipo) || "Continuo".equalsIgnoreCase(tipo)) return "Contínuo";
        if ("Programado".equalsIgnoreCase(tipo)) return "Programado";
        throw new IllegalArgumentException("Tipo de uso deve ser Contínuo ou Programado");
    }

    private String normalizarTipoUsoParaResposta(String tipoUso) {
        try {
            return validarTipoUso(tipoUso);
        } catch (IllegalArgumentException erro) {
            return "Programado";
        }
    }

    private void configurarTratamentoAntibiotico(Medicamento medicamento, MedicamentoDTO dto) {
        boolean antibiotico = dto.getAntibiotico() != null
                ? dto.getAntibiotico()
                : medicamentoEhAntibiotico(medicamento);
        medicamento.setAntibiotico(antibiotico);

        if (!antibiotico) {
            medicamento.setDataInicioTratamento(null);
            medicamento.setDuracaoTratamentoDias(null);
            return;
        }

        Integer duracaoInformada = dto.getDuracaoTratamentoDias();
        if (duracaoInformada != null && !MedicamentoRegras.duracaoPermitida(duracaoInformada)) {
            throw new IllegalArgumentException("A duração do antibiótico deve ser de 5 ou 7 dias");
        }

        LocalDate dataInicio = dto.getDataInicioTratamento();
        if (dataInicio != null) {
            medicamento.setDataInicioTratamento(dataInicio);
        } else if (medicamento.getDataInicioTratamento() == null) {
            medicamento.setDataInicioTratamento(LocalDate.now(FUSO_HORARIO));
        }

        if (duracaoInformada != null) {
            medicamento.setDuracaoTratamentoDias(duracaoInformada);
        } else if (!MedicamentoRegras.duracaoPermitida(medicamento.getDuracaoTratamentoDias())) {
            medicamento.setDuracaoTratamentoDias(5);
        }
    }

    private boolean medicamentoEhAntibiotico(Medicamento medicamento) {
        return medicamento.getAntibiotico() != null
                ? medicamento.isAntibiotico()
                : MedicamentoRegras.ehAntibiotico(medicamento.getCategoria());
    }
}
