package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.repository.AdminRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.security.SecureRandom;
import java.time.Clock;
import java.time.Instant;
import java.util.HexFormat;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class SessaoAdminService {
    private record Sessao(int adminId, Instant expiraEm) { }
    private final ConcurrentHashMap<String, Sessao> sessoes = new ConcurrentHashMap<>();
    private final AdminRepository admins;
    private final Clock clock;
    public SessaoAdminService(AdminRepository admins, Clock clock) { this.admins = admins; this.clock = clock; }
    public String criar(int adminId) {
        sessoes.entrySet().removeIf(e -> !e.getValue().expiraEm().isAfter(clock.instant()));
        byte[] bytes = new byte[32];
        new SecureRandom().nextBytes(bytes);
        String token = HexFormat.of().formatHex(bytes);
        sessoes.put(token, new Sessao(adminId, clock.instant().plusSeconds(8 * 3600)));
        return token;
    }
    public void validar(String token) {
        Sessao sessao = token == null ? null : sessoes.get(token);
        if (sessao == null || !sessao.expiraEm().isAfter(clock.instant()) || !admins.existsById(sessao.adminId())) {
            if (token != null) sessoes.remove(token);
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Entre novamente como administrador para trocar o vínculo do dispenser.");
        }
    }
    public void encerrar(String token) { if (token != null) sessoes.remove(token); }
}
