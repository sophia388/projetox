const assert = require('assert');
const v = require('../js/validation.js');

let passed = 0;
function test(desc, fn) {
    fn();
    passed++;
    console.log(`✓ ${desc}`);
}

// 1. Nome
test('Nome válido deve ser aprovado e sanitizado', () => {
    const res = v.validarNome('   Maria da Silva  ');
    assert.strictEqual(res.valido, true);
    assert.strictEqual(res.valor, 'Maria da Silva');
});

test('Nome com acentos e hífen deve ser aprovado', () => {
    const res = v.validarNome('Jean-Luc d\'Ávila Gonçalves');
    assert.strictEqual(res.valido, true);
});

test('Nome com números ou símbolos deve ser rejeitado', () => {
    assert.strictEqual(v.validarNome('Carlos123').valido, false);
    assert.strictEqual(v.validarNome('Carlos @ Silva').valido, false);
    assert.strictEqual(v.validarNome('<script>').valido, false);
    assert.strictEqual(v.validarNome('A').valido, false); // < 2 chars
    assert.strictEqual(v.validarNome('').valido, false);
});

// 2. Usuário
test('Usuário válido deve ser aprovado', () => {
    assert.strictEqual(v.validarUsuario('idoso.joao').valido, true);
    assert.strictEqual(v.validarUsuario('cuidador_ana-123').valido, true);
});

test('Usuário com espaços, acentos ou símbolos proibidos deve ser rejeitado', () => {
    assert.strictEqual(v.validarUsuario('joao silva').valido, false);
    assert.strictEqual(v.validarUsuario('joão').valido, false);
    assert.strictEqual(v.validarUsuario('ab').valido, false); // < 3 chars
    assert.strictEqual(v.validarUsuario('user@oldfly').valido, false);
});

// 3. Senha
test('Senha válida deve ser aprovada', () => {
    assert.strictEqual(v.validarSenha('123456').valido, true);
    assert.strictEqual(v.validarSenha('senhaForte#2026').valido, true);
});

test('Senha com menos de 6 caracteres deve ser rejeitada quando obrigatória', () => {
    assert.strictEqual(v.validarSenha('12345').valido, false);
    assert.strictEqual(v.validarSenha('').valido, false);
    assert.strictEqual(v.validarSenha('', false).valido, true); // opcional na edição
});

// 4. E-mail
test('E-mail válido deve ser aprovado e convertido para minúsculas', () => {
    const res = v.validarEmail('  Usuario.Teste@Dominio.COM  ');
    assert.strictEqual(res.valido, true);
    assert.strictEqual(res.valor, 'usuario.teste@dominio.com');
});

test('E-mail inválido deve ser rejeitado', () => {
    assert.strictEqual(v.validarEmail('invalido').valido, false);
    assert.strictEqual(v.validarEmail('user@domain').valido, false);
    assert.strictEqual(v.validarEmail('user@.com').valido, false);
    assert.strictEqual(v.validarEmail('@domain.com').valido, false);
});

// 5. Idade
test('Idade válida entre 1 e 130 deve ser aprovada', () => {
    assert.strictEqual(v.validarIdade(67).valido, true);
    assert.strictEqual(v.validarIdade('67').valido, true);
});

test('Idade negativa, decimal, zero ou superior a 130 deve ser rejeitada', () => {
    assert.strictEqual(v.validarIdade(0).valido, false);
    assert.strictEqual(v.validarIdade(-5).valido, false);
    assert.strictEqual(v.validarIdade(67.5).valido, false);
    assert.strictEqual(v.validarIdade('67.5').valido, false);
    assert.strictEqual(v.validarIdade(131).valido, false);
    assert.strictEqual(v.validarIdade('abc').valido, false);
});

// 6. Perfil e Tipo Idoso
test('Perfil deve aceitar somente idoso, cuidador e admin', () => {
    assert.strictEqual(v.validarPerfil('idoso').valido, true);
    assert.strictEqual(v.validarPerfil('cuidador').valido, true);
    assert.strictEqual(v.validarPerfil('admin').valido, true);
    assert.strictEqual(v.validarPerfil('hacker').valido, false);
});

test('Tipo idoso deve aceitar apenas normal e debilitado', () => {
    assert.strictEqual(v.validarTipoIdoso('normal').valido, true);
    assert.strictEqual(v.validarTipoIdoso('debilitado').valido, true);
    assert.strictEqual(v.validarTipoIdoso('outro').valido, false);
});

// 7. Receita Médica
test('Médico válido deve ser aprovado', () => {
    assert.strictEqual(v.validarMedico('Dra. Helena Martins').valido, true);
    assert.strictEqual(v.validarMedico('Dr. Carlos Silva').valido, true);
});

test('Médico com números ou símbolos proibidos deve ser rejeitado', () => {
    assert.strictEqual(v.validarMedico('Dr. 12345').valido, false);
    assert.strictEqual(v.validarMedico('').valido, false);
});

test('Data de receita válida deve ser aprovada', () => {
    assert.strictEqual(v.validarDataReceita('2026-09-21').valido, true);
});

test('Data de receita impossível deve ser rejeitada', () => {
    assert.strictEqual(v.validarDataReceita('2026-02-30').valido, false);
    assert.strictEqual(v.validarDataReceita('data-invalida').valido, false);
    assert.strictEqual(v.validarDataReceita('1850-01-01').valido, false);
});

test('Arquivo da receita com extensão não permitida deve ser rejeitado', () => {
    assert.strictEqual(v.validarArquivo('receita.exe').valido, false);
    assert.strictEqual(v.validarArquivo('script.js').valido, false);
    assert.strictEqual(v.validarArquivo('foto.jpg').valido, true);
    assert.strictEqual(v.validarArquivo('receita.pdf').valido, true);
});

// 8. Medicamento
test('Nome e dosagem de medicamento válidos devem ser aprovados', () => {
    assert.strictEqual(v.validarMedicamentoNome('Losartana Potássica 50mg').valido, true);
    assert.strictEqual(v.validarDosagem('50mg').valido, true);
    assert.strictEqual(v.validarDosagem('1 comprimido').valido, true);
});

test('Categoria com números ou símbolos deve ser rejeitada', () => {
    assert.strictEqual(v.validarCategoria('Cardiovascular').valido, true);
    assert.strictEqual(v.validarCategoria('Cardio123').valido, false);
});

test('Container deve aceitar apenas inteiros de 1 a 8', () => {
    assert.strictEqual(v.validarContainer(1).valido, true);
    assert.strictEqual(v.validarContainer(8).valido, true);
    assert.strictEqual(v.validarContainer(0).valido, false);
    assert.strictEqual(v.validarContainer(9).valido, false);
    assert.strictEqual(v.validarContainer('3.5').valido, false);
});

test('Estoque atual e mínimo devem respeitar limites', () => {
    assert.strictEqual(v.validarEstoqueAtual(0).valido, true);
    assert.strictEqual(v.validarEstoqueAtual(10).valido, true);
    assert.strictEqual(v.validarEstoqueAtual(-1).valido, false);
    assert.strictEqual(v.validarEstoqueAtual(10.5).valido, false);

    assert.strictEqual(v.validarEstoqueMinimo(1).valido, true);
    assert.strictEqual(v.validarEstoqueMinimo(5).valido, true);
    assert.strictEqual(v.validarEstoqueMinimo(0).valido, false);
    assert.strictEqual(v.validarEstoqueMinimo(-2).valido, false);
});

test('Quantidade comprada deve ser positiva', () => {
    assert.strictEqual(v.validarQuantidadeComprada(10).valido, true);
    assert.strictEqual(v.validarQuantidadeComprada(0).valido, false);
    assert.strictEqual(v.validarQuantidadeComprada(-5).valido, false);
});

// 9. Horários
test('Horários individuais e múltiplos devem ser validados', () => {
    assert.strictEqual(v.validarHorarioIndividual('08:00').valido, true);
    assert.strictEqual(v.validarHorarioIndividual('25:00').valido, false);
    assert.strictEqual(v.validarHorarios('08:00, 20:00').valido, true);
    assert.strictEqual(v.validarHorarios('').valido, false);
    assert.strictEqual(v.validarHorarios('08:00, 99:00').valido, false);
});

// 10. Antibiótico
test('Antibiótico deve validar data de início e duração de 5 ou 7 dias', () => {
    assert.strictEqual(v.validarAntibiotico(false).valido, true);
    assert.strictEqual(v.validarAntibiotico(true, '2026-09-21', 5).valido, true);
    assert.strictEqual(v.validarAntibiotico(true, '2026-09-21', 7).valido, true);
    assert.strictEqual(v.validarAntibiotico(true, '2026-09-21', 10).valido, false);
    assert.strictEqual(v.validarAntibiotico(true, '', 5).valido, false);
});

console.log(`Todos os ${passed} testes de validação do frontend passaram com sucesso!`);
