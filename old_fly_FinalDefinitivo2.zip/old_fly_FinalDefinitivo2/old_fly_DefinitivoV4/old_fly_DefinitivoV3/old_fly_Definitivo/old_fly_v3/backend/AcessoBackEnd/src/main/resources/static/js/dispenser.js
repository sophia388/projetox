(function (global) {
    'use strict';

    function descreverStatus(dados) {
        if (!dados.habilitado || !dados.configurado) return { titulo: 'Configuração pendente', detalhe: 'O dispenser físico ainda não foi vinculado.', estado: 'pendente' };
        if (dados.conferenciaPendente) return { titulo: 'Conferência necessária', detalhe: 'Há um ciclo sem confirmação. Aguarde o cuidador conferir o dispenser antes de continuar.', estado: 'atencao' };
        if (!dados.online) return { titulo: 'Dispenser desconectado', detalhe: 'Verifique a alimentação e o Wi-Fi. Horários perdidos não serão liberados automaticamente depois.', estado: 'atencao' };
        if (dados.emExecucao) return { titulo: 'Ciclo em andamento', detalhe: 'Aguardando a confirmação do dispenser.', estado: 'conectado' };
        if (dados.simulacao) return { titulo: 'Conectado em simulação', detalhe: 'Os horários estão sendo testados. Os motores permanecem parados.', estado: 'simulacao' };
        if (!dados.permitirMotores) return { titulo: 'Motores desabilitados', detalhe: 'O dispenser está conectado e aguarda a habilitação dos motores.', estado: 'pendente' };
        return { titulo: 'Dispenser conectado', detalhe: 'Motor 1: container 1. Motor 2: container 2. Aguardando os horários cadastrados.', estado: 'conectado' };
    }

    const estados = {
        OFERECIDO: 'Aguardando início', INICIADO: 'Ciclo em andamento ou confirmação pendente',
        CONCLUIDO: 'Ciclo do motor concluído', SIMULADO: 'Simulação concluída',
        INCERTO: 'Conferência necessária', CONFERIDO: 'Conferido pelo responsável',
        CANCELADO: 'Cancelado', EXPIRADO: 'Horário encerrado sem acionamento'
    };

    if (typeof module === 'object' && module.exports) module.exports = { descreverStatus, estados };
    if (!global.document) return;

    global.document.addEventListener('DOMContentLoaded', () => {
        const painel = document.getElementById('dispenser-fisico');
        if (!painel) return;
        let consultando = false;
        let usuariosCarregados = false;
        let salvando = false;
        let selecaoAlterada = false;
        const form = document.getElementById('dispenser-vinculo-form');
        const select = document.getElementById('dispenser-idoso');
        const mensagem = document.getElementById('dispenser-vinculo-msg');
        select.addEventListener('change', () => {
            selecaoAlterada = true;
            document.getElementById('dispenser-cargas-conferidas').checked = false;
        });
        form.addEventListener('submit', async evento => {
            evento.preventDefault();
            if (salvando || !form.reportValidity()) return;
            salvando = true;
            const botao = form.querySelector('[type="submit"]');
            botao.disabled = true;
            try {
                await requestBackend('/api/dispenser/vinculo', {
                    method: 'PUT', credentials: 'include',
                    body: JSON.stringify({ idosoId: Number(select.value), cargasConferidas: document.getElementById('dispenser-cargas-conferidas').checked })
                });
                mensagem.textContent = 'Vínculo salvo. Os próximos horários valerão a partir do próximo minuto.';
                selecaoAlterada = false;
                document.getElementById('dispenser-cargas-conferidas').checked = false;
                await atualizar();
            } catch (erro) {
                mensagem.textContent = mensagemDaOperacao(erro, 'Não foi possível salvar o vínculo.');
            } finally { salvando = false; botao.disabled = false; }
        });

        async function atualizar() {
            const usuario = getLoggedUser();
            if (!usuario) { painel.hidden = true; return; }
            if (consultando || document.hidden) return;
            consultando = true;
            try {
                const dados = await requestBackend('/api/dispenser/status');
                if (!getLoggedUser()) { painel.hidden = true; return; }
                const pertence = usuario.perfil === 'admin'
                    || (usuario.perfil === 'idoso' && usuario.id === dados.idosoId)
                    || (usuario.perfil === 'cuidador' && usuario.idosoId === dados.idosoId);
                painel.hidden = !pertence;
                if (!pertence) return;
                form.hidden = usuario.perfil !== 'admin';
                if (usuario.perfil === 'admin') {
                    if (!usuariosCarregados || document.activeElement !== select) {
                        const selecionado = selecaoAlterada ? Number(select.value) : dados.idosoId;
                        const usuarios = await buscarUsuariosBackend();
                        select.replaceChildren();
                        const semVinculo = document.createElement('option');
                        semVinculo.value = '0'; semVinculo.textContent = 'Sem vínculo (pausado)';
                        select.appendChild(semVinculo);
                        usuarios.filter(u => u.perfil === 'idoso').forEach(u => {
                            const opcao = document.createElement('option');
                            opcao.value = String(u.id); opcao.textContent = `${u.nome} (ID ${u.id})`;
                            select.appendChild(opcao);
                        });
                        select.value = String(selecionado);
                        usuariosCarregados = true;
                    }
                }
                const descricao = descreverStatus(dados);
                painel.dataset.estado = descricao.estado;
                document.getElementById('dispenser-conexao').textContent = descricao.titulo;
                document.getElementById('dispenser-detalhe').textContent = descricao.detalhe;
                const aviso = document.getElementById('dispenser-sem-motor');
                aviso.textContent = dados.containersSemMotor?.length
                    ? `Containers ${dados.containersSemMotor.join(', ')} não têm motor neste aparelho. Esses remédios não terão acionamento físico.` : '';
                const lista = document.getElementById('dispenser-historico');
                lista.replaceChildren();
                (dados.historico || []).slice(0, 5).forEach(item => {
                    const linha = document.createElement('li');
                    // Datas da agenda são locais do backend (America/Sao_Paulo), sem conversão do navegador.
                    const [data, hora] = item.horario.split('T');
                    const dataExibida = data.split('-').reverse().join('/');
                    linha.textContent = `${dataExibida} ${hora.slice(0, 5)} · Container ${item.container} · ${estados[item.estado] || 'Status indisponível'}`;
                    lista.appendChild(linha);
                });
            } catch (erro) {
                painel.dataset.estado = 'atencao';
                document.getElementById('dispenser-conexao').textContent = 'Conexão não confirmada';
                document.getElementById('dispenser-detalhe').textContent = 'Não foi possível atualizar o estado do dispenser. Tentaremos novamente em alguns segundos.';
            } finally { consultando = false; }
        }

        document.getElementById('btn-atualizar-dispenser').addEventListener('click', atualizar);
        atualizar();
        setInterval(atualizar, 5000);
    });
})(typeof window !== 'undefined' ? window : globalThis);
