package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.entity.Admin;
import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.AdminRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioCuidadorRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioValidacaoService {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private UsuarioCuidadorRepository cuidadorRepository;

    @Autowired
    private UsuarioIdosoRepository idosoRepository;

    public void validarUnicidade(String usuario, String email, String tipo, Integer idExistente) {
        if (usuario != null && !usuario.isBlank()) {
            Optional<Admin> adminUser = adminRepository.findByUsuario(usuario);
            if (adminUser.isPresent() && (!"admin".equalsIgnoreCase(tipo) || adminUser.get().getId() != idExistente)) {
                throw new IllegalArgumentException("O nome de usuário '" + usuario + "' já está em uso.");
            }

            Optional<UsuarioCuidador> cuidadorUser = cuidadorRepository.findByUsuario(usuario);
            if (cuidadorUser.isPresent() && (!"cuidador".equalsIgnoreCase(tipo) || cuidadorUser.get().getId() != idExistente)) {
                throw new IllegalArgumentException("O nome de usuário '" + usuario + "' já está em uso.");
            }

            Optional<UsuarioIdoso> idosoUser = idosoRepository.findByUsuario(usuario);
            if (idosoUser.isPresent() && (!"idoso".equalsIgnoreCase(tipo) || idosoUser.get().getId() != idExistente)) {
                throw new IllegalArgumentException("O nome de usuário '" + usuario + "' já está em uso.");
            }
        }

        if (email != null && !email.isBlank()) {
            Optional<Admin> adminEmail = adminRepository.findByEmail(email);
            if (adminEmail.isPresent() && (!"admin".equalsIgnoreCase(tipo) || adminEmail.get().getId() != idExistente)) {
                throw new IllegalArgumentException("O e-mail '" + email + "' já está cadastrado no sistema.");
            }

            Optional<UsuarioCuidador> cuidadorEmail = cuidadorRepository.findByEmail(email);
            if (cuidadorEmail.isPresent() && (!"cuidador".equalsIgnoreCase(tipo) || cuidadorEmail.get().getId() != idExistente)) {
                throw new IllegalArgumentException("O e-mail '" + email + "' já está cadastrado no sistema.");
            }

            Optional<UsuarioIdoso> idosoEmail = idosoRepository.findByEmail(email);
            if (idosoEmail.isPresent() && (!"idoso".equalsIgnoreCase(tipo) || idosoEmail.get().getId() != idExistente)) {
                throw new IllegalArgumentException("O e-mail '" + email + "' já está cadastrado no sistema.");
            }
        }
    }

    public void validarSenhaCadastro(String senha) {
        if (senha == null || senha.isBlank()) {
            throw new IllegalArgumentException("A senha é obrigatória para o cadastro.");
        }
        if (senha.length() < 6 || senha.length() > 60) {
            throw new IllegalArgumentException("A senha deve ter entre 6 e 60 caracteres.");
        }
    }

    public void validarSenhaAtualizacao(String senha) {
        if (senha != null && !senha.isBlank() && (senha.length() < 6 || senha.length() > 60)) {
            throw new IllegalArgumentException("A senha deve ter entre 6 e 60 caracteres.");
        }
    }
}
