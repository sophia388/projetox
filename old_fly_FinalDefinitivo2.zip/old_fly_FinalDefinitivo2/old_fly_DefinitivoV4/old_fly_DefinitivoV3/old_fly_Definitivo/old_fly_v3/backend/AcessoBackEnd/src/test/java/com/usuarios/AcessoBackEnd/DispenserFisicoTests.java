package com.usuarios.AcessoBackEnd;

import com.usuarios.AcessoBackEnd.config.DispenserProperties;
import com.usuarios.AcessoBackEnd.dto.MedicamentoDTO;
import com.usuarios.AcessoBackEnd.entity.*;
import com.usuarios.AcessoBackEnd.repository.*;
import com.usuarios.AcessoBackEnd.service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.server.ResponseStatusException;

import java.time.*;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static com.usuarios.AcessoBackEnd.entity.ComandoDispenser.Estado.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties = "spring.datasource.url=jdbc:h2:mem:dispenser-tests;MODE=MySQL;DB_CLOSE_DELAY=-1;LOCK_TIMEOUT=10000")
@Transactional
class DispenserFisicoTests {
    private static final String TOKEN = "somente-testes-012345678901234567890123456789";
    private static final String AUTH = "Bearer " + TOKEN;
    @Autowired DispenserFisicoService service;
    @Autowired DispenserProperties config;
    @Autowired UsuarioIdosoRepository idosos;
    @Autowired MedicamentoRepository medicamentos;
    @Autowired ComandoDispenserRepository comandos;
    @Autowired VinculoDispenserRepository vinculoRepository;
    @Autowired VinculoDispenserService vinculos;
    @Autowired SessaoAdminService sessoesAdmin;
    @Autowired AdminRepository admins;
    @Autowired UsuarioIdosoService idosoService;
    @Autowired MedicamentoService medicamentoService;
    @Autowired WebApplicationContext context;
    @MockitoBean Clock clock;
    private UsuarioIdoso idoso;
    private MockMvc mvc;

    @BeforeEach
    void preparar() {
        when(clock.getZone()).thenReturn(ZoneId.of("America/Sao_Paulo"));
        horario("2026-10-26T11:00:10Z"); // 08:00 em São Paulo
        idoso = idosos.saveAndFlush(new UsuarioIdoso("Teste", 70, UUID.randomUUID().toString(), null, "teste123", null));
        config.setHabilitado(true);
        config.setIdosoId(idoso.getId());
        config.setToken(TOKEN);
        config.setPermitirMotores(false);
        var vinculo = vinculoRepository.findById(1).orElseThrow();
        vinculo.setIdosoId(idoso.getId());
        vinculo.setAtivarAPartirDe(null);
        vinculoRepository.saveAndFlush(vinculo);
        mvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    private void horario(String instante) { when(clock.instant()).thenReturn(Instant.parse(instante)); }

    private Medicamento remedio(int container, String horario, UsuarioIdoso dono) {
        Medicamento m = new Medicamento();
        m.setNome("Vitamina"); m.setDosagem("50mg"); m.setCategoria("Vitamina");
        m.setTipoUso("Contínuo"); m.setHorario(horario); m.setContainerNumero(container);
        m.setIdoso(dono); m.setEstoque(new Estoque(10, 5));
        return medicamentos.saveAndFlush(m);
    }

    @Test
    void rotasDeMovimentoExigemTokenEConfiguracao() throws Exception {
        remedio(1, "08:00", idoso);
        mvc.perform(post("/api/dispenser/proximo")).andExpect(status().isUnauthorized());
        mvc.perform(post("/api/dispenser/proximo").header("Authorization", "Bearer errado"))
                .andExpect(status().isUnauthorized());
        assertEquals(0, comandos.count());
        config.setHabilitado(false);
        mvc.perform(post("/api/dispenser/proximo").header("Authorization", AUTH))
                .andExpect(status().isServiceUnavailable());
    }

    @Test
    void simulacaoCompletaPelaApiSemBaixaAutomaticaNoEstoque() throws Exception {
        Medicamento m = remedio(1, "08:00", idoso);
        String protocolo = mvc.perform(post("/api/dispenser/proximo").header("Authorization", AUTH))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String id = protocolo.split(";")[0];
        assertTrue(protocolo.endsWith(";1;2048;1;OFERECIDO"));
        mvc.perform(post("/api/dispenser/comandos/" + id + "/iniciar").header("Authorization", AUTH))
                .andExpect(status().isOk()).andExpect(content().string(id + ";1;2048;1;INICIADO"));
        mvc.perform(post("/api/dispenser/comandos/" + id + "/resultado?estado=SIMULADO").header("Authorization", AUTH))
                .andExpect(status().isNoContent());
        mvc.perform(post("/api/dispenser/comandos/" + id + "/resultado?estado=SIMULADO").header("Authorization", AUTH))
                .andExpect(status().isNoContent());
        assertEquals(10, medicamentos.findById(m.getId()).orElseThrow().getEstoque().getQuantidadeAtual());
        assertNull(service.proximo(AUTH, true));
    }

    @Test
    void duasConsultasNaoCriamDoisComandosEInicioNaoPodeSerRepetido() {
        remedio(1, "08:00", idoso);
        var primeiro = service.proximo(AUTH, true);
        assertEquals(primeiro.getId(), service.proximo(AUTH, true).getId());
        service.iniciar(AUTH, primeiro.getId());
        assertEquals(409, assertThrows(ResponseStatusException.class,
                () -> service.iniciar(AUTH, primeiro.getId())).getStatusCode().value());
        assertEquals(1, comandos.count());
    }

    @Test
    void atendeDoisMotoresSequencialmenteSemExecutarContainerTresNemOutroIdoso() {
        remedio(2, "08:00", idoso);
        remedio(1, "08:00", idoso);
        remedio(3, "08:00", idoso);
        UsuarioIdoso outro = idosos.saveAndFlush(new UsuarioIdoso("Outro", 70, UUID.randomUUID().toString(), null, "teste123", null));
        remedio(1, "08:00", outro);
        var um = service.proximo(AUTH, true);
        assertEquals(1, um.getMotor());
        service.iniciar(AUTH, um.getId());
        assertEquals(um.getId(), service.proximo(AUTH, true).getId());
        service.resultado(AUTH, um.getId(), "SIMULADO");
        var dois = service.proximo(AUTH, true);
        assertEquals(2, dois.getMotor());
        service.iniciar(AUTH, dois.getId());
        service.resultado(AUTH, dois.getId(), "SIMULADO");
        assertNull(service.proximo(AUTH, true));
    }

    @Test
    void modoRealDependeDeHabilitacaoExplicita() {
        remedio(1, "08:00", idoso);
        assertNull(service.proximo(AUTH, false));
        config.setPermitirMotores(true);
        var comando = service.proximo(AUTH, false);
        assertFalse(comando.isSimulacao());
        service.iniciar(AUTH, comando.getId());
        assertThrows(ResponseStatusException.class, () -> service.resultado(AUTH, comando.getId(), "SIMULADO"));
        service.resultado(AUTH, comando.getId(), "CONCLUIDO");
        service.resultado(AUTH, comando.getId(), "CONCLUIDO");
        assertNull(service.proximo(AUTH, false));
    }

    @Test
    void atrasoNaoExecutaDoseAntigaMasHorarioDoDiaSeguinteFunciona() {
        remedio(1, "08:00", idoso);
        var comando = service.proximo(AUTH, true);
        horario("2026-10-26T11:01:00Z");
        assertThrows(ResponseStatusException.class, () -> service.iniciar(AUTH, comando.getId()));
        assertNull(service.proximo(AUTH, true));
        horario("2026-10-27T11:00:00Z");
        assertNotEquals(comando.getId(), service.proximo(AUTH, true).getId());
    }

    @Test
    void reinicioDoServicoPreservaBloqueioEAConferenciaNaoRepeteDose() {
        remedio(1, "08:00", idoso);
        var comando = service.proximo(AUTH, true);
        service.iniciar(AUTH, comando.getId());
        var reiniciado = new DispenserFisicoService(config, comandos, medicamentos, idosos, clock, vinculos);
        assertEquals(INICIADO, reiniciado.proximo(AUTH, true).getEstado());
        reiniciado.resultado(AUTH, comando.getId(), "INCERTO");
        assertEquals(INCERTO, reiniciado.proximo(AUTH, true).getEstado());
        reiniciado.conferir(AUTH, comando.getId());
        reiniciado.conferir(AUTH, comando.getId());
        assertNull(reiniciado.proximo(AUTH, true));
    }

    @Test
    void remocaoOuMudancaDoRemedioAntesDoInicioImpedeMotor() {
        Medicamento m = remedio(1, "08:00", idoso);
        var comando = service.proximo(AUTH, true);
        m.setHorario("09:00"); medicamentos.saveAndFlush(m);
        assertThrows(ResponseStatusException.class, () -> service.iniciar(AUTH, comando.getId()));
        medicamentos.delete(m); medicamentos.flush();
        assertThrows(ResponseStatusException.class, () -> service.iniciar(AUTH, comando.getId()));
    }

    @Test
    void estoqueVazioContainerDuplicadoEAntibioticoForaDoPeriodoNaoAcionam() {
        Medicamento m = remedio(1, "08:00", idoso);
        m.getEstoque().setQuantidadeAtual(0); medicamentos.saveAndFlush(m);
        assertNull(service.proximo(AUTH, true));
        m.getEstoque().setQuantidadeAtual(10); m.setAntibiotico(true);
        m.setDataInicioTratamento(LocalDate.of(2026, 10, 27)); m.setDuracaoTratamentoDias(5);
        medicamentos.saveAndFlush(m);
        assertNull(service.proximo(AUTH, true));
        m.setDataInicioTratamento(LocalDate.of(2026, 10, 1)); medicamentos.saveAndFlush(m);
        assertNull(service.proximo(AUTH, true));
        m.setAntibiotico(false); medicamentos.saveAndFlush(m);
        remedio(1, "08:00", idoso);
        assertNull(service.proximo(AUTH, true));
    }

    @Test
    void statusNaoExibeTokenEIndicaDesconexao() throws Exception {
        service.proximo(AUTH, true);
        mvc.perform(get("/api/dispenser/status")).andExpect(status().isOk())
                .andExpect(jsonPath("$.online").value(true)).andExpect(jsonPath("$.token").doesNotExist());
        horario("2026-10-26T11:01:00Z");
        assertEquals(false, service.status().get("online"));
    }

    @Test
    void cadastroAutomaticoRespeitaDoisContainersDoDispenserVinculado() {
        MedicamentoDTO dto = new MedicamentoDTO();
        dto.setNome("Vitamina"); dto.setDosagem("50mg"); dto.setCategoria("Vitamina");
        dto.setHorario("08:00"); dto.setTipoUso("Contínuo"); dto.setIdosoId(idoso.getId());
        dto.setQuantidadeAtual(10); dto.setQuantidadeMinima(5);
        assertEquals(1, medicamentoService.cadastrar(dto).getContainerNumero());
        assertEquals(2, medicamentoService.cadastrar(dto).getContainerNumero());
        assertTrue(assertThrows(IllegalArgumentException.class, () -> medicamentoService.cadastrar(dto))
                .getMessage().contains("2 containers"));
    }

    @Test
    void excluirIdosoTambemRemoveComandosEImpedeNovosAcionamentos() {
        remedio(1, "08:00", idoso);
        var comando = service.proximo(AUTH, true);
        idosoService.remover(idoso.getId());
        idosos.flush();
        assertFalse(comandos.existsById(comando.getId()));
        assertNull(service.proximo(AUTH, true));
    }

    @Test
    void administradorPodeTrocarVinculoPelaTelaComPersistencia() throws Exception {
        UsuarioIdoso outro = idosos.saveAndFlush(new UsuarioIdoso("Outro", 70, UUID.randomUUID().toString(), null, "teste123", null));
        remedio(1, "08:00", idoso);
        remedio(1, "08:00, 08:01", outro);
        var anterior = service.proximo(AUTH, true);
        String corpo = "{\"idosoId\":" + outro.getId() + ",\"cargasConferidas\":true}";
        mvc.perform(put("/api/dispenser/vinculo").contentType("application/json").content(corpo))
                .andExpect(status().isUnauthorized());
        Admin admin = admins.saveAndFlush(new Admin("Admin", 40, UUID.randomUUID().toString(), null, "teste123"));
        var cookie = new jakarta.servlet.http.Cookie("oldfly_admin_session", sessoesAdmin.criar(admin.getId()));
        mvc.perform(put("/api/dispenser/vinculo").cookie(cookie).contentType("application/json").content(corpo))
                .andExpect(status().isNoContent());
        assertEquals(outro.getId(), vinculoRepository.findById(1).orElseThrow().getIdosoId());
        assertEquals(CANCELADO, comandos.findById(anterior.getId()).orElseThrow().getEstado());
        assertNull(service.proximo(AUTH, true));
        horario("2026-10-26T11:01:00Z");
        assertEquals(outro.getId(), service.proximo(AUTH, true).getIdosoId());
    }

    @Test
    void naoTrocaVinculoDuranteCicloOuConferenciaPendente() {
        UsuarioIdoso outro = idosos.saveAndFlush(new UsuarioIdoso("Outro", 70, UUID.randomUUID().toString(), null, "teste123", null));
        remedio(1, "08:00", idoso);
        var comando = service.proximo(AUTH, true);
        service.iniciar(AUTH, comando.getId());
        assertThrows(ResponseStatusException.class, () -> service.trocarIdoso(outro.getId()));
        service.resultado(AUTH, comando.getId(), "INCERTO");
        assertThrows(ResponseStatusException.class, () -> service.trocarIdoso(outro.getId()));
        service.conferir(AUTH, comando.getId());
        service.trocarIdoso(outro.getId());
        assertEquals(outro.getId(), vinculos.idosoId());
    }

    @Test
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    void consultasSimultaneasEntregamOMesmoComandoPersistido() throws Exception {
        remedio(1, "08:00", idoso);
        CountDownLatch inicio = new CountDownLatch(1);
        try (var executor = Executors.newFixedThreadPool(2)) {
            var a = executor.submit(() -> { inicio.await(); return service.proximo(AUTH, true).getId(); });
            var b = executor.submit(() -> { inicio.await(); return service.proximo(AUTH, true).getId(); });
            inicio.countDown();
            assertEquals(a.get(15, TimeUnit.SECONDS), b.get(15, TimeUnit.SECONDS));
        } finally { idosoService.remover(idoso.getId()); }
    }

    @Test
    void loginDeAdministradorEmiteSessaoELogoutImpedeTroca() throws Exception {
        Admin admin = admins.saveAndFlush(new Admin("Admin", 40, "admin.dispenser", "admin.dispenser@teste.com", "teste123"));
        var resposta = mvc.perform(post("/auth/login").contentType("application/json")
                        .content("{\"usuario\":\"admin.dispenser\",\"senha\":\"teste123\"}"))
                .andExpect(status().isOk()).andReturn().getResponse();
        String cabecalho = resposta.getHeaders("Set-Cookie").stream()
                .filter(c -> c.startsWith("oldfly_admin_session=")).findFirst().orElseThrow();
        String token = cabecalho.substring("oldfly_admin_session=".length(), cabecalho.indexOf(';'));
        assertTrue(cabecalho.contains("HttpOnly"));
        var cookie = new jakarta.servlet.http.Cookie("oldfly_admin_session", token);
        mvc.perform(put("/api/dispenser/vinculo").cookie(cookie).contentType("application/json")
                        .content("{\"idosoId\":0,\"cargasConferidas\":true}"))
                .andExpect(status().isNoContent());
        mvc.perform(post("/auth/logout").cookie(cookie)).andExpect(status().isNoContent());
        mvc.perform(put("/api/dispenser/vinculo").cookie(cookie).contentType("application/json")
                        .content("{\"idosoId\":" + idoso.getId() + ",\"cargasConferidas\":true}"))
                .andExpect(status().isUnauthorized());
        assertTrue(admins.existsById(admin.getId()));
    }

    @Test
    void resultadoDeUsuarioExcluidoPermiteAPlacaReconhecerComandoRemovido() {
        remedio(1, "08:00", idoso);
        var comando = service.proximo(AUTH, true);
        service.iniciar(AUTH, comando.getId());
        idosoService.remover(idoso.getId());
        idosos.flush();
        assertEquals(404, assertThrows(ResponseStatusException.class,
                () -> service.resultado(AUTH, comando.getId(), "INCERTO")).getStatusCode().value());
    }

    @Test
    void conferenciaDeComandoCanceladoNaoPrendeAPlacaNemReexecutaCiclo() {
        remedio(1, "08:00", idoso);
        var comando = service.proximo(AUTH, true);
        service.trocarIdoso(0);
        service.trocarIdoso(idoso.getId());
        service.resultado(AUTH, comando.getId(), "INCERTO");
        service.conferir(AUTH, comando.getId());
        assertEquals(CANCELADO, comandos.findById(comando.getId()).orElseThrow().getEstado());
        assertThrows(ResponseStatusException.class, () -> service.iniciar(AUTH, comando.getId()));
    }

    @Test
    void painelDiferenciaCicloNormalDeConfirmacaoAtrasada() {
        remedio(1, "08:00", idoso);
        var comando = service.proximo(AUTH, true);
        service.iniciar(AUTH, comando.getId());
        assertEquals(true, service.status().get("emExecucao"));
        assertEquals(false, service.status().get("conferenciaPendente"));
        horario("2026-10-26T11:00:45Z");
        assertEquals(true, service.status().get("conferenciaPendente"));
    }
}
