package com.usuarios.AcessoBackEnd;

import com.usuarios.AcessoBackEnd.dto.MedicamentoDTO;
import com.usuarios.AcessoBackEnd.dto.MedicamentoResponseDTO;
import com.usuarios.AcessoBackEnd.entity.*;
import com.usuarios.AcessoBackEnd.repository.*;
import com.usuarios.AcessoBackEnd.service.*;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import java.time.LocalDateTime;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@Transactional
class FluxosPersistenciaTests {
    @Autowired UsuarioIdosoRepository idosos;
    @Autowired UsuarioCuidadorRepository cuidadores;
    @Autowired AdminRepository admins;
    @Autowired MedicamentoRepository medicamentos;
    @Autowired EstoqueRepository estoques;
    @Autowired ReceitaRepository receitas;
    @Autowired DispositivoAutorizadoRepository dispositivos;
    @Autowired SessaoCuidadorRepository sessoes;
    @Autowired UsuarioIdosoService idosoService;
    @Autowired UsuarioCuidadorService cuidadorService;
    @Autowired AdminService adminService;
    @Autowired MedicamentoService medicamentoService;
    @Autowired EntityManager em;
    @Autowired WebApplicationContext context;
    @Autowired JdbcTemplate jdbc;

    private UsuarioIdoso idoso() {
        String chave = UUID.randomUUID().toString();
        return idosos.saveAndFlush(new UsuarioIdoso("Tati", 70, chave, chave + "@teste.com", "senha123", null));
    }

    private UsuarioCuidador cuidador(UsuarioIdoso idoso) {
        String chave = UUID.randomUUID().toString();
        return cuidadores.saveAndFlush(new UsuarioCuidador("Cuidadora", 35, chave, chave + "@teste.com", "senha123", idoso, null));
    }

    private void autorizar(UsuarioIdoso idoso, UsuarioCuidador cuidador, boolean ativo) {
        DispositivoAutorizado dispositivo = new DispositivoAutorizado();
        dispositivo.setTokenHash(UUID.randomUUID().toString());
        dispositivo.setIdoso(idoso);
        dispositivo.setCuidador(cuidador);
        dispositivo.setAtivo(ativo);
        dispositivo.setCriadoEm(LocalDateTime.now());
        dispositivos.saveAndFlush(dispositivo);
    }

    private String sessao(UsuarioCuidador cuidador) {
        SessaoCuidador sessao = new SessaoCuidador();
        sessao.setTokenHash(UUID.randomUUID().toString());
        sessao.setCuidador(cuidador);
        sessao.setExpiraEm(LocalDateTime.now().plusHours(1));
        sessoes.saveAndFlush(sessao);
        return sessao.getTokenHash();
    }

    private MedicamentoDTO dados(int idosoId) {
        MedicamentoDTO dto = new MedicamentoDTO();
        dto.setNome("Remédio teste");
        dto.setDosagem("50mg");
        dto.setCategoria("Vitamina");
        dto.setHorario("08:00, 20:00");
        dto.setTipoUso("Contínuo");
        dto.setIdosoId(idosoId);
        dto.setQuantidadeAtual(10);
        dto.setQuantidadeMinima(5);
        return dto;
    }

    @Test
    void excluiIdosoComTodosOsDadosDependentesPelaApi() throws Exception {
        UsuarioIdoso tati = idoso();
        UsuarioIdoso outro = idoso();
        UsuarioCuidador cuidador = cuidador(tati);
        String sessao = sessao(cuidador);
        autorizar(tati, cuidador, true);
        autorizar(tati, cuidador, false);
        int remedio = medicamentoService.cadastrar(dados(tati.getId())).getId();
        int estoque = medicamentos.findById(remedio).orElseThrow().getEstoque().getId();
        int remedioOutro = medicamentoService.cadastrar(dados(outro.getId())).getId();
        Receita receita = new Receita();
        receita.setIdoso(tati);
        receitas.saveAndFlush(receita);

        MockMvcBuilders.webAppContextSetup(context).build()
                .perform(delete("/idoso/" + tati.getId())).andExpect(status().isOk());
        em.flush();
        em.clear();

        assertFalse(idosos.existsById(tati.getId()));
        assertFalse(medicamentos.existsById(remedio));
        assertFalse(estoques.existsById(estoque));
        assertFalse(receitas.existsById(receita.getId()));
        assertTrue(dispositivos.findAll().stream().noneMatch(d -> d.getIdoso().getId() == tati.getId()));
        assertNull(cuidadores.findById(cuidador.getId()).orElseThrow().getIdoso());
        assertTrue(sessoes.existsById(sessao));
        assertTrue(medicamentos.existsById(remedioOutro));
    }

    @Test
    void excluiCuidadorComSessoesEDispositivosSemExcluirOIdoso() throws Exception {
        UsuarioIdoso idoso = idoso();
        UsuarioCuidador cuidador = cuidador(idoso);
        String sessao = sessao(cuidador);
        autorizar(idoso, cuidador, true);
        autorizar(idoso, cuidador, false);

        MockMvcBuilders.webAppContextSetup(context).build()
                .perform(delete("/cuidador/" + cuidador.getId())).andExpect(status().isOk());
        em.flush();
        em.clear();
        assertFalse(cuidadores.existsById(cuidador.getId()));
        assertFalse(sessoes.existsById(sessao));
        assertTrue(dispositivos.findAll().stream().noneMatch(d -> d.getCuidador().getId() == cuidador.getId()));
        assertTrue(idosos.existsById(idoso.getId()));
    }

    @Test
    void excluiAdminSemExcluirContasDeOutrasPessoas() {
        Admin admin = admins.saveAndFlush(new Admin("Admin", 40, "admin-teste", "admin@teste.com", "senha123"));
        UsuarioIdoso idoso = idoso();
        UsuarioCuidador cuidador = cuidador(idoso);
        idoso.setAdmin(admin);
        cuidador.setAdmin(admin);
        em.flush();
        adminService.remover(admin.getId());
        em.flush();
        em.clear();
        assertFalse(admins.existsById(admin.getId()));
        assertNull(idosos.findById(idoso.getId()).orElseThrow().getAdmin());
        assertNull(cuidadores.findById(cuidador.getId()).orElseThrow().getAdmin());
    }

    @Test
    void apiAceitaRemedioSemContainerEEscolheLivre() throws Exception {
        UsuarioIdoso idoso = idoso();
        medicamentoService.cadastrar(dados(idoso.getId()));
        MockMvcBuilders.webAppContextSetup(context).build().perform(post("/medicamentos")
                .contentType(MediaType.APPLICATION_JSON).content("""
                {"nome":"Vitamina D","dosagem":"50mg","categoria":"Vitamina",
                 "horario":"08:00","tipoUso":"Contínuo","idosoId":%d,
                 "quantidadeAtual":10,"quantidadeMinima":5}
                """.formatted(idoso.getId())))
                .andExpect(status().isOk()).andExpect(jsonPath("$.containerNumero").value(2));
    }

    @Test
    void preservaContainerNaEdicaoMesmoComDispenserCheio() {
        UsuarioIdoso idoso = idoso();
        MedicamentoResponseDTO primeiro = medicamentoService.cadastrar(dados(idoso.getId()));
        for (int i = 2; i <= 8; i++) {
            assertEquals(i, medicamentoService.cadastrar(dados(idoso.getId())).getContainerNumero());
        }
        MedicamentoDTO dto = dados(idoso.getId());
        dto.setContainerNumero(8); // Clientes antigos não devem mover um remédio para um slot ocupado.
        dto.setNome("Nome atualizado");
        assertEquals(1, medicamentoService.atualizar(primeiro.getId(), dto).getContainerNumero());
        assertTrue(assertThrows(IllegalArgumentException.class,
                () -> medicamentoService.cadastrar(dados(idoso.getId()))).getMessage().contains("8 containers"));
    }

    @Test
    void reutilizaContainerLiberadoEExcluiSeuEstoque() {
        UsuarioIdoso idoso = idoso();
        MedicamentoResponseDTO primeiro = medicamentoService.cadastrar(dados(idoso.getId()));
        medicamentoService.cadastrar(dados(idoso.getId()));
        int estoque = medicamentos.findById(primeiro.getId()).orElseThrow().getEstoque().getId();
        medicamentoService.remover(primeiro.getId());
        em.flush();
        assertFalse(estoques.existsById(estoque));
        assertEquals(1, medicamentoService.cadastrar(dados(idoso.getId())).getContainerNumero());
    }

    @Test
    void trocaDeIdosoEscolheContainerDoDestino() {
        UsuarioIdoso origem = idoso();
        UsuarioIdoso destino = idoso();
        MedicamentoResponseDTO remedio = medicamentoService.cadastrar(dados(origem.getId()));
        medicamentoService.cadastrar(dados(destino.getId()));
        assertEquals(2, medicamentoService.atualizar(remedio.getId(), dados(destino.getId())).getContainerNumero());
    }

    @Test
    void permiteCadastroSemVinculoComContainerAutomatico() {
        assertEquals(1, medicamentoService.cadastrar(dados(0)).getContainerNumero());
        assertEquals(2, medicamentoService.cadastrar(dados(0)).getContainerNumero());
    }

    @Test
    void persisteReceitaComQuinhentosCaracteresEAgendaLonga() {
        Receita receita = new Receita();
        receita.setObservacoes("a".repeat(500));
        receitas.saveAndFlush(receita);
        MedicamentoDTO dto = dados(idoso().getId());
        dto.setHorario(IntStream.range(0, 48).mapToObj(i -> "%02d:%02d".formatted(i / 2, i % 2 * 30))
                .collect(Collectors.joining(", ")));
        int id = medicamentoService.cadastrar(dto).getId();
        em.flush();
        em.clear();
        assertEquals(500, receitas.findById(receita.getId()).orElseThrow().getObservacoes().length());
        assertEquals(dto.getHorario(), medicamentos.findById(id).orElseThrow().getHorario());
    }

    @Test
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    void falhaNaExclusaoDesfazTodasAsRemocoesEDesvinculos() {
        UsuarioIdoso idoso = idoso();
        UsuarioCuidador cuidador = cuidador(idoso);
        autorizar(idoso, cuidador, true);
        int remedio = medicamentoService.cadastrar(dados(idoso.getId())).getId();
        int estoque = medicamentos.findById(remedio).orElseThrow().getEstoque().getId();
        // Simula uma dependência desconhecida para verificar rollback da transação inteira.
        jdbc.execute("create table exclusao_guard_test (idoso_id integer references usuario_idoso(id))");
        try {
            jdbc.update("insert into exclusao_guard_test (idoso_id) values (?)", idoso.getId());
            assertThrows(DataIntegrityViolationException.class, () -> idosoService.remover(idoso.getId()));
            assertTrue(idosos.existsById(idoso.getId()));
            assertTrue(medicamentos.existsById(remedio));
            assertTrue(estoques.existsById(estoque));
            assertEquals(idoso.getId(), cuidadores.findById(cuidador.getId()).orElseThrow().getIdoso().getId());
            assertTrue(dispositivos.findAll().stream().anyMatch(d -> d.getIdoso().getId() == idoso.getId()));
        } finally {
            jdbc.execute("drop table exclusao_guard_test");
            cuidadorService.remover(cuidador.getId());
            idosoService.remover(idoso.getId());
        }
    }

    @Test
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    void cadastrosSimultaneosDoMesmoIdosoNaoRepetemContainer() throws Exception {
        UsuarioIdoso idoso = idoso();
        CountDownLatch iniciar = new CountDownLatch(1);
        try (var executor = Executors.newFixedThreadPool(2)) {
            var primeiro = executor.submit(() -> {
                iniciar.await();
                return medicamentoService.cadastrar(dados(idoso.getId())).getContainerNumero();
            });
            var segundo = executor.submit(() -> {
                iniciar.await();
                return medicamentoService.cadastrar(dados(idoso.getId())).getContainerNumero();
            });
            iniciar.countDown();
            assertNotEquals(primeiro.get(15, TimeUnit.SECONDS), segundo.get(15, TimeUnit.SECONDS));
        } finally {
            idosoService.remover(idoso.getId());
        }
    }
}
