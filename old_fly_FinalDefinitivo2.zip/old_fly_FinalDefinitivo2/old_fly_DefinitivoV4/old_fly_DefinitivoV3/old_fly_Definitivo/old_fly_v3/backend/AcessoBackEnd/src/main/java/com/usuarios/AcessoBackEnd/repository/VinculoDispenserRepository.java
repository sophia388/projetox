package com.usuarios.AcessoBackEnd.repository;

import com.usuarios.AcessoBackEnd.entity.VinculoDispenser;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import java.util.Optional;

public interface VinculoDispenserRepository extends JpaRepository<VinculoDispenser, Integer> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select v from VinculoDispenser v where v.id = 1")
    Optional<VinculoDispenser> bloquear();
}
