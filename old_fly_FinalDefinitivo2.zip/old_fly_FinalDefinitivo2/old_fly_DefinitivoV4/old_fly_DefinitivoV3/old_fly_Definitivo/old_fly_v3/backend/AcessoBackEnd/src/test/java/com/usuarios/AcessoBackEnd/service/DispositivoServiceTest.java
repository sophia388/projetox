package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.entity.DispositivoAutorizado;
import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.DispositivoAutorizadoRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DispositivoServiceTest {

    @Mock
    private DispositivoAutorizadoRepository dispositivoRepository;

    @Mock
    private UsuarioIdosoRepository idosoRepository;

    @InjectMocks
    private DispositivoService service;

    @Test
    void autorizaSomenteCuidadorVinculadoEArmazenaHash() {
        UsuarioIdoso idoso = idoso(42, true);
        UsuarioCuidador cuidador = new UsuarioCuidador();
        cuidador.setId(7);
        cuidador.setIdoso(idoso);
        when(idosoRepository.findById(42)).thenReturn(Optional.of(idoso));

        DispositivoService.CredencialDispositivo credencial = service.autorizar(cuidador, 42);

        ArgumentCaptor<DispositivoAutorizado> captor = ArgumentCaptor.forClass(DispositivoAutorizado.class);
        verify(dispositivoRepository).save(captor.capture());
        assertEquals(64, captor.getValue().getTokenHash().length());
        assertNotEquals(credencial.token(), captor.getValue().getTokenHash());
        assertSame(idoso, credencial.idoso());
    }

    @Test
    void rejeitaCuidadorNaoVinculado() {
        UsuarioIdoso idoso = idoso(42, true);
        UsuarioCuidador cuidador = new UsuarioCuidador();
        cuidador.setIdoso(idoso(99, true));
        when(idosoRepository.findById(42)).thenReturn(Optional.of(idoso));

        assertThrows(SecurityException.class, () -> service.autorizar(cuidador, 42));
        verify(dispositivoRepository, never()).save(any());
    }

    @Test
    void rejeitaAutorizacaoParaIdosoNormal() {
        UsuarioIdoso idoso = idoso(42, false);
        UsuarioCuidador cuidador = new UsuarioCuidador();
        cuidador.setIdoso(idoso);
        when(idosoRepository.findById(42)).thenReturn(Optional.of(idoso));

        assertThrows(IllegalArgumentException.class, () -> service.autorizar(cuidador, 42));
        verify(dispositivoRepository, never()).save(any());
    }

    private UsuarioIdoso idoso(int id, boolean debilitado) {
        UsuarioIdoso idoso = new UsuarioIdoso();
        idoso.setId(id);
        idoso.setDebilitado(debilitado);
        return idoso;
    }
}
