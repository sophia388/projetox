package com.usuarios.AcessoBackEnd.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "comando_dispenser", uniqueConstraints = @UniqueConstraint(
        name = "uk_dispenser_medicamento_horario", columnNames = {"medicamento_id", "agendado_para"}))
public class ComandoDispenser {
    public enum Estado { OFERECIDO, INICIADO, CONCLUIDO, SIMULADO, INCERTO, CONFERIDO, CANCELADO }

    @Id
    @Column(length = 36)
    private String id = UUID.randomUUID().toString();
    // Identificadores históricos, sem cascade: revalidamos o cadastro antes de mover o motor.
    @Column(name = "medicamento_id", nullable = false)
    private int medicamentoId;
    @Column(nullable = false)
    private int idosoId;
    @Column(nullable = false)
    private int motor;
    @Column(nullable = false)
    private int passos = 2048;
    @Column(nullable = false)
    private boolean simulacao;
    @Column(name = "agendado_para", nullable = false)
    private LocalDateTime agendadoPara;
    private LocalDateTime atualizadoEm;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Estado estado = Estado.OFERECIDO;

    public String getId() { return id; }
    public int getMedicamentoId() { return medicamentoId; }
    public void setMedicamentoId(int medicamentoId) { this.medicamentoId = medicamentoId; }
    public int getIdosoId() { return idosoId; }
    public void setIdosoId(int idosoId) { this.idosoId = idosoId; }
    public int getMotor() { return motor; }
    public void setMotor(int motor) { this.motor = motor; }
    public int getPassos() { return passos; }
    public boolean isSimulacao() { return simulacao; }
    public void setSimulacao(boolean simulacao) { this.simulacao = simulacao; }
    public LocalDateTime getAgendadoPara() { return agendadoPara; }
    public void setAgendadoPara(LocalDateTime agendadoPara) { this.agendadoPara = agendadoPara; }
    public LocalDateTime getAtualizadoEm() { return atualizadoEm; }
    public Estado getEstado() { return estado; }
    public void mudarEstado(Estado estado, LocalDateTime agora) { this.estado = estado; this.atualizadoEm = agora; }
}
