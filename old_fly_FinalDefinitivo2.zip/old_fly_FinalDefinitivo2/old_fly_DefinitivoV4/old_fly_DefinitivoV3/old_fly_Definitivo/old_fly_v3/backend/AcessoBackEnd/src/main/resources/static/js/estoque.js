function mostrarToast(mensagem, tipo = 'ok') {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.innerText = mensagem;
    toast.className = `toast show ${tipo}`;
    setTimeout(() => toast.className = 'toast', 3000);
}

function voltarDashboard() {
    window.location.href = '../index.html?dashboard=1';
}

function escapeHTML(valor) {
    return String(valor ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

document.addEventListener('DOMContentLoaded', async () => {
    const usuarioLogado = getLoggedUser();
    if (!usuarioLogado) {
        window.location.href = '../index.html';
        return;
    }

    if (usuarioLogado.perfil === 'idoso' && usuarioLogado.debilitado) {
        voltarDashboard();
        return;
    }

    const linkDashboard = document.getElementById('link-dashboard');
    const btnVoltarDashboard = document.getElementById('btn-voltar-dashboard');
    const btnSair = document.getElementById('btn-sair-estoque');

    linkDashboard.addEventListener('click', (e) => {
        e.preventDefault();
        voltarDashboard();
    });

    btnVoltarDashboard.addEventListener('click', voltarDashboard);

    btnSair.addEventListener('click', (e) => {
        e.preventDefault();
        if (window.OldFlyAlarm) OldFlyAlarm.stop();
        clearLoggedUser();
        window.location.href = '../index.html';
    });

    const urlParams = new URLSearchParams(window.location.search);
    const medicamentoId = urlParams.get('medicamentoId');

    if (!medicamentoId) {
        mostrarToast('Medicamento não informado.', 'erro');
        return;
    }

    let medicamento = null;

    const nomeRemedio = document.getElementById('nome-remedio');
    const tipoRemedio = document.getElementById('tipo-remedio');
    const detalhesRemedio = document.getElementById('detalhes-remedio');
    const containerRemedio = document.getElementById('container-remedio');
    const qtdAtual = document.getElementById('qtd-atual');
    const statusEstoque = document.getElementById('status-estoque');
    const infoMedicamento = document.querySelector('.remedio-detalhes .info-card');
    const antibioticNotice = document.getElementById('antibiotic-notice');
    const antibioticTreatmentInfo = document.getElementById('antibiotic-treatment-info');
    const horariosAtuais = document.getElementById('horarios-atuais');
    const inputHorarios = document.getElementById('input-horarios');
    const inputHorarioNovo = document.getElementById('input-horario-novo');
    const horariosLista = document.getElementById('estoque-horarios-lista');
    const intervaloHorarios = document.getElementById('estoque-intervalo');
    const btnAdicionarHorario = document.getElementById('btn-adicionar-horario');
    const btnGerarHorarios = document.getElementById('btn-gerar-horarios');
    const btnTestarAlarme = document.getElementById('btn-testar-alarme');
    const scheduleBuilder = inputHorarioNovo.closest('.schedule-builder');
    const inputMinimo = document.getElementById('input-minimo');
    const scheduleEditor = document.getElementById('schedule-editor');
    const btnEditarHorarios = document.getElementById('btn-editar-horarios');
    const btnSalvarHorarios = document.getElementById('btn-salvar-horarios');
    const btnCancelarHorarios = document.getElementById('btn-cancelar-horarios');
    const btnAdd = document.getElementById('btn-add-estoque');
    const inputQtd = document.getElementById('input-qtd');
    let horariosSelecionados = [];

    function medicamentoEhAntibiotico() {
        return typeof medicamento.antibiotico === 'boolean'
            ? medicamento.antibiotico
            : ehAntibiotico(medicamento.categoria);
    }

    function formatarData(dataISO) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(String(dataISO ?? ''))) return 'data não informada';
        const [ano, mes, dia] = dataISO.split('-');
        return `${dia}/${mes}/${ano}`;
    }

    function limparErroHorarios() {
        scheduleBuilder.classList.remove('has-error');
        inputHorarioNovo.removeAttribute('aria-invalid');
    }

    function mostrarErroHorarios(mensagem) {
        scheduleBuilder.classList.add('has-error');
        inputHorarioNovo.setAttribute('aria-invalid', 'true');
        mostrarToast(mensagem, 'erro');
        inputHorarioNovo.focus();
    }

    function renderizarHorariosEditor() {
        horariosSelecionados = OldFlySchedule.extrairHorarios(horariosSelecionados.join(', '));
        inputHorarios.value = OldFlySchedule.serializarHorarios(horariosSelecionados);

        if (!horariosSelecionados.length) {
            horariosLista.innerHTML = '<span class="schedule-empty"><i class="fa-regular fa-clock"></i> Nenhum horário adicionado</span>';
            return;
        }

        horariosLista.innerHTML = horariosSelecionados.map(horario => `
            <span class="schedule-chip" role="listitem">
                <i class="fa-regular fa-clock"></i> ${horario}
                <button type="button" data-horario="${horario}" aria-label="Remover o horário ${horario}" title="Remover ${horario}">
                    <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                </button>
            </span>
        `).join('');

        horariosLista.querySelectorAll('button[data-horario]').forEach(botao => {
            botao.addEventListener('click', () => {
                horariosSelecionados = horariosSelecionados.filter(horario => horario !== botao.dataset.horario);
                renderizarHorariosEditor();
            });
        });
    }

    function definirHorariosEditor(valor) {
        horariosSelecionados = OldFlySchedule.extrairHorarios(valor || '');
        limparErroHorarios();
        renderizarHorariosEditor();
    }

    function adicionarHorario() {
        const horario = OldFlySchedule.normalizarHorario(inputHorarioNovo.value);
        if (!horario) {
            mostrarErroHorarios('Escolha um horário válido no relógio.');
            return;
        }

        horariosSelecionados = [...horariosSelecionados, horario];
        limparErroHorarios();
        renderizarHorariosEditor();
        inputHorarioNovo.value = '';
        inputHorarioNovo.focus();
    }

    function gerarHorarios() {
        const gerados = OldFlySchedule.gerarHorarios(inputHorarioNovo.value, intervaloHorarios.value);
        if (!gerados.length) {
            mostrarErroHorarios('Informe o primeiro horário e escolha um intervalo para gerar o dia.');
            return;
        }

        horariosSelecionados = gerados;
        limparErroHorarios();
        renderizarHorariosEditor();
        mostrarToast(`${gerados.length} horário(s) gerado(s) automaticamente.`);
    }

    function atualizarStatusUI() {
        const status = classificarEstoque(
            medicamento.quantidadeAtual,
            medicamento.quantidadeMinima,
            medicamentoEhAntibiotico()
        );
        const classesStatus = ['stock-gray', 'stock-red', 'stock-yellow', 'stock-green', 'stock-blue'];

        statusEstoque.innerText = status.rotulo;
        statusEstoque.classList.remove(...classesStatus);
        statusEstoque.classList.add(`stock-${status.cor}`);
        containerRemedio.classList.remove(...classesStatus);
        containerRemedio.classList.add(`stock-${status.cor}`);
        infoMedicamento.classList.remove(...classesStatus);
        infoMedicamento.classList.add(`stock-${status.cor}`);
    }

    function renderMedicamento() {
        nomeRemedio.innerText = medicamento.nome;
        tipoRemedio.innerText = medicamento.tipoUso;
        tipoRemedio.className = `tag ${medicamento.tipoUso === 'Programado' ? 'tag-yellow' : 'tag-green'}`;
        detalhesRemedio.innerText = `${medicamento.categoria} • ${medicamento.dosagem} • Idoso: ${medicamento.nomeIdoso}`;
        containerRemedio.innerText = `#${medicamento.containerNumero}`;
        qtdAtual.innerText = medicamento.quantidadeAtual;
        const horariosNormalizados = OldFlySchedule.serializarHorarios(
            OldFlySchedule.extrairHorarios(medicamento.horario || '')
        );
        horariosAtuais.innerHTML = `<i class="fa-regular fa-clock"></i> ${escapeHTML(horariosNormalizados || 'Nenhum horário válido')}`;
        inputHorarioNovo.value = '';
        intervaloHorarios.value = '';
        definirHorariosEditor(medicamento.horario);
        inputMinimo.value = medicamento.quantidadeMinima;
        if (medicamentoEhAntibiotico()) {
            antibioticTreatmentInfo.innerText = `Duração de ${medicamento.duracaoTratamentoDias || 5} dias. Exclusão automática prevista para ${formatarData(medicamento.dataExclusao)}.`;
            antibioticNotice.style.display = 'flex';
        } else {
            antibioticNotice.style.display = 'none';
        }
        atualizarStatusUI();
    }

    async function carregarMedicamento() {
        try {
            medicamento = await buscarMedicamentoBackend(medicamentoId);
            renderMedicamento();
        } catch (erro) {
            mostrarToast(mensagemDaOperacao(erro, 'Não foi possível carregar o remédio. Atualize a página.'), 'erro');
        }
    }

    btnAdicionarHorario.addEventListener('click', adicionarHorario);
    btnGerarHorarios.addEventListener('click', gerarHorarios);
    btnTestarAlarme.addEventListener('click', () => {
        if (window.OldFlyAlarm && medicamento) OldFlyAlarm.testar(medicamento);
    });
    inputHorarioNovo.addEventListener('change', limparErroHorarios);
    inputHorarioNovo.addEventListener('keydown', (e) => {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        adicionarHorario();
    });

    btnEditarHorarios.addEventListener('click', () => {
        scheduleEditor.style.display = 'block';
        inputHorarioNovo.focus();
    });

    btnCancelarHorarios.addEventListener('click', () => {
        scheduleEditor.style.display = 'none';
        renderMedicamento();
    });

    btnSalvarHorarios.addEventListener('click', async () => {
        if (!medicamento || btnSalvarHorarios.disabled) return;
        const novoHorario = inputHorarios.value;
        const novoMinimo = Number(inputMinimo.value || 5);

        if (!horariosSelecionados.length || !novoHorario) {
            mostrarErroHorarios('Adicione pelo menos um horário antes de salvar.');
            return;
        }

        btnSalvarHorarios.disabled = true;
        try {
            medicamento = await salvarMedicamentoBackend({
                ...medicamento,
                horario: novoHorario,
                quantidadeMinima: novoMinimo,
                quantidadeAtual: medicamento.quantidadeAtual,
                idosoId: medicamento.idosoId || 0
            }, medicamento.id);
            renderMedicamento();
            if (window.OldFlyAlarm) {
                try {
                    OldFlyAlarm.setMedicamentos(await buscarMedicamentosBackend());
                } catch (erro) {
                    OldFlyAlarm.setMedicamentos([medicamento]);
                }
                OldFlyAlarm.verificarAgora();
            }
            scheduleEditor.style.display = 'none';
            mostrarToast('Horários e mínimo atualizados.');
        } catch (erro) {
            mostrarToast(mensagemDaOperacao(erro, 'Não foi possível atualizar os horários.'), 'erro');
        } finally {
            btnSalvarHorarios.disabled = false;
        }
    });

    btnAdd.addEventListener('click', async () => {
        if (!medicamento || btnAdd.disabled) return;
        const valorAdicional = Number(inputQtd.value);
        if (!Number.isInteger(valorAdicional) || valorAdicional <= 0) {
            mostrarToast('Insira uma quantidade válida.', 'erro');
            return;
        }

        const novoTotal = Number(medicamento.quantidadeAtual || 0) + valorAdicional;
        if (novoTotal > 99999) {
            mostrarToast('O estoque pode ter no máximo 99999 unidades.', 'erro');
            return;
        }

        btnAdd.disabled = true;
        try {
            medicamento = await atualizarEstoqueBackend(medicamento.id, novoTotal, medicamento.quantidadeMinima);
            renderMedicamento();
            inputQtd.value = '';
            mostrarToast(`${valorAdicional} unidades adicionadas ao estoque.`);
        } catch (erro) {
            mostrarToast(mensagemDaOperacao(erro, 'Não foi possível atualizar o estoque.'), 'erro');
        } finally {
            btnAdd.disabled = false;
        }
    });

    const farmaciasMock = [
        { nome: 'Ultrafarma', preco: 10.99 },
        { nome: 'Drogasil', preco: 12.50 },
        { nome: 'Droga Raia', preco: 13.20 },
        { nome: 'Pague Menos', preco: 14.90 }
    ];

    farmaciasMock.sort((a, b) => a.preco - b.preco);
    document.getElementById('lista-farmacias').innerHTML = farmaciasMock.map(f => `
        <div class="pharmacy-item">
            <span class="pharmacy-name"><i class="fa-solid fa-store"></i> ${f.nome}</span>
            <span class="pharmacy-price">R$ ${f.preco.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
        </div>
    `).join('');

    await carregarMedicamento();
    if (window.OldFlyAlarm) OldFlyAlarm.start();
});
