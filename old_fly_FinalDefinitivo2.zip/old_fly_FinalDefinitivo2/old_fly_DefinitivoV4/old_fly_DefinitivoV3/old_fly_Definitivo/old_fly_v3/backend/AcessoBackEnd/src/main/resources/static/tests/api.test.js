'use strict';

const assert = require('node:assert/strict');
const { test } = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function api(fetch) {
    const contexto = vm.createContext({
        window: { location: { hostname: 'localhost' } },
        fetch, AbortController, setTimeout, clearTimeout
    });
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../js/auth.js'), 'utf8'), contexto);
    return contexto;
}

function resposta(status, corpo = '') {
    return { status, ok: status >= 200 && status < 300, text: async () => corpo };
}

test('salvar remédio omite container e mantém o zero para validação do estoque mínimo', async () => {
    let enviado;
    const contexto = api(async (url, opcoes) => {
        enviado = JSON.parse(opcoes.body);
        return resposta(200, '{"id":1,"containerNumero":3}');
    });
    const salvo = await contexto.salvarMedicamentoBackend({ nome: 'Vitamina', containerNumero: 1, quantidadeMinima: 0 });
    assert.equal(Object.hasOwn(enviado, 'containerNumero'), false);
    assert.equal(enviado.quantidadeMinima, 0);
    assert.equal(salvo.containerNumero, 3);
});

test('validação exibe a mensagem específica recebida do servidor', async () => {
    const contexto = api(async () => resposta(400, JSON.stringify({
        message: 'Os 8 containers estão ocupados.', errors: { nome: 'Confira o nome.' }
    })));
    await assert.rejects(contexto.requestBackend('/medicamentos'), erro => {
        assert.equal(erro.status, 400);
        assert.equal(contexto.mensagemDaOperacao(erro), 'Os 8 containers estão ocupados.');
        assert.equal(erro.errors.nome, 'Confira o nome.');
        return true;
    });
});

test('falha interna não apresenta SQL ou detalhes técnicos', async () => {
    const contexto = api(async () => resposta(500, '{"message":"SQL JDBC constraint stacktrace"}'));
    await assert.rejects(contexto.requestBackend('/idoso/1', { method: 'DELETE' }), erro => {
        assert.equal(erro.status, 500);
        assert.doesNotMatch(erro.message, /SQL|JDBC|stacktrace|backend/);
        return true;
    });
});

test('exclusão aceita resposta vazia e não tenta decodificar JSON', async () => {
    const contexto = api(async () => resposta(204));
    assert.equal(await contexto.excluirUsuarioBackend(1, 'idoso'), null);
});

test('falha de conexão não repete uma gravação e orienta conferir o resultado', async () => {
    let chamadas = 0;
    const contexto = api(async () => { chamadas++; throw new TypeError('Failed to fetch'); });
    await assert.rejects(contexto.excluirUsuarioBackend(1, 'idoso'), erro => {
        assert.equal(erro.status, 0);
        assert.match(erro.message, /conferir se a operação foi concluída/);
        return true;
    });
    assert.equal(chamadas, 1);
});

test('login diferencia senha incorreta de serviço indisponível e mantém cookies', async () => {
    let opcoes;
    const contexto = api(async (url, dados) => { opcoes = dados; return resposta(401); });
    assert.equal(await contexto.loginBackend('tati', 'senha'), null);
    assert.equal(opcoes.credentials, 'include');
    contexto.fetch = async () => resposta(503);
    await assert.rejects(contexto.loginBackend('tati', 'senha'), erro => erro.status === 503);
});

function formulario({ buscarUsuarios, salvar } = {}) {
    const elementos = new Map();
    function elemento(id) {
        if (!elementos.has(id)) elementos.set(id, {
            value: '', innerText: '', innerHTML: '', checked: false, disabled: false,
            style: {}, dataset: {}, classList: { add() {}, remove() {} }, eventos: {},
            addEventListener(evento, callback) { this.eventos[evento] = callback; },
            closest() { return elemento('schedule'); },
            querySelector() { return elemento('salvar'); }, querySelectorAll() { return []; },
            removeAttribute() {}, setAttribute() {}, focus() {}
        });
        return elementos.get(id);
    }
    let iniciar;
    const mensagens = new Map();
    const contexto = vm.createContext({
        document: { getElementById: elemento, addEventListener(evento, callback) { iniciar = callback; } },
        window: { location: { search: '', href: '' } }, URLSearchParams,
        getLoggedUser: () => ({ id: 1, perfil: 'admin' }),
        buscarUsuariosBackend: buscarUsuarios || (async () => [{ id: 2, perfil: 'idoso', nome: 'Tati' }]),
        salvarMedicamentoBackend: salvar,
        classificarEstoque: () => ({ cor: 'gray', rotulo: 'Acabou' }),
        ehAntibiotico: () => false,
        mensagemDaOperacao: erro => erro.message,
        OldFlySchedule: require('../js/schedule.js'),
        sessionStorage: { setItem: (chave, valor) => mensagens.set(chave, valor) },
        setTimeout: () => 0
    });
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../js/medicamento.js'), 'utf8'), contexto);
    return { iniciar, elemento, mensagens, contexto };
}

test('formulário bloqueia envio duplicado e confirma o container atribuído', async () => {
    let concluir;
    let chamadas = 0;
    const tela = formulario({ salvar: () => { chamadas++; return new Promise(resolve => { concluir = resolve; }); } });
    await tela.iniciar();
    tela.elemento('medicamento-horario-novo').value = '08:00';
    tela.elemento('btn-adicionar-horario').eventos.click();
    const enviar = () => tela.elemento('form-medicamento').eventos.submit({ preventDefault() {} });
    const primeira = enviar();
    await enviar();
    assert.equal(chamadas, 1);
    assert.equal(tela.elemento('salvar').disabled, true);
    concluir({ id: 1, containerNumero: 4 });
    await primeira;
    assert.match(tela.mensagens.get('oldfly_medicamento_salvo'), /container #4/);
});

test('falha ao carregar usuários bloqueia o cadastro sem usar contas fictícias', async () => {
    const tela = formulario({ buscarUsuarios: async () => { throw new Error('Conexão indisponível.'); } });
    await tela.iniciar();
    assert.equal(tela.elemento('salvar').disabled, true);
    assert.equal(tela.elemento('medicamento-form-msg').innerText, 'Conexão indisponível.');
});

test('formulário preserva dados e mostra a validação ao falhar o salvamento', async () => {
    const tela = formulario({ salvar: async () => { throw new Error('Os 8 containers estão ocupados.'); } });
    await tela.iniciar();
    tela.elemento('medicamento-nome').value = 'Vitamina D';
    tela.elemento('medicamento-horario-novo').value = '08:00';
    tela.elemento('btn-adicionar-horario').eventos.click();
    await tela.elemento('form-medicamento').eventos.submit({ preventDefault() {} });
    assert.equal(tela.elemento('medicamento-nome').value, 'Vitamina D');
    assert.equal(tela.elemento('medicamento-form-msg').innerText, 'Os 8 containers estão ocupados.');
    assert.equal(tela.elemento('salvar').disabled, false);
    assert.equal(tela.mensagens.size, 0);
});
