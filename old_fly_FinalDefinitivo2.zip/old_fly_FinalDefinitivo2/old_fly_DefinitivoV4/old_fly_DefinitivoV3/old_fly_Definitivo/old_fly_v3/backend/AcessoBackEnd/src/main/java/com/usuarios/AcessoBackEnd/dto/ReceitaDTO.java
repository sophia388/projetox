package com.usuarios.AcessoBackEnd.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class ReceitaDTO {

    @NotBlank(message = "O nome do médico é obrigatório")
    @Size(min = 2, max = 100, message = "O nome do médico deve ter entre 2 e 100 caracteres")
    @Pattern(regexp = "^[A-Za-zÀ-ÖØ-öø-ÿ'\\-\\.\\s]+$", message = "O nome do médico deve conter apenas letras, pontos e espaços")
    private String medico;

    @NotBlank(message = "A data da receita é obrigatória")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "Formato de data inválido (deve ser AAAA-MM-DD)")
    private String dataReceita;

    @NotBlank(message = "Os medicamentos da receita são obrigatórios")
    @Size(min = 2, max = 255, message = "A lista de medicamentos deve ter entre 2 e 255 caracteres")
    private String medicamentos;

    @Size(max = 500, message = "As observações devem ter no máximo 500 caracteres")
    private String observacoes;

    @Size(max = 255, message = "O nome do arquivo deve ter no máximo 255 caracteres")
    private String arquivoNome;

    @Min(value = 0, message = "Idoso vinculado inválido")
    private int idosoId;

    public String getMedico() { return medico; }
    public void setMedico(String medico) { this.medico = medico != null ? medico.trim() : null; }
    public String getDataReceita() { return dataReceita; }
    public void setDataReceita(String dataReceita) { this.dataReceita = dataReceita != null ? dataReceita.trim() : null; }
    public String getMedicamentos() { return medicamentos; }
    public void setMedicamentos(String medicamentos) { this.medicamentos = medicamentos != null ? medicamentos.trim() : null; }
    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes != null ? observacoes.trim() : null; }
    public String getArquivoNome() { return arquivoNome; }
    public void setArquivoNome(String arquivoNome) { this.arquivoNome = arquivoNome != null ? arquivoNome.trim() : null; }
    public int getIdosoId() { return idosoId; }
    public void setIdosoId(int idosoId) { this.idosoId = idosoId; }
}

