package com.usuarios.AcessoBackEnd.dto;

public class UsuarioSistemaDTO {
    private int id;
    private String nome;
    private int idade;
    private String usuario;
    private String email;
    private String perfil;
    private String descricao;
    private String acesso;
    private Integer idosoId;
    private String nomeIdoso;
    private boolean debilitado;

    public UsuarioSistemaDTO(int id, String nome, int idade, String usuario, String email, String perfil,
                             String descricao, String acesso, Integer idosoId, String nomeIdoso,
                             boolean debilitado) {
        this.id = id;
        this.nome = nome;
        this.idade = idade;
        this.usuario = usuario;
        this.email = email;
        this.perfil = perfil;
        this.descricao = descricao;
        this.acesso = acesso;
        this.idosoId = idosoId;
        this.nomeIdoso = nomeIdoso;
        this.debilitado = debilitado;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public int getIdade() { return idade; }
    public String getUsuario() { return usuario; }
    public String getEmail() { return email; }
    public String getPerfil() { return perfil; }
    public String getDescricao() { return descricao; }
    public String getAcesso() { return acesso; }
    public Integer getIdosoId() { return idosoId; }
    public String getNomeIdoso() { return nomeIdoso; }
    public boolean isDebilitado() { return debilitado; }
}
