package com.usuarios.AcessoBackEnd.repository;

import com.usuarios.AcessoBackEnd.entity.SessaoCuidador;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.Optional;

public interface SessaoCuidadorRepository extends JpaRepository<SessaoCuidador, String> {
    void deleteByCuidadorId(int cuidadorId);
    Optional<SessaoCuidador> findByTokenHashAndExpiraEmAfter(String tokenHash, LocalDateTime agora);
}
