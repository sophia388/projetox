document.addEventListener('DOMContentLoaded', () => {
    const loginScreen = document.getElementById('login-screen');
    const authWrapper = document.querySelector('.auth-wrapper');
    const appAreas = document.querySelectorAll('.app-area');
    const loginForm = document.getElementById('login-form');
    const loginUser = document.getElementById('login-user');
    const loginPass = document.getElementById('login-pass');
    const loginError = document.getElementById('login-error');
    const loginCard = document.querySelector('.login-card:not(.register-card)');
    const registerCard = document.querySelector('.register-card');
    const btnShowRegister = document.getElementById('btn-show-register');
    const btnShowLogin = document.getElementById('btn-show-login');
    const assistedLogin = document.getElementById('assisted-login');
    const btnAssistedLogin = document.getElementById('btn-assisted-login');
    const assistedAccountName = document.getElementById('assisted-account-name');

    const registerForm = document.getElementById('register-form');
    const registerPerfil = document.getElementById('register-perfil');
    const registerNome = document.getElementById('register-nome');
    const registerIdade = document.getElementById('register-idade');
    const registerEmail = document.getElementById('register-email');
    const registerUsuario = document.getElementById('register-usuario');
    const registerSenha = document.getElementById('register-senha');
    const registerCampoIdoso = document.getElementById('register-campo-idoso');
    const registerIdosoId = document.getElementById('register-idoso-id');
    const registerCampoTipoIdoso = document.getElementById('register-campo-tipo-idoso');
    const registerTipoIdoso = document.getElementById('register-tipo-idoso');
    const registerMessage = document.getElementById('register-message');

    const profileName = document.getElementById('profile-name');
    const profileRole = document.getElementById('profile-role');
    const btnLogout = document.getElementById('btn-logout');

    const navDashboard = document.getElementById('nav-dashboard');
    const navReceitas = document.getElementById('nav-receitas');
    const navUsuarios = document.getElementById('nav-usuarios');
    const navSobre = document.getElementById('nav-sobre');

    const viewDashboard = document.getElementById('view-dashboard');
    const viewReceitasVazia = document.getElementById('view-receitas-vazia');
    const viewReceitasForm = document.getElementById('view-receitas-form');
    const viewUsuarios = document.getElementById('view-usuarios');
    const viewSobre = document.getElementById('view-sobre');

    const dispenserGrid = document.getElementById('dispenser-grid');
    const remediosList = document.getElementById('remedios-list');
    const btnNovoMedicamento = document.getElementById('btn-novo-medicamento');
    const btnAutorizarDispositivo = document.getElementById('btn-autorizar-dispositivo');

    const btnNovaReceita = document.getElementById('btn-nova-receita');
    const btnAddPrimeira = document.getElementById('btn-add-primeira');
    const btnCancelar = document.getElementById('btn-cancelar');
    const receitasList = document.getElementById('receitas-list');
    const receitasEmpty = document.getElementById('receitas-empty');
    const receitaForm = document.getElementById('form-receita');
    const receitaFormMsg = document.getElementById('receita-form-msg');

    const adminUsersList = document.getElementById('admin-users-list');
    const adminUserForm = document.getElementById('admin-user-form');
    const adminFormTitle = document.getElementById('admin-form-title');
    const adminFormMsg = document.getElementById('admin-form-msg');
    const adminUserPerfil = document.getElementById('admin-user-perfil');
    const adminCampoIdoso = document.getElementById('admin-campo-idoso');
    const adminUserIdosoId = document.getElementById('admin-user-idoso-id');
    const adminCampoTipoIdoso = document.getElementById('admin-campo-tipo-idoso');
    const adminUserTipoIdoso = document.getElementById('admin-user-tipo-idoso');
    const filtroUsuarios = document.getElementById('filtro-usuarios');
    const btnAdminLimpar = document.getElementById('btn-admin-limpar');

    let usuariosCache = [];
    let medicamentosCache = [];
    let receitasCache = [];
    let painelAlarmesTimer = null;
    let contaAssistidaDisponivel = null;

    function escapeHTML(valor) {
        return String(valor ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function doisDigitos(valor) {
        return String(valor).padStart(2, '0');
    }

    function atualizarBotaoContaAssistida() {
        if (!assistedLogin || !assistedAccountName) return;
        assistedLogin.style.display = contaAssistidaDisponivel ? 'block' : 'none';
        assistedAccountName.textContent = contaAssistidaDisponivel
            ? contaAssistidaDisponivel.nome
            : 'Conta assistida';
    }

    function medicamentosDoPainelAlarmes() {
        const usuario = getViewingUser();
        if (!usuario) return [];
        if (usuario.perfil === 'admin') return medicamentosCache;

        const idosoId = usuario.perfil === 'idoso' ? usuario.id : usuario.idosoId;
        if (idosoId == null) return [];
        return medicamentosCache.filter(medicamento => String(medicamento.idosoId) === String(idosoId));
    }

    function descricaoDataAlarme(evento, agora) {
        const hoje = OldFlySchedule.dataLocalISO(agora);
        const amanhaData = new Date(agora.getFullYear(), agora.getMonth(), agora.getDate() + 1);
        const amanha = OldFlySchedule.dataLocalISO(amanhaData);
        const dataEvento = OldFlySchedule.dataLocalISO(evento.data);
        const prefixo = dataEvento === hoje
            ? 'Hoje'
            : dataEvento === amanha
                ? 'Amanhã'
                : evento.data.toLocaleDateString('pt-BR');
        return `${prefixo} às ${evento.horario}`;
    }

    function formatarContagemRegressiva(evento) {
        if (evento.tocandoAgora) return 'Tocando agora';
        const totalSegundos = Math.max(0, Math.ceil(evento.emMs / 1000));
        const horas = Math.floor(totalSegundos / 3600);
        const minutos = Math.floor((totalSegundos % 3600) / 60);
        const segundos = totalSegundos % 60;
        return `${doisDigitos(horas)}:${doisDigitos(minutos)}:${doisDigitos(segundos)}`;
    }

    function periodoDoHorario(horario) {
        const hora = Number(String(horario || '').split(':')[0]);
        if (!Number.isFinite(hora)) return '--';
        if (hora >= 5 && hora < 12) return 'Manhã';
        if (hora >= 12 && hora < 18) return 'Tarde';
        return 'Noite';
    }

    function frequenciaDiaria(horarios) {
        const lista = window.OldFlySchedule
            ? OldFlySchedule.extrairHorarios(horarios || '')
            : [];
        const quantidade = lista.length;
        return quantidade ? `${quantidade} por dia` : 'Sem horários';
    }

    function atualizarPainelAlarmes() {
        const agora = new Date();
        document.querySelectorAll('.medicine-next-alarm[data-med-id]').forEach(painel => {
            const medicamento = medicamentosDoPainelAlarmes().find(
                item => String(item.id) === String(painel.dataset.medId)
            );
            const evento = medicamento
                ? OldFlySchedule.proximosAlarmes([medicamento], agora, 1)[0]
                : null;
            const contador = painel.querySelector('strong');
            const descricao = painel.querySelector('small');
            const periodo = painel.closest('.dispenser-card')?.querySelector('.medicine-period strong');
            if (!evento) {
                contador.textContent = '--:--:--';
                descricao.textContent = 'Sem horário programado';
                if (periodo) periodo.textContent = '--';
                return;
            }
            contador.textContent = formatarContagemRegressiva(evento);
            descricao.textContent = descricaoDataAlarme(evento, agora);
            if (periodo) periodo.textContent = periodoDoHorario(evento.horario);
        });
    }

    function iniciarPainelAlarmes() {
        if (painelAlarmesTimer) clearInterval(painelAlarmesTimer);
        atualizarPainelAlarmes();
        painelAlarmesTimer = setInterval(atualizarPainelAlarmes, 1000);
    }

    function pararPainelAlarmes() {
        if (!painelAlarmesTimer) return;
        clearInterval(painelAlarmesTimer);
        painelAlarmesTimer = null;
    }

    function mostrarToast(mensagem, tipo = 'ok') {
        const toast = document.getElementById('toast');
        if (!toast) return;
        toast.innerText = mensagem;
        toast.className = `toast show ${tipo}`;
        setTimeout(() => toast.className = 'toast', 3000);
    }

    function confirmarAcao(mensagem, callback) {
        const modal = document.getElementById('confirm-modal');
        const texto = document.getElementById('confirm-message');
        const cancelar = document.getElementById('confirm-cancel');
        const confirmar = document.getElementById('confirm-ok');
        if (!modal || !texto || !cancelar || !confirmar) return;

        texto.innerText = mensagem;
        modal.style.display = 'flex';

        const fechar = () => {
            modal.style.display = 'none';
            cancelar.onclick = null;
            confirmar.onclick = null;
        };

        cancelar.onclick = fechar;
        confirmar.onclick = async () => {
            fechar();
            await callback();
        };
    }

    function hideAllViews() {
        [viewDashboard, viewReceitasVazia, viewReceitasForm, viewUsuarios, viewSobre].forEach(view => {
            if (view) view.style.display = 'none';
        });
    }

    function removeActiveNav() {
        [navDashboard, navReceitas, navUsuarios, navSobre].forEach(nav => {
            if (nav) nav.classList.remove('active');
        });
    }

    function showLoginCard() {
        authWrapper.classList.remove('register-mode');
        loginCard.style.display = 'block';
        registerCard.style.display = 'none';
        atualizarBotaoContaAssistida();
    }

    async function showRegisterCard() {
        authWrapper.classList.add('register-mode');
        loginCard.style.display = 'none';
        registerCard.style.display = 'block';
        await carregarUsuariosCache();
        preencherSelectIdosos(registerIdosoId);
    }

    function showLogin() {
        pararPainelAlarmes();
        loginScreen.style.display = 'flex';
        appAreas.forEach(area => area.style.display = 'none');
        showLoginCard();
        atualizarBotaoContaAssistida();
    }

    async function showApp() {
        loginScreen.style.display = 'none';
        appAreas.forEach(area => area.style.display = '');
        await carregarUsuariosCache();
        updateProfile();
        configurarPermissoes();
        await renderDashboard();
        iniciarPainelAlarmes();
        if (window.OldFlyAlarm) {
            OldFlyAlarm.start();
            atualizarPainelAlarmes();
        }
        showDashboard();
        const mensagemMedicamento = sessionStorage.getItem('oldfly_medicamento_salvo');
        if (mensagemMedicamento) {
            sessionStorage.removeItem('oldfly_medicamento_salvo');
            mostrarToast(mensagemMedicamento);
        }
    }

    function configurarPermissoes() {
        const loggedUser = getLoggedUser();
        const podeGerenciar = loggedUser && loggedUser.perfil !== 'idoso';
        const modoDebilitado = Boolean(loggedUser && loggedUser.perfil === 'idoso' && loggedUser.debilitado);
        document.body.classList.toggle('modo-debilitado', modoDebilitado);
        document.querySelectorAll('.can-manage').forEach(item => {
            item.style.display = podeGerenciar ? '' : 'none';
        });
        if (btnAutorizarDispositivo) {
            const podeAutorizar = loggedUser && loggedUser.perfil === 'cuidador'
                && loggedUser.debilitado && loggedUser.idosoId;
            btnAutorizarDispositivo.style.display = podeAutorizar ? '' : 'none';
            if (podeAutorizar) {
                const autorizadoParaEsteIdoso = contaAssistidaDisponivel
                    && String(contaAssistidaDisponivel.id) === String(loggedUser.idosoId);
                btnAutorizarDispositivo.innerHTML = autorizadoParaEsteIdoso
                    ? '<i class="fa-solid fa-lock"></i> Bloquear acesso assistido neste dispositivo'
                    : '<i class="fa-solid fa-mobile-screen-button"></i> Autorizar este dispositivo para o idoso';
                btnAutorizarDispositivo.classList.toggle('danger', Boolean(autorizadoParaEsteIdoso));
            }
        }
    }

    function updateProfile() {
        const loggedUser = getLoggedUser();
        const viewingUser = getViewingUser();
        if (!loggedUser || !viewingUser) return;

        const viewingText = loggedUser.perfil === 'admin' && loggedUser.usuario !== viewingUser.usuario
            ? ` vendo: ${viewingUser.nome}`
            : '';

        profileName.innerText = `${loggedUser.nome}${viewingText}`;
        profileRole.innerText = roleLabel(loggedUser.perfil);
        navUsuarios.style.display = loggedUser.perfil === 'admin' ? 'flex' : 'none';
    }

    function showDashboard() {
        removeActiveNav();
        hideAllViews();
        navDashboard.classList.add('active');
        viewDashboard.style.display = 'block';
    }

    function showSobre() {
        removeActiveNav();
        hideAllViews();
        navSobre.classList.add('active');
        viewSobre.style.display = 'block';
    }

    async function carregarUsuariosCache() {
        try {
            usuariosCache = await buscarUsuariosBackend();
        } catch (erro) {
            usuariosCache = [];
            mostrarToast(mensagemDaOperacao(erro, 'Não foi possível carregar os usuários. Atualize a página.'), 'erro');
        }
        return usuariosCache;
    }

    function preencherSelectIdosos(selectElement, selecionado = 0) {
        if (!selectElement) return;
        const idosos = usuariosCache.filter(user => user.perfil === 'idoso');
        selectElement.innerHTML = '<option value="0">Sem idoso vinculado</option>' + idosos.map(idoso => `
            <option value="${idoso.id}" ${Number(selecionado) === Number(idoso.id) ? 'selected' : ''}>${escapeHTML(idoso.nome)}</option>
        `).join('');
    }

    function atualizarCampoIdosoResponsavel() {
        if (registerCampoIdoso) {
            registerCampoIdoso.style.display = registerPerfil.value === 'cuidador' ? 'block' : 'none';
        }
        if (adminCampoIdoso) {
            adminCampoIdoso.style.display = adminUserPerfil.value === 'cuidador' ? 'block' : 'none';
        }
        if (registerCampoTipoIdoso) {
            registerCampoTipoIdoso.style.display = registerPerfil.value === 'idoso' ? 'block' : 'none';
        }
        if (adminCampoTipoIdoso) {
            adminCampoTipoIdoso.style.display = adminUserPerfil.value === 'idoso' ? 'block' : 'none';
        }
    }

    function getPrimeiroIdosoId() {
        const viewingUser = getViewingUser();
        if (viewingUser && viewingUser.perfil === 'idoso') return viewingUser.id;
        if (viewingUser && viewingUser.perfil === 'cuidador' && viewingUser.idosoId) return viewingUser.idosoId;
        const idoso = usuariosCache.find(user => user.perfil === 'idoso');
        return idoso ? idoso.id : 0;
    }

    function medicamentoEhAntibiotico(medicamento) {
        return typeof medicamento?.antibiotico === 'boolean'
            ? medicamento.antibiotico
            : ehAntibiotico(medicamento?.categoria);
    }

    function formatarData(dataISO) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(String(dataISO ?? ''))) return 'data não informada';
        const [ano, mes, dia] = dataISO.split('-');
        return `${dia}/${mes}/${ano}`;
    }

    function statusEstoque(medicamento) {
        return classificarEstoque(
            medicamento.quantidadeAtual,
            medicamento.quantidadeMinima,
            medicamentoEhAntibiotico(medicamento)
        );
    }

    function tagTipo(tipoUso) {
        if (tipoUso === 'Contínuo') return 'tag-green';
        if (tipoUso === 'Programado') return 'tag-yellow';
        return 'tag-gray';
    }

    async function renderDashboard() {
        try {
            medicamentosCache = await buscarMedicamentosBackend();
        } catch (erro) {
            medicamentosCache = [];
            mostrarToast(mensagemDaOperacao(erro, 'Não foi possível carregar os remédios.'), 'erro');
        }

        if (window.OldFlyAlarm) OldFlyAlarm.setMedicamentos(medicamentosCache);
        atualizarPainelAlarmes();

        const medicamentosVisiveis = medicamentosDoPainelAlarmes();

        if (!medicamentosVisiveis.length) {
            dispenserGrid.innerHTML = '<div class="empty-state-card full-width"><p>Nenhum remédio cadastrado no banco.</p></div>';
            remediosList.innerHTML = '';
            return;
        }

        const modoDebilitado = document.body.classList.contains('modo-debilitado');
        dispenserGrid.innerHTML = medicamentosVisiveis.map((med, indice) => {
            const status = statusEstoque(med);
            const cor = status.cor;
            const antibiotico = medicamentoEhAntibiotico(med);
            const numeroContainer = med.containerNumero;
            const frequencia = frequenciaDiaria(med.horario);
            return `
                <div class="dispenser-card card-${cor}" data-id="${med.id}" aria-label="${escapeHTML(med.nome)}: estoque ${status.rotulo.toLowerCase()}">
                    <span class="badge badge-${cor}">#${numeroContainer}</span>
                    <div class="medicine-period" aria-label="Período do próximo alarme">
                        <strong>--</strong>
                    </div>
                    <div class="inner-shape"><div class="dot"></div></div>
                    <h3>${escapeHTML(med.nome)}</h3>
                    <p class="medicine-dosage">${escapeHTML(med.dosagem)}</p>
                    <p class="medicine-category-status">${escapeHTML(med.categoria)} · ${status.rotulo}</p>
                    <div class="assisted-stock-number" aria-label="Frequência: ${frequencia}">
                        <strong>${frequencia}</strong>
                    </div>
                    <p class="medicine-schedule"><i class="fa-regular fa-clock"></i> ${escapeHTML(med.horario)}</p>
                    ${antibiotico ? `<p class="treatment-line">Exclusão: ${formatarData(med.dataExclusao)}</p>` : ''}
                    <div class="medicine-alarm-row">
                        <div class="medicine-next-alarm" data-med-id="${med.id}" aria-live="polite">
                            <span><i class="fa-solid fa-bell"></i> Próximo alarme</span>
                            <strong>--:--:--</strong>
                            <small>Calculando horário...</small>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        remediosList.innerHTML = medicamentosVisiveis.map(med => {
            const status = statusEstoque(med);
            const cor = status.cor;
            const antibiotico = medicamentoEhAntibiotico(med);
            return `
                <div class="remedio-item" data-id="${med.id}">
                    <div class="status-dot dot-${cor}"></div>
                    <div class="remedio-info">
                        <div class="remedio-header">
                            <h4>${escapeHTML(med.nome)}</h4>
                            <span class="tag ${tagTipo(med.tipoUso)}">${escapeHTML(med.tipoUso)}</span>
                            ${antibiotico ? `<span class="tag tag-blue">Antibiótico · ${med.duracaoTratamentoDias || 5} dias</span>` : ''}
                            <span class="tag tag-${cor}">${status.rotulo}</span>
                        </div>
                        <p>${escapeHTML(med.categoria)} • ${escapeHTML(med.dosagem)} • Container #${med.containerNumero}</p>
                        <p class="time"><i class="fa-regular fa-clock"></i> ${escapeHTML(med.horario)}</p>
                        <p class="stock-line">Estoque: ${med.quantidadeAtual} un. • Mínimo: ${med.quantidadeMinima} un. • Idoso: ${escapeHTML(med.nomeIdoso)}</p>
                        ${antibiotico ? `<p class="treatment-line"><i class="fa-regular fa-calendar-xmark"></i> Exclusão automática: ${formatarData(med.dataExclusao)}</p>` : ''}
                    </div>
                    <div class="actions can-manage">
                        <button type="button" class="icon-btn btn-editar-medicamento" title="Editar"><i class="fa-solid fa-pen"></i></button>
                        <button type="button" class="icon-btn text-red btn-excluir-medicamento" title="Excluir"><i class="fa-solid fa-trash"></i></button>
                    </div>
                </div>
            `;
        }).join('');

        configurarPermissoes();
        configurarAcoesMedicamentos();
        atualizarPainelAlarmes();
    }

    function configurarAcoesMedicamentos() {
        const usuario = getLoggedUser();
        const somenteLeituraSimplificada = usuario && usuario.perfil === 'idoso' && usuario.debilitado;
        document.querySelectorAll('.remedio-item, .dispenser-card').forEach(item => {
            item.style.cursor = somenteLeituraSimplificada ? 'default' : 'pointer';
            item.addEventListener('click', (e) => {
                if (somenteLeituraSimplificada) return;
                if (e.target.closest('.actions') || e.target.closest('button')) return;
                window.location.href = `paginas/estoque.html?medicamentoId=${item.dataset.id}`;
            });
        });

        document.querySelectorAll('.btn-editar-medicamento').forEach(botao => {
            botao.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = Number(botao.closest('.remedio-item').dataset.id);
                window.location.href = `paginas/medicamento.html?medicamentoId=${id}`;
            });
        });

        document.querySelectorAll('.btn-excluir-medicamento').forEach(botao => {
            botao.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = Number(botao.closest('.remedio-item').dataset.id);
                confirmarAcao('Deseja excluir este remédio do banco de dados?', async () => {
                    try {
                        await excluirMedicamentoBackend(id);
                        mostrarToast('Remédio excluído com sucesso.');
                        await renderDashboard();
                    } catch (erro) {
                        mostrarToast(mensagemDaOperacao(erro, 'Não foi possível excluir o remédio.'), 'erro');
                    }
                });
            });
        });
    }

    async function renderReceitas() {
        try {
            receitasCache = await buscarReceitasBackend();
        } catch (erro) {
            receitasCache = [];
            mostrarToast(mensagemDaOperacao(erro, 'Não foi possível carregar as receitas.'), 'erro');
        }

        if (!receitasCache.length) {
            receitasList.innerHTML = '';
            receitasEmpty.style.display = 'block';
            return;
        }

        receitasEmpty.style.display = 'none';
        receitasList.innerHTML = receitasCache.map(receita => `
            <div class="receita-card">
                <div class="receita-icon"><i class="fa-solid fa-file-medical"></i></div>
                <div class="receita-info">
                    <h3>${escapeHTML(receita.medico)}</h3>
                    <p><strong>Data:</strong> ${escapeHTML(receita.dataReceita || 'Sem data')}</p>
                    <p><strong>Medicamentos:</strong> ${escapeHTML(receita.medicamentos)}</p>
                    <p><strong>Observações:</strong> ${escapeHTML(receita.observacoes || 'Nenhuma')}</p>
                    <p><strong>Arquivo:</strong> ${escapeHTML(receita.arquivoNome || 'Sem anexo')} • <strong>Idoso:</strong> ${escapeHTML(receita.nomeIdoso)}</p>
                </div>
                <button type="button" class="icon-btn text-red btn-excluir-receita" data-id="${receita.id}" title="Excluir receita"><i class="fa-solid fa-trash"></i></button>
            </div>
        `).join('');

        document.querySelectorAll('.btn-excluir-receita').forEach(botao => {
            botao.addEventListener('click', () => {
                confirmarAcao('Deseja excluir esta receita?', async () => {
                    try {
                        await excluirReceitaBackend(botao.dataset.id);
                        mostrarToast('Receita excluída com sucesso.');
                        await renderReceitas();
                    } catch (erro) {
                        mostrarToast(mensagemDaOperacao(erro, 'Não foi possível excluir a receita.'), 'erro');
                    }
                });
            });
        });
    }

    async function renderAdminArea() {
        const loggedUser = getLoggedUser();
        if (!loggedUser || loggedUser.perfil !== 'admin' || !adminUsersList) return;

        await carregarUsuariosCache();
        preencherSelectIdosos(adminUserIdosoId);

        const filtro = filtroUsuarios.value || 'todos';
        const usuarios = filtro === 'todos'
            ? usuariosCache
            : usuariosCache.filter(user => user.perfil === filtro);

        if (!usuarios.length) {
            adminUsersList.innerHTML = '<p>Nenhum usuário encontrado para esse filtro.</p>';
            return;
        }

        adminUsersList.innerHTML = usuarios.map(user => `
            <div class="user-card" data-id="${user.id}" data-perfil="${user.perfil}">
                <div class="user-icon"><i class="fa-solid ${user.perfil === 'admin' ? 'fa-user-shield' : user.perfil === 'cuidador' ? 'fa-hand-holding-heart' : 'fa-person-cane'}"></i></div>
                <h3>${escapeHTML(user.nome)}</h3>
                <span class="tag tag-blue-custom">${roleLabel(user.perfil)}</span>
                <p>${escapeHTML(user.descricao)}</p>
                <div class="access-data">
                    <strong>ID:</strong> ${user.id}<br>
                    <strong>Usuário:</strong> ${escapeHTML(user.usuario)}<br>
                    <strong>E-mail:</strong> ${escapeHTML(user.email)}<br>
                    ${user.perfil === 'cuidador' ? `<strong>Idoso vinculado:</strong> ${escapeHTML(user.nomeIdoso || 'Sem vínculo')}<br>` : ''}
                    ${user.perfil === 'idoso' ? `<strong>Condição:</strong> ${user.debilitado ? 'Idoso debilitado' : 'Idoso normal'}<br>` : ''}
                    <strong>Senha:</strong> ********<br>
                    <strong>Acesso:</strong> ${escapeHTML(user.acesso)}
                </div>
                <div class="card-actions">
                    <button type="button" class="btn btn-outline-small btn-editar-usuario">Editar</button>
                    <button type="button" class="btn btn-outline-small danger btn-excluir-usuario">Excluir</button>
                </div>
            </div>
        `).join('');

        document.querySelectorAll('.btn-editar-usuario').forEach(botao => {
            botao.addEventListener('click', () => {
                const card = botao.closest('.user-card');
                const user = usuariosCache.find(item => Number(item.id) === Number(card.dataset.id) && item.perfil === card.dataset.perfil);
                preencherFormularioAdmin(user);
            });
        });

        document.querySelectorAll('.btn-excluir-usuario').forEach(botao => {
            botao.addEventListener('click', () => {
                const card = botao.closest('.user-card');
                const id = Number(card.dataset.id);
                const perfil = card.dataset.perfil;
                const aviso = perfil === 'idoso'
                    ? 'Excluir este usuário, seus remédios, estoques, receitas e autorizações de dispositivos?'
                    : 'Excluir este usuário e seus vínculos e autorizações?';
                confirmarAcao(aviso, async () => {
                    if (botao.disabled) return;
                    botao.disabled = true;
                    try {
                        await excluirUsuarioBackend(id, perfil);
                        const logado = getLoggedUser();
                        if (logado && logado.id === id && logado.perfil === perfil) {
                            clearLoggedUser();
                            if (window.OldFlyAlarm) OldFlyAlarm.stop();
                            showLogin();
                            return;
                        }
                        const visualizado = getViewingUser();
                        if (visualizado && visualizado.id === id && visualizado.perfil === perfil) {
                            localStorage.removeItem('oldfly_viewing_user');
                        }
                        mostrarToast('Usuário excluído com sucesso.');
                        limparFormularioAdmin();
                        await renderAdminArea();
                        const atual = usuariosCache.find(user => user.id === logado?.id && user.perfil === logado?.perfil);
                        if (atual) setLoggedUser(atual);
                        await renderDashboard();
                        await renderReceitas();
                    } catch (erro) {
                        mostrarToast(mensagemDaOperacao(erro, 'Não foi possível excluir o usuário.'), 'erro');
                    } finally {
                        botao.disabled = false;
                    }
                });
            });
        });
    }

    function preencherFormularioAdmin(user) {
        if (!user) return;
        adminFormTitle.innerText = 'Editar usuário';
        document.getElementById('admin-user-id').value = user.id;
        adminUserPerfil.value = user.perfil;
        document.getElementById('admin-user-nome').value = user.nome;
        document.getElementById('admin-user-idade').value = user.idade || 1;
        document.getElementById('admin-user-email').value = user.email;
        document.getElementById('admin-user-usuario').value = user.usuario;
        document.getElementById('admin-user-senha').value = '';
        if (adminUserTipoIdoso) adminUserTipoIdoso.value = user.debilitado ? 'debilitado' : 'normal';
        atualizarCampoIdosoResponsavel();
        preencherSelectIdosos(adminUserIdosoId, user.idosoId || 0);
        adminFormMsg.innerText = 'Editando usuário. Preencha a senha somente se quiser trocar.';
        adminUserForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function limparFormularioAdmin() {
        adminUserForm.reset();
        document.getElementById('admin-user-id').value = '';
        adminFormTitle.innerText = 'Cadastrar usuário';
        adminFormMsg.innerText = '';
        atualizarCampoIdosoResponsavel();
        preencherSelectIdosos(adminUserIdosoId);
    }

    function configurarOlhoSenha() {
        document.querySelectorAll('.password-toggle').forEach(button => {
            button.addEventListener('click', () => {
                const input = document.getElementById(button.dataset.target);
                const icon = button.querySelector('i');
                if (!input || !icon) return;

                const mostrar = input.type === 'password';
                input.type = mostrar ? 'text' : 'password';
                icon.classList.toggle('fa-eye', !mostrar);
                icon.classList.toggle('fa-eye-slash', mostrar);
            });
        });
    }

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        loginError.innerText = 'Entrando...';

        try {
            const user = await loginBackend(loginUser.value.trim(), loginPass.value.trim());
            if (!user) {
                loginError.innerText = 'Usuário ou senha incorretos.';
                return;
            }

            setLoggedUser(user);
            setViewingUser(user);
            loginError.innerText = '';
            loginForm.reset();
            await showApp();
        } catch (erro) {
            loginError.innerText = mensagemDaOperacao(erro, 'Não foi possível entrar. Tente novamente.');
        }
    });

    if (btnAssistedLogin) {
        btnAssistedLogin.addEventListener('click', async () => {
            if (!contaAssistidaDisponivel) return;
            const idoso = { ...contaAssistidaDisponivel, acessoDispositivo: true };
            setLoggedUser(idoso);
            setViewingUser(idoso);
            await showApp();
        });
    }

    registerPerfil.addEventListener('change', atualizarCampoIdosoResponsavel);
    btnShowRegister.addEventListener('click', showRegisterCard);
    btnShowLogin.addEventListener('click', showLoginCard);

    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        registerMessage.style.color = 'var(--green-text)';
        registerMessage.innerText = 'Cadastrando...';

        const usuarioCriado = registerUsuario.value.trim();
        const senhaCriada = registerSenha.value.trim();

        try {
            await cadastrarUsuarioBackend({
                perfil: registerPerfil.value,
                nome: registerNome.value.trim(),
                idade: registerIdade.value,
                email: registerEmail.value.trim(),
                usuario: usuarioCriado,
                senha: senhaCriada,
                adminId: 0,
                idosoId: registerIdosoId ? registerIdosoId.value : 0,
                debilitado: registerPerfil.value === 'idoso' && registerTipoIdoso.value === 'debilitado'
            });

            registerMessage.innerText = 'Cadastro realizado. Agora faça login.';
            registerForm.reset();
            loginUser.value = usuarioCriado;
            loginPass.value = senhaCriada;
            atualizarCampoIdosoResponsavel();
            await carregarUsuariosCache();
            showLoginCard();
        } catch (erro) {
            registerMessage.style.color = 'var(--red-text)';
            registerMessage.innerText = mensagemDaOperacao(erro, 'Não foi possível cadastrar. Confira os dados.');
        }
    });

    btnLogout.addEventListener('click', (e) => {
        e.preventDefault();
        if (window.OldFlyAlarm) OldFlyAlarm.stop();
        clearLoggedUser();
        showLogin();
    });

    navDashboard.addEventListener('click', async (e) => {
        e.preventDefault();
        await renderDashboard();
        showDashboard();
    });

    navReceitas.addEventListener('click', async (e) => {
        e.preventDefault();
        removeActiveNav();
        hideAllViews();
        navReceitas.classList.add('active');
        await renderReceitas();
        viewReceitasVazia.style.display = 'block';
    });

    navUsuarios.addEventListener('click', async (e) => {
        e.preventDefault();
        const loggedUser = getLoggedUser();
        if (!loggedUser || loggedUser.perfil !== 'admin') return;
        removeActiveNav();
        hideAllViews();
        navUsuarios.classList.add('active');
        await renderAdminArea();
        viewUsuarios.style.display = 'block';
    });

    navSobre.addEventListener('click', (e) => {
        e.preventDefault();
        showSobre();
    });

    const showFormReceita = (e) => {
        e.preventDefault();
        hideAllViews();
        receitaFormMsg.innerText = '';
        viewReceitasForm.style.display = 'block';
    };

    btnNovaReceita.addEventListener('click', showFormReceita);
    btnAddPrimeira.addEventListener('click', showFormReceita);

    btnCancelar.addEventListener('click', async (e) => {
        e.preventDefault();
        receitaForm.reset();
        document.getElementById('file-preview').style.display = 'none';
        hideAllViews();
        await renderReceitas();
        viewReceitasVazia.style.display = 'block';
    });

    receitaForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        receitaFormMsg.innerText = 'Salvando...';
        const fileName = document.getElementById('file-name').innerText;
        try {
            await salvarReceitaBackend({
                medico: document.getElementById('receita-medico').value.trim(),
                dataReceita: document.getElementById('receita-data').value,
                medicamentos: document.getElementById('receita-medicamentos').value.trim(),
                observacoes: document.getElementById('receita-observacoes').value.trim(),
                arquivoNome: fileName,
                idosoId: getPrimeiroIdosoId()
            });
            mostrarToast('Receita salva no banco com sucesso.');
            receitaForm.reset();
            document.getElementById('file-preview').style.display = 'none';
            hideAllViews();
            await renderReceitas();
            viewReceitasVazia.style.display = 'block';
        } catch (erro) {
            receitaFormMsg.innerText = mensagemDaOperacao(erro, 'Não foi possível salvar a receita. Confira os dados.');
        }
    });

    const btnFoto = document.getElementById('btn-foto');
    const btnAnexo = document.getElementById('btn-anexo');
    const inputCamera = document.getElementById('input-camera');
    const inputGallery = document.getElementById('input-gallery');
    const filePreview = document.getElementById('file-preview');
    const fileNameSpan = document.getElementById('file-name');

    const handleFileSelect = (input) => {
        if (input.files && input.files[0]) {
            fileNameSpan.innerText = input.files[0].name;
            filePreview.style.display = 'block';
        }
    };

    btnAnexo.addEventListener('click', () => inputGallery.click());
    btnFoto.addEventListener('click', () => inputCamera.click());
    inputCamera.addEventListener('change', () => handleFileSelect(inputCamera));
    inputGallery.addEventListener('change', () => handleFileSelect(inputGallery));

    btnNovoMedicamento.addEventListener('click', () => {
        window.location.href = 'paginas/medicamento.html';
    });

    if (btnAutorizarDispositivo) {
        btnAutorizarDispositivo.addEventListener('click', async () => {
            const cuidador = getLoggedUser();
            if (!cuidador || cuidador.perfil !== 'cuidador' || !cuidador.idosoId) return;
            btnAutorizarDispositivo.disabled = true;
            try {
                const autorizadoParaEsteIdoso = contaAssistidaDisponivel
                    && String(contaAssistidaDisponivel.id) === String(cuidador.idosoId);
                if (autorizadoParaEsteIdoso) {
                    await bloquearDispositivoBackend();
                    contaAssistidaDisponivel = null;
                    configurarPermissoes();
                    mostrarToast('Acesso assistido bloqueado neste dispositivo.');
                    return;
                }

                const idoso = await autorizarDispositivoBackend(cuidador.idosoId);
                contaAssistidaDisponivel = idoso;
                clearLoggedUser();
                if (window.OldFlyAlarm) OldFlyAlarm.stop();
                showLogin();
                loginError.innerText = `Dispositivo autorizado. Escolha a conta assistida de ${idoso.nome} abaixo.`;
            } catch (erro) {
                if (erro.status === 401) {
                    clearLoggedUser();
                    if (window.OldFlyAlarm) OldFlyAlarm.stop();
                    showLogin();
                    loginError.innerText = 'Sua sessão de cuidador expirou. Entre novamente para autorizar o dispositivo.';
                    return;
                }
                mostrarToast('Não foi possível autorizar. Entre novamente como cuidador e confirme que o idoso é debilitado.', 'erro');
            } finally {
                btnAutorizarDispositivo.disabled = false;
            }
        });
    }

    adminUserPerfil.addEventListener('change', atualizarCampoIdosoResponsavel);
    filtroUsuarios.addEventListener('change', renderAdminArea);
    btnAdminLimpar.addEventListener('click', limparFormularioAdmin);

    adminUserForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        adminFormMsg.innerText = 'Salvando...';
        const id = document.getElementById('admin-user-id').value;
        const perfil = adminUserPerfil.value;
        const dados = {
            perfil,
            nome: document.getElementById('admin-user-nome').value.trim(),
            idade: document.getElementById('admin-user-idade').value,
            email: document.getElementById('admin-user-email').value.trim(),
            usuario: document.getElementById('admin-user-usuario').value.trim(),
            senha: document.getElementById('admin-user-senha').value.trim(),
            adminId: 0,
            idosoId: adminUserIdosoId ? adminUserIdosoId.value : 0,
            debilitado: perfil === 'idoso' && adminUserTipoIdoso.value === 'debilitado'
        };

        if (!id && !dados.senha) {
            adminFormMsg.innerText = 'Informe uma senha para criar o usuário.';
            return;
        }

        try {
            if (id) {
                await atualizarUsuarioBackend(id, perfil, dados);
                mostrarToast('Usuário atualizado com sucesso.');
            } else {
                await cadastrarUsuarioBackend(dados);
                mostrarToast('Usuário cadastrado com sucesso.');
            }
            limparFormularioAdmin();
            await renderAdminArea();
        } catch (erro) {
            adminFormMsg.innerText = mensagemDaOperacao(erro, 'Não foi possível salvar o usuário. Confira os dados.');
        }
    });

    configurarOlhoSenha();
    atualizarCampoIdosoResponsavel();

    async function iniciarAplicacao() {
        const params = new URLSearchParams(window.location.search);
        try {
            contaAssistidaDisponivel = await reconhecerDispositivoBackend();
        } catch (erro) {
            contaAssistidaDisponivel = null;
        }

        let usuario = getLoggedUser();
        if (usuario && usuario.acessoDispositivo) {
            clearLoggedUser();
            usuario = null;
        }

        if (!usuario) {
            showLogin();
            return;
        }

        await showApp();
        if (!usuario.debilitado && params.get('sobre') === '1') showSobre();
    }

    iniciarAplicacao();
});
