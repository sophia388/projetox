(function (root, factory) {
    'use strict';

    var api = factory();

    if (typeof module === 'object' && module.exports) {
        module.exports = api;
    } else {
        root.OldFlyValidation = api;
    }
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
    'use strict';

    var PADRAO_NOME = /^[A-Za-zÀ-ÖØ-öø-ÿ'\\-\s]+$/;
    var PADRAO_USUARIO = /^[a-zA-Z0-9._-]+$/;
    var PADRAO_EMAIL = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
    var PADRAO_MEDICO = /^[A-Za-zÀ-ÖØ-öø-ÿ'\\-\\.\s]+$/;
    var PADRAO_MEDICAMENTO_NOME = /^[A-Za-z0-9À-ÖØ-öø-ÿ\s+\\-\\.,()]+$/;
    var PADRAO_CATEGORIA = /^[A-Za-zÀ-ÖØ-öø-ÿ'\\-\s]+$/;
    var EXTENSOES_ARQUIVO_PERMITIDAS = ['.jpg', '.jpeg', '.png', '.webp', '.pdf'];

    function sanitizarTexto(valor) {
        if (typeof valor !== 'string') return '';
        return valor.trim().replace(/\s+/g, ' ');
    }

    function sanitizarSomenteDigitos(valor) {
        if (typeof valor !== 'string' && typeof valor !== 'number') return '';
        return String(valor).replace(/\D/g, '');
    }

    function validarNome(nome) {
        var limpo = sanitizarTexto(nome);
        if (!limpo) {
            return { valido: false, mensagem: 'O nome é obrigatório.', valor: '' };
        }
        if (limpo.length < 2 || limpo.length > 100) {
            return { valido: false, mensagem: 'O nome deve ter entre 2 e 100 caracteres.', valor: limpo };
        }
        if (!PADRAO_NOME.test(limpo)) {
            return { valido: false, mensagem: 'O nome deve conter apenas letras e espaços (sem números ou símbolos).', valor: limpo };
        }
        return { valido: true, mensagem: '', valor: limpo };
    }

    function validarUsuario(usuario) {
        var limpo = typeof usuario === 'string' ? usuario.trim() : '';
        if (!limpo) {
            return { valido: false, mensagem: 'O nome de usuário é obrigatório.', valor: '' };
        }
        if (/\s/.test(limpo)) {
            return { valido: false, mensagem: 'O nome de usuário não pode conter espaços.', valor: limpo };
        }
        if (limpo.length < 3 || limpo.length > 30) {
            return { valido: false, mensagem: 'O usuário deve ter entre 3 e 30 caracteres.', valor: limpo };
        }
        if (!PADRAO_USUARIO.test(limpo)) {
            return { valido: false, mensagem: 'O usuário deve conter apenas letras, números, ponto (.), underline (_) ou hífen (-).', valor: limpo };
        }
        return { valido: true, mensagem: '', valor: limpo };
    }

    function validarSenha(senha, obrigatoria) {
        if (obrigatoria === undefined) obrigatoria = true;
        var valor = typeof senha === 'string' ? senha.trim() : '';

        if (!valor) {
            if (obrigatoria) {
                return { valido: false, mensagem: 'A senha é obrigatória.', valor: '' };
            }
            return { valido: true, mensagem: '', valor: '' };
        }

        if (valor.length < 6 || valor.length > 60) {
            return { valido: false, mensagem: 'A senha deve ter entre 6 e 60 caracteres.', valor: valor };
        }
        return { valido: true, mensagem: '', valor: valor };
    }

    function validarEmail(email) {
        var limpo = typeof email === 'string' ? email.trim() : '';
        if (!limpo) {
            return { valido: false, mensagem: 'O e-mail é obrigatório.', valor: '' };
        }
        if (limpo.length > 100) {
            return { valido: false, mensagem: 'O e-mail deve ter no máximo 100 caracteres.', valor: limpo };
        }
        if (!PADRAO_EMAIL.test(limpo)) {
            return { valido: false, mensagem: 'Informe um e-mail válido (exemplo: usuario@dominio.com).', valor: limpo };
        }
        return { valido: true, mensagem: '', valor: limpo.toLowerCase() };
    }

    function validarIdade(idade) {
        var str = String(idade !== undefined && idade !== null ? idade : '').trim();
        if (!str) {
            return { valido: false, mensagem: 'A idade é obrigatória.', valor: null };
        }
        if (!/^\d+$/.test(str)) {
            return { valido: false, mensagem: 'A idade deve ser um número inteiro (sem vírgulas ou letras).', valor: null };
        }
        var num = Number(str);
        if (!Number.isInteger(num) || num < 1 || num > 130) {
            return { valido: false, mensagem: 'A idade deve estar entre 1 e 130 anos.', valor: null };
        }
        return { valido: true, mensagem: '', valor: num };
    }

    function validarPerfil(perfil) {
        var limpo = typeof perfil === 'string' ? perfil.trim().toLowerCase() : '';
        var permitidos = ['idoso', 'cuidador', 'admin'];
        if (permitidos.indexOf(limpo) === -1) {
            return { valido: false, mensagem: 'Selecione um perfil válido (Idoso, Cuidador ou Administrador).', valor: '' };
        }
        return { valido: true, mensagem: '', valor: limpo };
    }

    function validarTipoIdoso(tipo) {
        var limpo = typeof tipo === 'string' ? tipo.trim().toLowerCase() : '';
        if (limpo !== 'normal' && limpo !== 'debilitado') {
            return { valido: false, mensagem: 'Condição do idoso inválida.', valor: 'normal' };
        }
        return { valido: true, mensagem: '', valor: limpo };
    }

    function validarMedico(medico) {
        var limpo = sanitizarTexto(medico);
        if (!limpo) {
            return { valido: false, mensagem: 'O nome do médico é obrigatório.', valor: '' };
        }
        if (limpo.length < 2 || limpo.length > 100) {
            return { valido: false, mensagem: 'O nome do médico deve ter entre 2 e 100 caracteres.', valor: limpo };
        }
        if (!PADRAO_MEDICO.test(limpo)) {
            return { valido: false, mensagem: 'O nome do médico deve conter apenas letras, pontos e espaços.', valor: limpo };
        }
        return { valido: true, mensagem: '', valor: limpo };
    }

    function validarDataReceita(dataStr) {
        var limpo = typeof dataStr === 'string' ? dataStr.trim() : '';
        if (!limpo) {
            return { valido: false, mensagem: 'A data da receita é obrigatória.', valor: '' };
        }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(limpo)) {
            return { valido: false, mensagem: 'Formato de data inválido. Use AAAA-MM-DD.', valor: '' };
        }
        var partes = limpo.split('-').map(Number);
        var ano = partes[0];
        var mes = partes[1];
        var dia = partes[2];

        if (ano < 1900 || ano > 2100) {
            return { valido: false, mensagem: 'O ano da receita deve estar entre 1900 e 2100.', valor: '' };
        }
        var dt = new Date(ano, mes - 1, dia);
        if (dt.getFullYear() !== ano || dt.getMonth() !== mes - 1 || dt.getDate() !== dia) {
            return { valido: false, mensagem: 'Data inexistente no calendário.', valor: '' };
        }
        return { valido: true, mensagem: '', valor: limpo };
    }

    function validarMedicamentosReceita(texto) {
        var limpo = sanitizarTexto(texto);
        if (!limpo) {
            return { valido: false, mensagem: 'Informe os medicamentos da receita.', valor: '' };
        }
        if (limpo.length < 2 || limpo.length > 255) {
            return { valido: false, mensagem: 'O campo medicamentos deve ter entre 2 e 255 caracteres.', valor: limpo };
        }
        return { valido: true, mensagem: '', valor: limpo };
    }

    function validarObservacoesReceita(texto) {
        var limpo = sanitizarTexto(texto);
        if (limpo.length > 500) {
            return { valido: false, mensagem: 'Observações não podem ultrapassar 500 caracteres.', valor: limpo };
        }
        return { valido: true, mensagem: '', valor: limpo };
    }

    function validarArquivo(nomeArquivo, tamanhoBytes) {
        if (!nomeArquivo) {
            return { valido: true, mensagem: '', valor: '' };
        }
        var nomeLower = nomeArquivo.toLowerCase();
        var validoExt = EXTENSOES_ARQUIVO_PERMITIDAS.some(function (ext) {
            return nomeLower.endsWith(ext);
        });
        if (!validoExt) {
            return { valido: false, mensagem: 'Formato de arquivo não permitido. Use imagens (JPG, PNG, WEBP) ou PDF.', valor: '' };
        }
        if (tamanhoBytes && tamanhoBytes > 10 * 1024 * 1024) {
            return { valido: false, mensagem: 'O arquivo não pode ultrapassar 10 MB.', valor: '' };
        }
        var nomeSanitizado = nomeArquivo.replace(/[/\\]/g, '').trim();
        return { valido: true, mensagem: '', valor: nomeSanitizado };
    }

    function validarMedicamentoNome(nome) {
        var limpo = sanitizarTexto(nome);
        if (!limpo) {
            return { valido: false, mensagem: 'O nome do medicamento é obrigatório.', valor: '' };
        }
        if (limpo.length < 2 || limpo.length > 100) {
            return { valido: false, mensagem: 'O nome do medicamento deve ter entre 2 e 100 caracteres.', valor: limpo };
        }
        if (!PADRAO_MEDICAMENTO_NOME.test(limpo)) {
            return { valido: false, mensagem: 'O nome do medicamento contém caracteres inválidos.', valor: limpo };
        }
        return { valido: true, mensagem: '', valor: limpo };
    }

    function validarDosagem(dosagem) {
        var limpo = sanitizarTexto(dosagem);
        if (!limpo) {
            return { valido: false, mensagem: 'A dosagem é obrigatória (ex: 50mg, 1 comprimido).', valor: '' };
        }
        if (limpo.length < 1 || limpo.length > 50) {
            return { valido: false, mensagem: 'A dosagem deve ter entre 1 e 50 caracteres.', valor: limpo };
        }
        return { valido: true, mensagem: '', valor: limpo };
    }

    function validarCategoria(categoria) {
        var limpo = sanitizarTexto(categoria);
        if (!limpo) {
            return { valido: false, mensagem: 'A categoria do medicamento é obrigatória.', valor: '' };
        }
        if (limpo.length < 2 || limpo.length > 50) {
            return { valido: false, mensagem: 'A categoria deve ter entre 2 e 50 caracteres.', valor: limpo };
        }
        if (!PADRAO_CATEGORIA.test(limpo)) {
            return { valido: false, mensagem: 'A categoria deve conter apenas letras e espaços.', valor: limpo };
        }
        return { valido: true, mensagem: '', valor: limpo };
    }

    function validarTipoUso(tipoUso) {
        var limpo = typeof tipoUso === 'string' ? tipoUso.trim() : '';
        if (limpo === 'Contínuo' || limpo === 'Continuo') {
            return { valido: true, mensagem: '', valor: 'Contínuo' };
        }
        if (limpo === 'Programado') {
            return { valido: true, mensagem: '', valor: 'Programado' };
        }
        return { valido: false, mensagem: 'O tipo de uso deve ser Contínuo ou Programado.', valor: '' };
    }

    function validarContainer(container) {
        var str = String(container !== undefined && container !== null ? container : '').trim();
        if (!str || !/^\d+$/.test(str)) {
            return { valido: false, mensagem: 'O container deve ser um número inteiro de 1 a 8.', valor: null };
        }
        var num = Number(str);
        if (!Number.isInteger(num) || num < 1 || num > 8) {
            return { valido: false, mensagem: 'O container deve ser de 1 a 8.', valor: null };
        }
        return { valido: true, mensagem: '', valor: num };
    }

    function validarEstoqueAtual(qtd) {
        var str = String(qtd !== undefined && qtd !== null ? qtd : '').trim();
        if (str === '' || !/^\d+$/.test(str)) {
            return { valido: false, mensagem: 'O estoque atual deve ser um número inteiro não negativo (>= 0).', valor: null };
        }
        var num = Number(str);
        if (!Number.isInteger(num) || num < 0 || num > 99999) {
            return { valido: false, mensagem: 'O estoque atual deve estar entre 0 e 99999.', valor: null };
        }
        return { valido: true, mensagem: '', valor: num };
    }

    function validarEstoqueMinimo(qtd) {
        var str = String(qtd !== undefined && qtd !== null ? qtd : '').trim();
        if (!str || !/^\d+$/.test(str)) {
            return { valido: false, mensagem: 'O estoque mínimo deve ser um número inteiro positivo (>= 1).', valor: null };
        }
        var num = Number(str);
        if (!Number.isInteger(num) || num < 1 || num > 999) {
            return { valido: false, mensagem: 'O estoque mínimo deve estar entre 1 e 999.', valor: null };
        }
        return { valido: true, mensagem: '', valor: num };
    }

    function validarQuantidadeComprada(qtd) {
        var str = String(qtd !== undefined && qtd !== null ? qtd : '').trim();
        if (!str || !/^\d+$/.test(str)) {
            return { valido: false, mensagem: 'Informe uma quantidade comprada válida (número inteiro maior que 0).', valor: null };
        }
        var num = Number(str);
        if (!Number.isInteger(num) || num < 1 || num > 9999) {
            return { valido: false, mensagem: 'A quantidade comprada deve ser entre 1 e 9999 unidades.', valor: null };
        }
        return { valido: true, mensagem: '', valor: num };
    }

    function validarHorarioIndividual(horario) {
        if (typeof horario !== 'string') {
            return { valido: false, mensagem: 'Horário inválido.', valor: '' };
        }
        var m = horario.trim().match(/^(\d{1,2}):(\d{2})$/);
        if (!m) {
            return { valido: false, mensagem: 'Horário deve estar no formato HH:mm.', valor: '' };
        }
        var h = Number(m[1]);
        var min = Number(m[2]);
        if (h < 0 || h > 23 || min < 0 || min > 59) {
            return { valido: false, mensagem: 'Horário impossível no relógio (horas 00-23, minutos 00-59).', valor: '' };
        }
        var normalizado = (h < 10 ? '0' + h : String(h)) + ':' + (min < 10 ? '0' + min : String(min));
        return { valido: true, mensagem: '', valor: normalizado };
    }

    function validarHorarios(horarios) {
        var lista = [];
        if (Array.isArray(horarios)) {
            lista = horarios;
        } else if (typeof horarios === 'string') {
            lista = horarios.split(',').map(function (s) { return s.trim(); }).filter(Boolean);
        }

        if (!lista.length) {
            return { valido: false, mensagem: 'Adicione pelo menos um horário para o medicamento.', valor: '' };
        }

        var unicos = new Set();
        for (var i = 0; i < lista.length; i++) {
            var checagem = validarHorarioIndividual(lista[i]);
            if (!checagem.valido) {
                return { valido: false, mensagem: 'Horário inválido encontrado: ' + lista[i], valor: '' };
            }
            unicos.add(checagem.valor);
        }

        var ordenados = Array.from(unicos).sort();
        return { valido: true, mensagem: '', valor: ordenados.join(', ') };
    }

    function validarAntibiotico(ativo, dataInicio, duracao) {
        if (!ativo) {
            return { valido: true, mensagem: '', dataInicio: null, duracao: null };
        }
        var validData = validarDataReceita(dataInicio);
        if (!validData.valido) {
            return { valido: false, mensagem: 'Para antibióticos, informe uma data de início válida.', dataInicio: null, duracao: null };
        }
        var duracaoNum = Number(duracao);
        if (duracaoNum !== 5 && duracaoNum !== 7) {
            return { valido: false, mensagem: 'A duração do tratamento com antibiótico deve ser de 5 ou 7 dias.', dataInicio: null, duracao: null };
        }
        return { valido: true, mensagem: '', dataInicio: validData.valor, duracao: duracaoNum };
    }

    return {
        sanitizarTexto: sanitizarTexto,
        sanitizarSomenteDigitos: sanitizarSomenteDigitos,
        validarNome: validarNome,
        validarUsuario: validarUsuario,
        validarSenha: validarSenha,
        validarEmail: validarEmail,
        validarIdade: validarIdade,
        validarPerfil: validarPerfil,
        validarTipoIdoso: validarTipoIdoso,
        validarMedico: validarMedico,
        validarDataReceita: validarDataReceita,
        validarMedicamentosReceita: validarMedicamentosReceita,
        validarObservacoesReceita: validarObservacoesReceita,
        validarArquivo: validarArquivo,
        validarMedicamentoNome: validarMedicamentoNome,
        validarDosagem: validarDosagem,
        validarCategoria: validarCategoria,
        validarTipoUso: validarTipoUso,
        validarContainer: validarContainer,
        validarEstoqueAtual: validarEstoqueAtual,
        validarEstoqueMinimo: validarEstoqueMinimo,
        validarQuantidadeComprada: validarQuantidadeComprada,
        validarHorarioIndividual: validarHorarioIndividual,
        validarHorarios: validarHorarios,
        validarAntibiotico: validarAntibiotico
    };
}));
