package com.usuarios.AcessoBackEnd.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "sessao_cuidador")
public class SessaoCuidador {

    @Id
    @Column(length = 64)
    private String tokenHash;

    @ManyToOne(optional = false)
    @JoinColumn(name = "cuidador_id", nullable = false)
    private UsuarioCuidador cuidador;

    @Column(nullable = false)
    private LocalDateTime expiraEm;

    public String getTokenHash() { return tokenHash; }
    public void setTokenHash(String tokenHash) { this.tokenHash = tokenHash; }
    public UsuarioCuidador getCuidador() { return cuidador; }
    public void setCuidador(UsuarioCuidador cuidador) { this.cuidador = cuidador; }
    public LocalDateTime getExpiraEm() { return expiraEm; }
    public void setExpiraEm(LocalDateTime expiraEm) { this.expiraEm = expiraEm; }
}
