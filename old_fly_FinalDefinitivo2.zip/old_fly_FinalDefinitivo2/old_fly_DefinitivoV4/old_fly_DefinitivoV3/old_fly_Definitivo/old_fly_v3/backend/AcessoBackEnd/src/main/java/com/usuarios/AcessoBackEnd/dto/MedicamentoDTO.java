package com.usuarios.AcessoBackEnd.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public class MedicamentoDTO {

    @NotBlank(message = "O nome do medicamento é obrigatório")
    @Size(min = 2, max = 100, message = "O nome deve ter entre 2 e 100 caracteres")
    @Pattern(regexp = "^[A-Za-z0-9À-ÖØ-öø-ÿ\\s+\\-\\.,()]+$", message = "O nome do medicamento contém caracteres inválidos")
    private String nome;

    @NotBlank(message = "A dosagem é obrigatória")
    @Size(min = 1, max = 50, message = "A dosagem deve ter entre 1 e 50 caracteres")
    private String dosagem;

    @NotBlank(message = "A categoria é obrigatória")
    @Size(min = 2, max = 50, message = "A categoria deve ter entre 2 e 50 caracteres")
    @Pattern(regexp = "^[A-Za-zÀ-ÖØ-öø-ÿ'\\-\\s]+$", message = "A categoria deve conter apenas letras e espaços")
    private String categoria;

    @NotBlank(message = "Informe pelo menos um horário para o medicamento")
    @Pattern(regexp = "^(\\d{1,2}:\\d{2})(\\s*,\\s*\\d{1,2}:\\d{2})*$", message = "Formato de horários inválido. Use HH:mm separados por vírgula")
    private String horario;

    @NotBlank(message = "O tipo de uso é obrigatório")
    @Pattern(regexp = "^(?i)(Contínuo|Continuo|Programado)$", message = "O tipo de uso deve ser Contínuo ou Programado")
    private String tipoUso;

    @Min(value = 1, message = "O container deve ser de 1 a 8")
    @Max(value = 8, message = "O container deve ser de 1 a 8")
    private Integer containerNumero;

    private String cor;

    @Min(value = 0, message = "Idoso vinculado inválido")
    private int idosoId;

    @Min(value = 0, message = "O estoque atual não pode ser negativo")
    @Max(value = 99999, message = "O estoque atual deve ser no máximo 99999")
    private int quantidadeAtual;

    @Min(value = 1, message = "O estoque mínimo deve ser no mínimo 1")
    @Max(value = 999, message = "O estoque mínimo deve ser no máximo 999")
    private int quantidadeMinima;

    private Boolean antibiotico;
    private LocalDate dataInicioTratamento;
    private Integer duracaoTratamentoDias;

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome != null ? nome.trim() : null; }
    public String getDosagem() { return dosagem; }
    public void setDosagem(String dosagem) { this.dosagem = dosagem != null ? dosagem.trim() : null; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria != null ? categoria.trim() : null; }
    public String getHorario() { return horario; }
    public void setHorario(String horario) { this.horario = horario != null ? horario.trim() : null; }
    public String getTipoUso() { return tipoUso; }
    public void setTipoUso(String tipoUso) { this.tipoUso = tipoUso != null ? tipoUso.trim() : null; }
    public Integer getContainerNumero() { return containerNumero; }
    public void setContainerNumero(Integer containerNumero) { this.containerNumero = containerNumero; }
    public String getCor() { return cor; }
    public void setCor(String cor) { this.cor = cor != null ? cor.trim() : null; }
    public int getIdosoId() { return idosoId; }
    public void setIdosoId(int idosoId) { this.idosoId = idosoId; }
    public int getQuantidadeAtual() { return quantidadeAtual; }
    public void setQuantidadeAtual(int quantidadeAtual) { this.quantidadeAtual = quantidadeAtual; }
    public int getQuantidadeMinima() { return quantidadeMinima; }
    public void setQuantidadeMinima(int quantidadeMinima) { this.quantidadeMinima = quantidadeMinima; }
    public Boolean getAntibiotico() { return antibiotico; }
    public void setAntibiotico(Boolean antibiotico) { this.antibiotico = antibiotico; }
    public LocalDate getDataInicioTratamento() { return dataInicioTratamento; }
    public void setDataInicioTratamento(LocalDate dataInicioTratamento) { this.dataInicioTratamento = dataInicioTratamento; }
    public Integer getDuracaoTratamentoDias() { return duracaoTratamentoDias; }
    public void setDuracaoTratamentoDias(Integer duracaoTratamentoDias) { this.duracaoTratamentoDias = duracaoTratamentoDias; }
}

