package com.usuarios.AcessoBackEnd.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "oldfly.dispenser")
public class DispenserProperties {
    private boolean habilitado;
    private boolean permitirMotores;
    private int idosoId;
    private String token = "";

    public boolean isHabilitado() { return habilitado; }
    public void setHabilitado(boolean habilitado) { this.habilitado = habilitado; }
    public boolean isPermitirMotores() { return permitirMotores; }
    public void setPermitirMotores(boolean permitirMotores) { this.permitirMotores = permitirMotores; }
    public int getIdosoId() { return idosoId; }
    public void setIdosoId(int idosoId) { this.idosoId = idosoId; }
    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public boolean configurado() { return habilitado && token != null && token.length() >= 32; }
}
