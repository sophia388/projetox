package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.entity.DispositivoAutorizado;
import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.DispositivoAutorizadoRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Base64;

@Service
public class DispositivoService {

    private final SecureRandom secureRandom = new SecureRandom();

    @Autowired
    private DispositivoAutorizadoRepository repository;

    @Autowired
    private UsuarioIdosoRepository idosoRepository;

    public CredencialDispositivo autorizar(UsuarioCuidador cuidador, int idosoId) {
        UsuarioIdoso idoso = idosoRepository.findById(idosoId)
                .orElseThrow(() -> new IllegalArgumentException("Idoso não encontrado"));

        if (cuidador.getIdoso() == null || cuidador.getIdoso().getId() != idosoId) {
            throw new SecurityException("O cuidador não é responsável por este idoso");
        }
        if (!idoso.isDebilitado()) {
            throw new IllegalArgumentException("A autorização de dispositivo é exclusiva para idoso debilitado");
        }

        byte[] bytes = new byte[32];
        secureRandom.nextBytes(bytes);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);

        DispositivoAutorizado dispositivo = new DispositivoAutorizado();
        dispositivo.setTokenHash(hash(token));
        dispositivo.setIdoso(idoso);
        dispositivo.setCuidador(cuidador);
        dispositivo.setCriadoEm(LocalDateTime.now());
        dispositivo.setUltimoAcessoEm(LocalDateTime.now());
        repository.save(dispositivo);

        return new CredencialDispositivo(token, idoso);
    }

    public UsuarioIdoso reconhecer(String token) {
        if (token == null || token.isBlank()) return null;

        return repository.findByTokenHashAndAtivoTrue(hash(token))
                .filter(item -> item.getIdoso().isDebilitado())
                .map(item -> {
                    item.setUltimoAcessoEm(LocalDateTime.now());
                    repository.save(item);
                    return item.getIdoso();
                })
                .orElse(null);
    }

    public boolean revogar(String token, UsuarioCuidador cuidador) {
        if (token == null || token.isBlank() || cuidador == null) return false;

        return repository.findByTokenHashAndAtivoTrue(hash(token))
                .filter(item -> item.getCuidador().getId() == cuidador.getId())
                .map(item -> {
                    item.setAtivo(false);
                    repository.save(item);
                    return true;
                })
                .orElse(false);
    }

    private String hash(String token) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(token.getBytes(StandardCharsets.UTF_8));
            return java.util.HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException erro) {
            throw new IllegalStateException("SHA-256 não está disponível", erro);
        }
    }

    public record CredencialDispositivo(String token, UsuarioIdoso idoso) { }
}
