package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.config.DispenserProperties;
import com.usuarios.AcessoBackEnd.entity.VinculoDispenser;
import com.usuarios.AcessoBackEnd.repository.VinculoDispenserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class VinculoDispenserService implements CommandLineRunner {
    private final VinculoDispenserRepository repository;
    private final DispenserProperties properties;
    public VinculoDispenserService(VinculoDispenserRepository repository, DispenserProperties properties) {
        this.repository = repository; this.properties = properties;
    }
    @Override
    @Transactional
    public void run(String... args) {
        if (!repository.existsById(1)) {
            VinculoDispenser vinculo = new VinculoDispenser();
            vinculo.setIdosoId(properties.getIdosoId());
            repository.save(vinculo);
        }
    }
    public int idosoId() { return repository.findById(1).map(VinculoDispenser::getIdosoId).orElse(0); }
    public VinculoDispenser bloquear() { return repository.bloquear().orElseThrow(); }
}
