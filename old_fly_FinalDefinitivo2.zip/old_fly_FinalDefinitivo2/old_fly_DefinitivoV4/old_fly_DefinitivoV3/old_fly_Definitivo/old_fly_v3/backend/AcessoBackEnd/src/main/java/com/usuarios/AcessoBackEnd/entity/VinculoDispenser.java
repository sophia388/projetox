package com.usuarios.AcessoBackEnd.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "vinculo_dispenser")
public class VinculoDispenser {
    @Id
    private int id = 1;
    private int idosoId;
    private LocalDateTime ativarAPartirDe;
    public int getId() { return id; }
    public int getIdosoId() { return idosoId; }
    public void setIdosoId(int idosoId) { this.idosoId = idosoId; }
    public LocalDateTime getAtivarAPartirDe() { return ativarAPartirDe; }
    public void setAtivarAPartirDe(LocalDateTime data) { this.ativarAPartirDe = data; }
}
