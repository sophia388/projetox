package com.usuarios.AcessoBackEnd.repository;

import com.usuarios.AcessoBackEnd.entity.ComandoDispenser;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface ComandoDispenserRepository extends JpaRepository<ComandoDispenser, String> {
    Optional<ComandoDispenser> findByMedicamentoIdAndAgendadoPara(int medicamentoId, LocalDateTime agendadoPara);
    Optional<ComandoDispenser> findFirstByIdosoIdAndEstadoInOrderByAgendadoParaAsc(
            int idosoId, Collection<ComandoDispenser.Estado> estados);
    List<ComandoDispenser> findTop10ByIdosoIdOrderByAgendadoParaDesc(int idosoId);
    void deleteByIdosoId(int idosoId);
    List<ComandoDispenser> findByIdosoIdAndEstado(int idosoId, ComandoDispenser.Estado estado);
}
