package com.usuarios.AcessoBackEnd.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class LoginDTO {

    @NotBlank(message = "O usuário é obrigatório")
    @Size(max = 50, message = "O usuário deve ter no máximo 50 caracteres")
    private String usuario;

    @NotBlank(message = "A senha é obrigatória")
    @Size(max = 60, message = "A senha deve ter no máximo 60 caracteres")
    private String senha;

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario != null ? usuario.trim() : null;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha != null ? senha.trim() : null;
    }
}

