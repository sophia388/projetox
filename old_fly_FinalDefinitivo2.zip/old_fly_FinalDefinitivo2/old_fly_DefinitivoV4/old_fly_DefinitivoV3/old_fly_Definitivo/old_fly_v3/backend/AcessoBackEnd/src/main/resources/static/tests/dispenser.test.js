'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { descreverStatus, estados } = require('../js/dispenser.js');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const conectado = { habilitado: true, configurado: true, online: true, permitirMotores: true, simulacao: false };

test('dispenser diferencia configuração, desconexão, simulação e operação', () => {
    assert.equal(descreverStatus({}).titulo, 'Configuração pendente');
    assert.equal(descreverStatus({ ...conectado, online: false }).titulo, 'Dispenser desconectado');
    assert.equal(descreverStatus({ ...conectado, simulacao: true }).titulo, 'Conectado em simulação');
    assert.equal(descreverStatus(conectado).titulo, 'Dispenser conectado');
    assert.equal(descreverStatus({ ...conectado, permitirMotores: false }).titulo, 'Motores desabilitados');
});

test('ciclo em andamento não é tratado como falha nem como remédio tomado', () => {
    assert.equal(descreverStatus({ ...conectado, emExecucao: true }).titulo, 'Ciclo em andamento');
    assert.equal(estados.CONCLUIDO, 'Ciclo do motor concluído');
    assert.doesNotMatch(estados.CONCLUIDO, /tomado|ingerido|entregue/);
});

test('pendência exige conferência mesmo quando o dispositivo volta a conectar', () => {
    assert.equal(descreverStatus({ ...conectado, conferenciaPendente: true }).titulo, 'Conferência necessária');
    assert.match(descreverStatus({ ...conectado, online: false }).detalhe, /não serão liberados automaticamente/);
});

function painelTeste(falharAoSalvar = false) {
    const elementos = new Map();
    function elemento(id) {
        if (!elementos.has(id)) elementos.set(id, {
            value: '', checked: false, disabled: false, hidden: false, dataset: {}, children: [], eventos: {},
            addEventListener(tipo, callback) { this.eventos[tipo] = callback; },
            replaceChildren() { this.children = []; },
            appendChild(filho) { this.children.push(filho); },
            reportValidity() { return true; },
            querySelector() { return elemento('salvar'); }
        });
        return elementos.get(id);
    }
    let iniciar;
    let atualizar;
    let salvo;
    let idosoAtual = 2;
    const document = {
        hidden: false, activeElement: null,
        getElementById: elemento,
        createElement: () => ({ value: '', textContent: '' }),
        addEventListener(tipo, callback) { iniciar = callback; }
    };
    const contexto = vm.createContext({
        window: { document }, document,
        getLoggedUser: () => ({ id: 1, perfil: 'admin' }),
        buscarUsuariosBackend: async () => [{ id: 2, nome: 'João', perfil: 'idoso' }, { id: 3, nome: 'Maria', perfil: 'idoso' }],
        mensagemDaOperacao: erro => erro.message,
        setInterval: callback => { atualizar = callback; },
        requestBackend: async (rota, opcoes) => {
            if (rota.endsWith('/vinculo')) {
                salvo = opcoes;
                if (falharAoSalvar) throw new Error('Conclua o ciclo pendente antes de trocar o idoso.');
                idosoAtual = JSON.parse(opcoes.body).idosoId;
                return null;
            }
            return { ...conectado, idosoId: idosoAtual, historico: [] };
        }
    });
    vm.runInContext(fs.readFileSync(path.join(__dirname, '../js/dispenser.js'), 'utf8'), contexto);
    iniciar();
    return { elemento, atualizar: () => atualizar(), salvo: () => salvo };
}

test('seleção de outro idoso persiste durante atualização e envia a sessão do administrador', async () => {
    const tela = painelTeste();
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(tela.elemento('dispenser-idoso').value, '2');
    tela.elemento('dispenser-idoso').value = '3';
    tela.elemento('dispenser-idoso').eventos.change();
    await tela.atualizar();
    assert.equal(tela.elemento('dispenser-idoso').value, '3');
    tela.elemento('dispenser-cargas-conferidas').checked = true;
    await tela.elemento('dispenser-vinculo-form').eventos.submit({ preventDefault() {} });
    assert.equal(tela.salvo().credentials, 'include');
    assert.deepEqual(JSON.parse(tela.salvo().body), { idosoId: 3, cargasConferidas: true });
    assert.match(tela.elemento('dispenser-vinculo-msg').textContent, /Vínculo salvo/);
});

test('falha ao trocar idoso mantém a escolha e mostra a pendência sem anunciar sucesso', async () => {
    const tela = painelTeste(true);
    await new Promise(resolve => setImmediate(resolve));
    tela.elemento('dispenser-idoso').value = '3';
    tela.elemento('dispenser-idoso').eventos.change();
    tela.elemento('dispenser-cargas-conferidas').checked = true;
    await tela.elemento('dispenser-vinculo-form').eventos.submit({ preventDefault() {} });
    assert.equal(tela.elemento('dispenser-idoso').value, '3');
    assert.match(tela.elemento('dispenser-vinculo-msg').textContent, /ciclo pendente/);
    assert.equal(tela.elemento('salvar').disabled, false);
});
