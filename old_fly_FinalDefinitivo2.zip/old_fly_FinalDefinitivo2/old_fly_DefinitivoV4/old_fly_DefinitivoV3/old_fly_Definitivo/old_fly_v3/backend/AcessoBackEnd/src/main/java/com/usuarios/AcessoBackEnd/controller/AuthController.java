package com.usuarios.AcessoBackEnd.controller;

import com.usuarios.AcessoBackEnd.dto.LoginDTO;
import com.usuarios.AcessoBackEnd.dto.UsuarioSistemaDTO;
import com.usuarios.AcessoBackEnd.service.AuthService;
import com.usuarios.AcessoBackEnd.service.DispositivoService;
import com.usuarios.AcessoBackEnd.service.SessaoAdminService;
import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/auth")
@CrossOrigin(originPatterns = "*", allowCredentials = "true")
public class AuthController {

    private static final String COOKIE_SESSAO = "oldfly_session";
    private static final String COOKIE_DISPOSITIVO = "oldfly_device";

    @Autowired
    private AuthService service;

    @Autowired
    private DispositivoService dispositivoService;

    @Autowired
    private SessaoAdminService sessaoAdminService;

    @Value("${oldfly.cookie.secure:false}")
    private boolean cookieSecure;

    @PostMapping("/login")
    public ResponseEntity<UsuarioSistemaDTO> login(@Valid @RequestBody LoginDTO dto, HttpServletResponse response) {
        UsuarioSistemaDTO usuario = service.login(dto);

        if (usuario == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        if ("admin".equals(usuario.getPerfil())) {
            adicionarCookie(response, "oldfly_admin_session", sessaoAdminService.criar(usuario.getId()), 8 * 60 * 60);
        } else {
            adicionarCookie(response, "oldfly_admin_session", "", 0);
        }

        String sessaoCuidador = service.criarSessaoCuidador(dto);
        if (sessaoCuidador != null) {
            adicionarCookie(response, COOKIE_SESSAO, sessaoCuidador, 8 * 60 * 60);
        }
        return ResponseEntity.ok(usuario);
    }

    @PostMapping("/dispositivo/autorizar/{idosoId}")
    public ResponseEntity<UsuarioSistemaDTO> autorizarDispositivo(
            @PathVariable int idosoId,
            HttpServletRequest request,
            HttpServletResponse response) {
        UsuarioCuidador cuidador = service.obterCuidadorDaSessao(cookie(request, COOKIE_SESSAO));
        if (cuidador == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        try {
            DispositivoService.CredencialDispositivo credencial = dispositivoService.autorizar(cuidador, idosoId);
            adicionarCookie(response, COOKIE_DISPOSITIVO, credencial.token(), 365 * 24 * 60 * 60);
            return ResponseEntity.ok(service.usuarioDoDispositivo(credencial.idoso()));
        } catch (SecurityException erro) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        } catch (IllegalArgumentException erro) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/dispositivo")
    public ResponseEntity<UsuarioSistemaDTO> reconhecerDispositivo(HttpServletRequest request) {
        UsuarioIdoso idoso = dispositivoService.reconhecer(cookie(request, COOKIE_DISPOSITIVO));
        return idoso == null
                ? ResponseEntity.status(HttpStatus.UNAUTHORIZED).build()
                : ResponseEntity.ok(service.usuarioDoDispositivo(idoso));
    }

    @DeleteMapping("/dispositivo")
    public ResponseEntity<Void> bloquearDispositivo(
            HttpServletRequest request,
            HttpServletResponse response) {
        UsuarioCuidador cuidador = service.obterCuidadorDaSessao(cookie(request, COOKIE_SESSAO));
        if (cuidador == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        boolean revogado = dispositivoService.revogar(cookie(request, COOKIE_DISPOSITIVO), cuidador);
        if (!revogado) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();

        adicionarCookie(response, COOKIE_DISPOSITIVO, "", 0);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/usuarios")
    public List<UsuarioSistemaDTO> listarUsuarios() {
        return service.listarUsuarios();
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(HttpServletRequest request, HttpServletResponse response) {
        sessaoAdminService.encerrar(cookie(request, "oldfly_admin_session"));
        adicionarCookie(response, "oldfly_admin_session", "", 0);
        adicionarCookie(response, COOKIE_SESSAO, "", 0);
        return ResponseEntity.noContent().build();
    }

    private void adicionarCookie(HttpServletResponse response, String nome, String valor, long maxAge) {
        ResponseCookie cookie = ResponseCookie.from(nome, valor)
                .httpOnly(true)
                .secure(cookieSecure)
                .sameSite("Strict")
                .path("/")
                .maxAge(maxAge)
                .build();
        response.addHeader("Set-Cookie", cookie.toString());
    }

    private String cookie(HttpServletRequest request, String nome) {
        if (request.getCookies() == null) return null;
        for (Cookie cookie : request.getCookies()) {
            if (nome.equals(cookie.getName())) return cookie.getValue();
        }
        return null;
    }
}
