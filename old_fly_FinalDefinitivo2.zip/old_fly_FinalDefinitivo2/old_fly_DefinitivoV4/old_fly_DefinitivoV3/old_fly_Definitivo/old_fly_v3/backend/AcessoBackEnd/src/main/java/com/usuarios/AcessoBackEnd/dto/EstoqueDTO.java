package com.usuarios.AcessoBackEnd.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

public class EstoqueDTO {

    @Min(value = 0, message = "A quantidade atual não pode ser negativa")
    @Max(value = 99999, message = "A quantidade atual não pode exceder 99999")
    private int quantidadeAtual;

    @Min(value = 1, message = "A quantidade mínima deve ser pelo menos 1")
    @Max(value = 999, message = "A quantidade mínima deve ser no máximo 999")
    private int quantidadeMinima;

    public int getQuantidadeAtual() { return quantidadeAtual; }
    public void setQuantidadeAtual(int quantidadeAtual) { this.quantidadeAtual = quantidadeAtual; }
    public int getQuantidadeMinima() { return quantidadeMinima; }
    public void setQuantidadeMinima(int quantidadeMinima) { this.quantidadeMinima = quantidadeMinima; }
}

