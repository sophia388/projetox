'use strict';

const assert = require('node:assert/strict');
const schedule = require('../js/schedule.js');

function teste(nome, executar) {
    executar();
    console.log('\u2713 ' + nome);
}

teste('normaliza horários com uma ou duas casas na hora', () => {
    assert.equal(schedule.normalizarHorario('8:05'), '08:05');
    assert.equal(schedule.normalizarHorario(' 08:05 '), '08:05');
    assert.equal(schedule.normalizarHorario('23:59'), '23:59');
});

teste('rejeita horários e formatos inválidos', () => {
    ['24:00', '12:60', '-1:00', '8:5', '8h00', '', null, undefined].forEach((valor) => {
        assert.equal(schedule.normalizarHorario(valor), '');
    });

    assert.deepEqual(schedule.gerarHorarios('24:00', 2), []);
    assert.deepEqual(schedule.gerarHorarios('08:00', 0), []);
    assert.deepEqual(schedule.gerarHorarios('08:00', -2), []);
    assert.deepEqual(schedule.gerarHorarios('08:00', 5), []);
    assert.deepEqual(schedule.gerarHorarios('08:00', 1.5), []);
});

teste('extrai H:mm, HH:mm e a notação 8h00', () => {
    assert.deepEqual(
        schedule.extrairHorarios('Tomar às 8h00, repetir 9:30 e finalizar 18:05.'),
        ['08:00', '09:30', '18:05']
    );
});

teste('remove duplicatas, ignora inválidos e ordena horários', () => {
    assert.deepEqual(
        schedule.extrairHorarios('20:00, 8:00, 08h00, 25:00, 12:70, 14:15, 20:00'),
        ['08:00', '14:15', '20:00']
    );
    assert.deepEqual(schedule.extrairHorarios(null), []);
});

teste('gera um dia completo e cruza a meia-noite', () => {
    assert.deepEqual(
        schedule.gerarHorarios('22:30', 4),
        ['02:30', '06:30', '10:30', '14:30', '18:30', '22:30']
    );
    assert.deepEqual(schedule.gerarHorarios('00:00', '6'), ['00:00', '06:00', '12:00', '18:00']);
});

teste('serializa uma lista normalizada, única e ordenada', () => {
    assert.equal(
        schedule.serializarHorarios(['20:00', '8:00', '08:00', 'inválido', '12:30']),
        '08:00, 12:30, 20:00'
    );
    assert.equal(schedule.serializarHorarios('08:00'), '');
});

teste('formata hora e data usando o fuso local do Date', () => {
    const data = new Date(2026, 7, 24, 7, 5, 30);
    assert.equal(schedule.horaAtual(data), '07:05');
    assert.equal(schedule.dataLocalISO(data), '2026-08-24');
    assert.equal(schedule.horaAtual(new Date('inválida')), '');
    assert.equal(schedule.dataLocalISO(new Date('inválida')), '');
});

teste('filtra medicamentos pelo campo horario', () => {
    const medicamentos = [
        { id: 1, nome: 'A', horario: '08:00, 20:00' },
        { id: 2, nome: 'B', horario: '8h00 e 12:00' },
        { id: 3, nome: 'C', horario: '09:00' },
        { id: 4, nome: 'Sem horário' },
        null
    ];

    assert.deepEqual(
        schedule.medicamentosNoHorario(medicamentos, '8:00').map((medicamento) => medicamento.id),
        [1, 2]
    );
    assert.deepEqual(schedule.medicamentosNoHorario(medicamentos, '25:00'), []);
    assert.deepEqual(schedule.medicamentosNoHorario(null, '08:00'), []);
});

teste('calcula os dois próximos alarmes em ordem e agrupa horários iguais', () => {
    const medicamentos = [
        { id: 1, nome: 'Losartana', horario: '08:00, 20:00' },
        { id: 2, nome: 'Vitamina', horario: '20:00' },
        { id: 3, nome: 'Metformina', horario: '12:00' }
    ];
    const proximos = schedule.proximosAlarmes(medicamentos, new Date(2026, 7, 24, 11, 30, 0), 2);

    assert.equal(proximos.length, 2);
    assert.equal(proximos[0].horario, '12:00');
    assert.deepEqual(proximos[0].medicamentos.map(item => item.id), [3]);
    assert.equal(proximos[0].emMs, 30 * 60 * 1000);
    assert.equal(proximos[1].horario, '20:00');
    assert.deepEqual(proximos[1].medicamentos.map(item => item.id), [1, 2]);
});

teste('mantém o alarme do minuto atual e encontra a recorrência seguinte', () => {
    const medicamento = { id: 1, nome: 'Losartana', horario: '08:00' };
    const proximos = schedule.proximosAlarmes([medicamento], new Date(2026, 7, 24, 8, 0, 35), 2);

    assert.equal(proximos[0].tocandoAgora, true);
    assert.equal(proximos[0].emMs, 0);
    assert.equal(proximos[1].tocandoAgora, false);
    assert.equal(proximos[1].horario, '08:00');
    assert.equal(proximos[1].data.getDate(), 25);
});

console.log('Todos os testes de schedule passaram.');
