package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.dto.UsuarioIdosoDTO;
import com.usuarios.AcessoBackEnd.entity.Admin;
import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.AdminRepository;
import com.usuarios.AcessoBackEnd.repository.MedicamentoRepository;
import com.usuarios.AcessoBackEnd.repository.ReceitaRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioCuidadorRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.usuarios.AcessoBackEnd.repository.DispositivoAutorizadoRepository;
import com.usuarios.AcessoBackEnd.repository.ComandoDispenserRepository;

import java.util.List;

@Service
public class UsuarioIdosoService {

    @Autowired
    private UsuarioIdosoRepository repository;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private UsuarioCuidadorRepository cuidadorRepository;

    @Autowired
    private MedicamentoRepository medicamentoRepository;

    @Autowired
    private ReceitaRepository receitaRepository;

    @Autowired
    private UsuarioValidacaoService validacaoService;

    @Autowired
    private DispositivoAutorizadoRepository dispositivoRepository;

    @Autowired
    private ComandoDispenserRepository comandoDispenserRepository;

    @Autowired
    private VinculoDispenserService vinculoDispenser;

    public UsuarioIdoso cadastrar(UsuarioIdosoDTO dto) {
        String usuario = dto.getUsuario() == null || dto.getUsuario().isBlank() ? dto.getEmail() : dto.getUsuario();
        validacaoService.validarUnicidade(usuario, dto.getEmail(), "idoso", null);
        validacaoService.validarSenhaCadastro(dto.getSenha());
        validarVinculos(dto);

        UsuarioIdoso idoso = new UsuarioIdoso();
        preencher(idoso, dto);
        return repository.save(idoso);
    }

    public List<UsuarioIdoso> listar() {
        return repository.findAll();
    }

    public UsuarioIdoso buscarPorId(int id) {
        return repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Idoso não encontrado"));
    }

    public UsuarioIdoso atualizar(int id, UsuarioIdosoDTO dto) {
        UsuarioIdoso idoso = buscarPorId(id);
        String usuario = dto.getUsuario() == null || dto.getUsuario().isBlank() ? dto.getEmail() : dto.getUsuario();
        validacaoService.validarUnicidade(usuario, dto.getEmail(), "idoso", id);
        validacaoService.validarSenhaAtualizacao(dto.getSenha());
        validarVinculos(dto);

        preencher(idoso, dto);
        return repository.save(idoso);
    }

    private void validarVinculos(UsuarioIdosoDTO dto) {
        if (dto.getAdminId() > 0 && adminRepository.findById(dto.getAdminId()).isEmpty()) {
            throw new IllegalArgumentException("O administrador selecionado não foi encontrado no sistema.");
        }
    }


    @Transactional
    public void remover(int id) {
        var vinculo = vinculoDispenser.bloquear();
        if (vinculo.getIdosoId() == id) {
            vinculo.setIdosoId(0);
            vinculo.setAtivarAPartirDe(null);
        }
        UsuarioIdoso idoso = buscarPorId(id);

        dispositivoRepository.deleteByIdosoId(id);
        comandoDispenserRepository.deleteByIdosoId(id);

        for (UsuarioCuidador cuidador : cuidadorRepository.findByIdosoId(id)) {
            cuidador.setIdoso(null);
            cuidadorRepository.save(cuidador);
        }

        // A remoção por entidade também exclui o estoque pelo cascade do medicamento.
        medicamentoRepository.deleteAll(medicamentoRepository.findByIdosoId(id));
        receitaRepository.deleteAll(receitaRepository.findByIdosoId(id));

        repository.delete(idoso);
    }

    private void preencher(UsuarioIdoso idoso, UsuarioIdosoDTO dto) {
        Admin admin = dto.getAdminId() > 0 ? adminRepository.findById(dto.getAdminId()).orElse(null) : null;
        idoso.setNome(dto.getNome());
        idoso.setIdade(dto.getIdade());
        idoso.setUsuario(dto.getUsuario() == null || dto.getUsuario().isBlank() ? dto.getEmail() : dto.getUsuario());
        idoso.setEmail(dto.getEmail());
        if (dto.getSenha() != null && !dto.getSenha().isBlank()) {
            idoso.setSenha(dto.getSenha());
        }
        idoso.setDebilitado(dto.isDebilitado());
        idoso.setAdmin(admin);
    }
}
