package com.usuarios.AcessoBackEnd.repository;

import com.usuarios.AcessoBackEnd.entity.DispositivoAutorizado;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DispositivoAutorizadoRepository extends JpaRepository<DispositivoAutorizado, Integer> {
    void deleteByIdosoId(int idosoId);
    void deleteByCuidadorId(int cuidadorId);
    Optional<DispositivoAutorizado> findByTokenHashAndAtivoTrue(String tokenHash);
}
