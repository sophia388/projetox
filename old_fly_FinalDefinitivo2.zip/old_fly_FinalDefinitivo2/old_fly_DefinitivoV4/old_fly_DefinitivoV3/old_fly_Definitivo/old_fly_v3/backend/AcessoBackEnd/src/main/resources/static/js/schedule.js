(function (root, factory) {
    'use strict';

    var api = factory();

    if (typeof module === 'object' && module.exports) {
        module.exports = api;
    } else {
        root.OldFlySchedule = api;
    }
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
    'use strict';

    var MINUTOS_POR_DIA = 24 * 60;

    function doisDigitos(valor) {
        return valor < 10 ? '0' + valor : String(valor);
    }

    function normalizarHorario(valor) {
        if (typeof valor !== 'string') {
            return '';
        }

        var correspondencia = valor.trim().match(/^(\d{1,2}):(\d{2})$/);
        if (!correspondencia) {
            return '';
        }

        var horas = Number(correspondencia[1]);
        var minutos = Number(correspondencia[2]);

        if (horas < 0 || horas > 23 || minutos < 0 || minutos > 59) {
            return '';
        }

        return doisDigitos(horas) + ':' + doisDigitos(minutos);
    }

    function extrairHorarios(texto) {
        if (typeof texto !== 'string') {
            return [];
        }

        var encontrados = new Set();
        var padrao = /(^|[^\d:])(\d{1,2})(?::|[hH])(\d{2})(?![\d:])/g;
        var correspondencia;

        while ((correspondencia = padrao.exec(texto)) !== null) {
            var horario = normalizarHorario(correspondencia[2] + ':' + correspondencia[3]);
            if (horario) {
                encontrados.add(horario);
            }
        }

        return Array.from(encontrados).sort();
    }

    function gerarHorarios(inicio, intervaloHoras) {
        var horarioInicial = normalizarHorario(inicio);
        var tipoValido = typeof intervaloHoras === 'number' || typeof intervaloHoras === 'string';
        var intervalo = tipoValido && String(intervaloHoras).trim() !== ''
            ? Number(intervaloHoras)
            : NaN;

        if (!horarioInicial || !Number.isInteger(intervalo) || intervalo <= 0 || 24 % intervalo !== 0) {
            return [];
        }

        var partes = horarioInicial.split(':');
        var inicioEmMinutos = Number(partes[0]) * 60 + Number(partes[1]);
        var passoEmMinutos = intervalo * 60;
        var quantidade = 24 / intervalo;
        var horarios = new Set();

        for (var indice = 0; indice < quantidade; indice += 1) {
            var total = (inicioEmMinutos + indice * passoEmMinutos) % MINUTOS_POR_DIA;
            horarios.add(doisDigitos(Math.floor(total / 60)) + ':' + doisDigitos(total % 60));
        }

        return Array.from(horarios).sort();
    }

    function serializarHorarios(lista) {
        if (!Array.isArray(lista)) {
            return '';
        }

        return extrairHorarios(lista.join(', ')).join(', ');
    }

    function dataValida(data) {
        var resultado = typeof data === 'undefined' ? new Date() : data;

        if (!(resultado instanceof Date)) {
            resultado = new Date(resultado);
        }

        return Number.isNaN(resultado.getTime()) ? null : resultado;
    }

    function horaAtual(data) {
        var atual = dataValida(data);
        if (!atual) {
            return '';
        }

        return doisDigitos(atual.getHours()) + ':' + doisDigitos(atual.getMinutes());
    }

    function dataLocalISO(data) {
        var atual = dataValida(data);
        if (!atual) {
            return '';
        }

        return atual.getFullYear()
            + '-' + doisDigitos(atual.getMonth() + 1)
            + '-' + doisDigitos(atual.getDate());
    }

    function medicamentosNoHorario(medicamentos, horario) {
        if (!Array.isArray(medicamentos)) {
            return [];
        }

        var horarioNormalizado = normalizarHorario(horario);
        if (!horarioNormalizado) {
            return [];
        }

        return medicamentos.filter(function (medicamento) {
            return medicamento
                && extrairHorarios(medicamento.horario).indexOf(horarioNormalizado) !== -1;
        });
    }

    function proximosAlarmes(medicamentos, dataReferencia, limite) {
        var agora = dataValida(dataReferencia);
        if (!agora || !Array.isArray(medicamentos)) {
            return [];
        }

        var quantidade = Number.isInteger(Number(limite)) && Number(limite) > 0
            ? Math.min(Number(limite), 10)
            : 2;
        var ocorrencias = [];

        medicamentos.forEach(function (medicamento, indiceMedicamento) {
            if (!medicamento || typeof medicamento !== 'object') return;

            extrairHorarios(medicamento.horario || '').forEach(function (horario) {
                var partes = horario.split(':').map(Number);

                for (var dia = 0; dia < 3; dia += 1) {
                    var dataAlarme = new Date(
                        agora.getFullYear(),
                        agora.getMonth(),
                        agora.getDate() + dia,
                        partes[0],
                        partes[1],
                        0,
                        0
                    );
                    var mesmoMinuto = dia === 0
                        && agora.getHours() === partes[0]
                        && agora.getMinutes() === partes[1];
                    var emMs = mesmoMinuto ? 0 : dataAlarme.getTime() - agora.getTime();
                    if (emMs < 0) continue;

                    ocorrencias.push({
                        data: dataAlarme,
                        horario: horario,
                        emMs: emMs,
                        tocandoAgora: mesmoMinuto,
                        medicamento: medicamento,
                        chaveMedicamento: medicamento.id != null
                            ? String(medicamento.id)
                            : String(indiceMedicamento) + ':' + String(medicamento.nome || '')
                    });
                }
            });
        });

        ocorrencias.sort(function (primeiro, segundo) {
            return primeiro.emMs - segundo.emMs
                || primeiro.horario.localeCompare(segundo.horario)
                || String(primeiro.medicamento.nome || '').localeCompare(String(segundo.medicamento.nome || ''));
        });

        var grupos = [];
        ocorrencias.forEach(function (ocorrencia) {
            var grupo = grupos.find(function (item) {
                return item.data.getTime() === ocorrencia.data.getTime();
            });

            if (!grupo) {
                grupo = {
                    data: ocorrencia.data,
                    horario: ocorrencia.horario,
                    emMs: ocorrencia.emMs,
                    tocandoAgora: ocorrencia.tocandoAgora,
                    medicamentos: [],
                    chavesMedicamentos: new Set()
                };
                grupos.push(grupo);
            }

            if (!grupo.chavesMedicamentos.has(ocorrencia.chaveMedicamento)) {
                grupo.chavesMedicamentos.add(ocorrencia.chaveMedicamento);
                grupo.medicamentos.push(ocorrencia.medicamento);
            }
        });

        return grupos.slice(0, quantidade).map(function (grupo) {
            return {
                data: grupo.data,
                horario: grupo.horario,
                emMs: grupo.emMs,
                tocandoAgora: grupo.tocandoAgora,
                medicamentos: grupo.medicamentos
            };
        });
    }

    return {
        normalizarHorario: normalizarHorario,
        extrairHorarios: extrairHorarios,
        gerarHorarios: gerarHorarios,
        serializarHorarios: serializarHorarios,
        horaAtual: horaAtual,
        dataLocalISO: dataLocalISO,
        medicamentosNoHorario: medicamentosNoHorario,
        proximosAlarmes: proximosAlarmes
    };
}));
