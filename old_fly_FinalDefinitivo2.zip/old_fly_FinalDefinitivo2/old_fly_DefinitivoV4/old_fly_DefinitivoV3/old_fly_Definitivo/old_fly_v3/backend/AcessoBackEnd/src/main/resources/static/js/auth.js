const API_HOST = window.location.hostname || 'localhost';
const API_URL = `http://${API_HOST}:8080`;

function ehAntibiotico(categoria) {
    return String(categoria ?? '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .includes('antibiotico');
}

function classificarEstoque(quantidadeAtual, quantidadeMinima, referenciaAntibiotico = false) {
    const atualInformado = Number(quantidadeAtual);
    const minimoInformado = Number(quantidadeMinima);
    const atual = Number.isFinite(atualInformado) ? Math.max(0, atualInformado) : 0;
    const minimo = Number.isFinite(minimoInformado) && minimoInformado > 0 ? minimoInformado : 5;

    if (atual === 0) return { cor: 'gray', rotulo: 'Acabou' };
    if (atual <= minimo) return { cor: 'red', rotulo: 'Acabando' };
    if (atual <= minimo * 2) return { cor: 'yellow', rotulo: 'Médio' };
    const antibiotico = typeof referenciaAntibiotico === 'boolean'
        ? referenciaAntibiotico
        : ehAntibiotico(referenciaAntibiotico);
    return antibiotico
        ? { cor: 'blue', rotulo: 'Cheio (antibiótico)' }
        : { cor: 'green', rotulo: 'Suficiente' };
}

async function requestBackend(rota, opcoes = {}) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);
    let resposta;
    let texto;
    try {
        resposta = await fetch(`${API_URL}${rota}`, {
            ...opcoes,
            headers: { 'Content-Type': 'application/json', ...(opcoes.headers || {}) },
            signal: controller.signal
        });
        texto = await resposta.text();
    } catch (causa) {
        const consulta = !opcoes.method || opcoes.method === 'GET';
        const erro = new Error(consulta
            ? 'Não foi possível carregar os dados. Verifique a conexão e tente novamente.'
            : 'A confirmação não chegou. Atualize a página para conferir se a operação foi concluída antes de tentar novamente.');
        erro.status = 0;
        throw erro;
    } finally {
        clearTimeout(timeout);
    }

    if (!resposta.ok) {
        var mensagemErro = resposta.status === 401
            ? 'Sua sessão expirou. Entre novamente para continuar.'
            : resposta.status === 403
                ? 'Sua conta não tem permissão para realizar esta ação.'
                : resposta.status === 404
                    ? 'Este registro não está mais disponível. Atualize a página.'
                    : 'Não foi possível concluir a operação agora. Confira os dados e tente novamente.';
        var errosCampos = null;
        try {
            var corpoTexto = texto;
            if (corpoTexto) {
                var corpoJson = JSON.parse(corpoTexto);
                if (resposta.status < 500 && corpoJson && corpoJson.message) {
                    mensagemErro = corpoJson.message;
                } else if (resposta.status < 500 && typeof corpoJson === 'string') {
                    mensagemErro = corpoJson;
                }
                if (corpoJson && corpoJson.errors) {
                    errosCampos = corpoJson.errors;
                }
            }
        } catch (ignored) {}

        var erro = new Error(mensagemErro);
        erro.status = resposta.status;
        if (errosCampos) erro.errors = errosCampos;
        throw erro;
    }

    if (resposta.status === 204) {
        return null;
    }

    try {
        return texto ? JSON.parse(texto) : null;
    } catch (causa) {
        const erro = new Error('Não foi possível confirmar a resposta. Atualize a página para conferir os dados.');
        erro.status = resposta.status;
        throw erro;
    }
}

function mensagemDaOperacao(erro, alternativa = 'Não foi possível concluir a operação. Tente novamente.') {
    return erro && typeof erro.status === 'number' && erro.message ? erro.message : alternativa;
}

async function loginBackend(usuario, senha) {
    try {
        return await requestBackend('/auth/login', {
            method: 'POST', credentials: 'include', body: JSON.stringify({ usuario, senha })
        });
    } catch (erro) {
        if (erro.status === 401) return null;
        throw erro;
    }
}

async function reconhecerDispositivoBackend() {
    try {
        return await requestBackend('/auth/dispositivo', { credentials: 'include' });
    } catch (erro) {
        if (erro.status === 401) return null;
        throw erro;
    }
}

async function autorizarDispositivoBackend(idosoId) {
    return requestBackend(`/auth/dispositivo/autorizar/${idosoId}`, {
        method: 'POST',
        credentials: 'include'
    });
}

async function bloquearDispositivoBackend() {
    return requestBackend('/auth/dispositivo', {
        method: 'DELETE',
        credentials: 'include'
    });
}

async function buscarUsuariosBackend() {
    return requestBackend('/auth/usuarios');
}

function rotaUsuario(perfil) {
    const rotas = {
        admin: '/admin',
        cuidador: '/cuidador',
        idoso: '/idoso'
    };

    return rotas[perfil];
}

function montarCorpoUsuario(dados) {
    const corpo = {
        nome: dados.nome,
        idade: Number(dados.idade),
        usuario: dados.usuario,
        email: dados.email,
        senha: dados.senha || ''
    };

    if (dados.perfil === 'idoso') {
        corpo.adminId = Number(dados.adminId || 0);
        corpo.debilitado = dados.debilitado === true;
    }

    if (dados.perfil === 'cuidador') {
        corpo.adminId = Number(dados.adminId || 0);
        corpo.idosoId = Number(dados.idosoId || 0);
    }

    return corpo;
}

async function cadastrarUsuarioBackend(dados) {
    const rota = rotaUsuario(dados.perfil);
    if (!rota) throw new Error('Tipo de usuário inválido');

    return requestBackend(rota, {
        method: 'POST',
        body: JSON.stringify(montarCorpoUsuario(dados))
    });
}

async function atualizarUsuarioBackend(id, perfil, dados) {
    const rota = rotaUsuario(perfil);
    if (!rota) throw new Error('Tipo de usuário inválido');

    return requestBackend(`${rota}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(montarCorpoUsuario({ ...dados, perfil }))
    });
}

async function excluirUsuarioBackend(id, perfil) {
    const rota = rotaUsuario(perfil);
    if (!rota) throw new Error('Tipo de usuário inválido');

    return requestBackend(`${rota}/${id}`, { method: 'DELETE' });
}

async function buscarMedicamentosBackend() {
    return requestBackend('/medicamentos');
}

async function buscarMedicamentoBackend(id) {
    return requestBackend(`/medicamentos/${id}`);
}

async function salvarMedicamentoBackend(dados, id = null) {
    const antibiotico = typeof dados.antibiotico === 'boolean'
        ? dados.antibiotico
        : ehAntibiotico(dados.categoria);
    const statusEstoque = classificarEstoque(
        dados.quantidadeAtual,
        dados.quantidadeMinima,
        antibiotico
    );
    const corpo = {
        nome: dados.nome,
        dosagem: dados.dosagem,
        categoria: dados.categoria,
        horario: dados.horario,
        tipoUso: dados.tipoUso,
        cor: statusEstoque.cor,
        idosoId: Number(dados.idosoId || 0),
        quantidadeAtual: Number(dados.quantidadeAtual || 0),
        quantidadeMinima: Number(dados.quantidadeMinima ?? 5),
        antibiotico,
        dataInicioTratamento: antibiotico ? (dados.dataInicioTratamento || null) : null,
        duracaoTratamentoDias: antibiotico ? Number(dados.duracaoTratamentoDias || 5) : null
    };

    return requestBackend(id ? `/medicamentos/${id}` : '/medicamentos', {
        method: id ? 'PUT' : 'POST',
        body: JSON.stringify(corpo)
    });
}

async function excluirMedicamentoBackend(id) {
    return requestBackend(`/medicamentos/${id}`, { method: 'DELETE' });
}

async function atualizarEstoqueBackend(id, quantidadeAtual, quantidadeMinima) {
    return requestBackend(`/estoque/medicamento/${id}`, {
        method: 'PUT',
        body: JSON.stringify({
            quantidadeAtual: Number(quantidadeAtual),
            quantidadeMinima: Number(quantidadeMinima)
        })
    });
}

async function buscarReceitasBackend() {
    return requestBackend('/receitas');
}

async function salvarReceitaBackend(dados, id = null) {
    const corpo = {
        medico: dados.medico,
        dataReceita: dados.dataReceita,
        medicamentos: dados.medicamentos,
        observacoes: dados.observacoes,
        arquivoNome: dados.arquivoNome,
        idosoId: Number(dados.idosoId || 0)
    };

    return requestBackend(id ? `/receitas/${id}` : '/receitas', {
        method: id ? 'PUT' : 'POST',
        body: JSON.stringify(corpo)
    });
}

async function excluirReceitaBackend(id) {
    return requestBackend(`/receitas/${id}`, { method: 'DELETE' });
}

function getLoggedUser() {
    const dados = localStorage.getItem('oldfly_logged_user');
    if (!dados) return null;

    try {
        return JSON.parse(dados);
    } catch (erro) {
        clearLoggedUser();
        return null;
    }
}

function setLoggedUser(user) {
    localStorage.setItem('oldfly_logged_user', JSON.stringify(user));
}

function clearLoggedUser() {
    requestBackend('/auth/logout', { method: 'POST', credentials: 'include' }).catch(() => {});
    localStorage.removeItem('oldfly_logged_user');
    localStorage.removeItem('oldfly_viewing_user');
}

function getViewingUser() {
    const loggedUser = getLoggedUser();
    if (!loggedUser) return null;

    if (loggedUser.perfil !== 'admin') return loggedUser;

    const dados = localStorage.getItem('oldfly_viewing_user');
    if (!dados) return loggedUser;

    try {
        return JSON.parse(dados);
    } catch (erro) {
        return loggedUser;
    }
}

function setViewingUser(user) {
    localStorage.setItem('oldfly_viewing_user', JSON.stringify(user));
}

function roleLabel(role) {
    const labels = {
        admin: 'Administrador',
        cuidador: 'Cuidador',
        idoso: 'Idoso'
    };

    return labels[role] || role;
}
