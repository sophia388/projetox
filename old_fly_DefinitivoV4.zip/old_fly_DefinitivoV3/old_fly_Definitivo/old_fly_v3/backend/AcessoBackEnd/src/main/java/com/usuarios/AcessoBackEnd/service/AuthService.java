package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.dto.LoginDTO;
import com.usuarios.AcessoBackEnd.dto.UsuarioSistemaDTO;
import com.usuarios.AcessoBackEnd.entity.Admin;
import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.entity.SessaoCuidador;
import com.usuarios.AcessoBackEnd.repository.AdminRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioCuidadorRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import com.usuarios.AcessoBackEnd.repository.SessaoCuidadorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.security.SecureRandom;
import java.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;

@Service
public class AuthService {

    private final SecureRandom secureRandom = new SecureRandom();

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private UsuarioCuidadorRepository cuidadorRepository;

    @Autowired
    private UsuarioIdosoRepository idosoRepository;

    @Autowired
    private SessaoCuidadorRepository sessaoRepository;

    public UsuarioSistemaDTO login(LoginDTO dto) {
        Optional<Admin> admin = adminRepository.findByUsuarioAndSenha(dto.getUsuario(), dto.getSenha());
        if (admin.isPresent()) {
            return toDTO(admin.get());
        }

        Optional<UsuarioCuidador> cuidador = cuidadorRepository.findByUsuarioAndSenha(dto.getUsuario(), dto.getSenha());
        if (cuidador.isPresent()) {
            return toDTO(cuidador.get());
        }

        Optional<UsuarioIdoso> idoso = idosoRepository.findByUsuarioAndSenha(dto.getUsuario(), dto.getSenha());
        if (idoso.isPresent()) {
            return toDTO(idoso.get());
        }

        return null;
    }

    public List<UsuarioSistemaDTO> listarUsuarios() {
        List<UsuarioSistemaDTO> usuarios = new ArrayList<>();
        adminRepository.findAll().forEach(admin -> usuarios.add(toDTO(admin)));
        cuidadorRepository.findAll().forEach(cuidador -> usuarios.add(toDTO(cuidador)));
        idosoRepository.findAll().forEach(idoso -> usuarios.add(toDTO(idoso)));
        return usuarios;
    }

    public String criarSessaoCuidador(LoginDTO dto) {
        return cuidadorRepository.findByUsuarioAndSenha(dto.getUsuario(), dto.getSenha())
                .map(cuidador -> {
                    byte[] bytes = new byte[32];
                    secureRandom.nextBytes(bytes);
                    String token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
                    SessaoCuidador sessao = new SessaoCuidador();
                    sessao.setTokenHash(hash(token));
                    sessao.setCuidador(cuidador);
                    sessao.setExpiraEm(LocalDateTime.now().plusHours(8));
                    sessaoRepository.save(sessao);
                    return token;
                })
                .orElse(null);
    }

    public UsuarioCuidador obterCuidadorDaSessao(String token) {
        if (token == null || token.isBlank()) return null;
        return sessaoRepository.findByTokenHashAndExpiraEmAfter(hash(token), LocalDateTime.now())
                .map(SessaoCuidador::getCuidador)
                .orElse(null);
    }

    private String hash(String token) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(token.getBytes(StandardCharsets.UTF_8));
            return java.util.HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException erro) {
            throw new IllegalStateException("SHA-256 não está disponível", erro);
        }
    }

    public UsuarioSistemaDTO usuarioDoDispositivo(UsuarioIdoso idoso) {
        return toDTO(idoso);
    }

    private UsuarioSistemaDTO toDTO(Admin admin) {
        return new UsuarioSistemaDTO(
                admin.getId(),
                admin.getNome(),
                admin.getIdade(),
                admin.getUsuario(),
                admin.getEmail(),
                "admin",
                "Administrador geral do sistema",
                "Acessa usuários, remédios, receitas e estoque",
                null,
                null,
                false
        );
    }

    private UsuarioSistemaDTO toDTO(UsuarioCuidador cuidador) {
        Integer idosoId = cuidador.getIdoso() != null ? cuidador.getIdoso().getId() : null;
        String nomeIdoso = cuidador.getIdoso() != null ? cuidador.getIdoso().getNome() : null;

        return new UsuarioSistemaDTO(
                cuidador.getId(),
                cuidador.getNome(),
                cuidador.getIdade(),
                cuidador.getUsuario(),
                cuidador.getEmail(),
                "cuidador",
                "Responsável pelo acompanhamento do idoso",
                "Pode acompanhar remédios, receitas e estoque",
                idosoId,
                nomeIdoso,
                cuidador.getIdoso() != null && cuidador.getIdoso().isDebilitado()
        );
    }

    private UsuarioSistemaDTO toDTO(UsuarioIdoso idoso) {
        return new UsuarioSistemaDTO(
                idoso.getId(),
                idoso.getNome(),
                idoso.getIdade(),
                idoso.getUsuario(),
                idoso.getEmail(),
                "idoso",
                "Usuário principal do dispenser",
                "Pode visualizar seus próprios remédios e receitas",
                null,
                null,
                idoso.isDebilitado()
        );
    }
}
