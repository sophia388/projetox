package com.usuarios.AcessoBackEnd.controller;

import com.usuarios.AcessoBackEnd.entity.ComandoDispenser;
import com.usuarios.AcessoBackEnd.service.DispenserFisicoService;
import com.usuarios.AcessoBackEnd.service.SessaoAdminService;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/dispenser")
public class DispenserFisicoController {
    private final DispenserFisicoService service;
    private final SessaoAdminService sessoes;
    public DispenserFisicoController(DispenserFisicoService service, SessaoAdminService sessoes) {
        this.service = service; this.sessoes = sessoes;
    }

    public record VinculoDTO(int idosoId, boolean cargasConferidas) { }

    @PutMapping("/vinculo")
    @CrossOrigin(originPatterns = "*", allowCredentials = "true")
    public ResponseEntity<Void> trocarIdoso(@CookieValue(value = "oldfly_admin_session", required = false) String sessao,
                                           @RequestBody VinculoDTO dados) {
        sessoes.validar(sessao);
        if (!dados.cargasConferidas()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                "Confira os remédios carregados nos containers antes de trocar o vínculo.");
        service.trocarIdoso(dados.idosoId());
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/status")
    @CrossOrigin("*")
    public Map<String, Object> status() { return service.status(); }

    @PostMapping(value = "/proximo", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> proximo(@RequestHeader(value = "Authorization", required = false) String token,
                                         @RequestParam(defaultValue = "true") boolean simulacao) {
        ComandoDispenser comando = service.proximo(token, simulacao);
        return comando == null ? ResponseEntity.noContent().build() : ResponseEntity.ok(serializar(comando));
    }

    @PostMapping(value = "/comandos/{id}/iniciar", produces = MediaType.TEXT_PLAIN_VALUE)
    public String iniciar(@RequestHeader(value = "Authorization", required = false) String token, @PathVariable String id) {
        return serializar(service.iniciar(token, id));
    }

    @PostMapping("/comandos/{id}/resultado")
    public ResponseEntity<Void> resultado(@RequestHeader(value = "Authorization", required = false) String token,
                                         @PathVariable String id, @RequestParam String estado) {
        service.resultado(token, id, estado);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/comandos/{id}/conferido")
    public ResponseEntity<Void> conferir(@RequestHeader(value = "Authorization", required = false) String token,
                                        @PathVariable String id) {
        service.conferir(token, id);
        return ResponseEntity.noContent().build();
    }

    private String serializar(ComandoDispenser c) {
        return c.getId() + ";" + c.getMotor() + ";" + c.getPassos() + ";"
                + (c.isSimulacao() ? "1" : "0") + ";" + c.getEstado().name();
    }
}
