#pragma once

// Copie para config.local.h e preencha localmente. Não compartilhe senhas/tokens.
const char* WIFI_SSID = "PREENCHA_SUA_REDE";
const char* WIFI_SENHA = "PREENCHA_SUA_SENHA";
// IP do computador na mesma rede do ESP8266. Nunca use localhost aqui.
const char* BACKEND_URL = "http://192.168.1.100:8080";
// Mesmo valor de DISPENSER_TOKEN no backend, com pelo menos 32 caracteres aleatórios.
const char* DISPENSER_TOKEN = "";

// Primeiro valide a comunicação sem movimentar os motores.
// Para mover: false aqui E DISPENSER_PERMITIR_MOTORES=true no backend.
const bool MODO_SIMULACAO = true;
