# Old Fly - Dispenser Inteligente

Projeto integrado com frontend HTML/CSS/JS, backend Spring Boot e banco MySQL.

## O que esta versão possui

- Login conectado ao backend.
- Cadastro inicial com botão de olho para visualizar senha.
- CRUD completo de usuários no backend.
- Tela de usuários para admin com cadastrar, editar, excluir e filtrar por perfil.
- Senhas ocultas na listagem de usuários.
- Entidade `Medicamento` com CRUD completo.
- Dashboard carregando remédios reais do banco.
- Entidade `Receita` com cadastro, listagem e exclusão.
- Entidade `Estoque` integrada ao medicamento.
- Página de estoque atualizando quantidade e horários no banco.
- Mensagens visuais no lugar de `alert()` e confirmação personalizada no lugar de ações diretas.
- Melhorias de acessibilidade visual: botões maiores, contraste e responsividade.

## Como rodar

### 1. Banco

Abra o MySQL Workbench e execute:

```sql
CREATE DATABASE IF NOT EXISTS sistema_usuarios;
USE sistema_usuarios;
```

O Spring Boot cria as tabelas automaticamente por causa de:

```properties
spring.jpa.hibernate.ddl-auto=update
```

### 2. Backend

Abra a pasta:

```text
backend/AcessoBackEnd
```

Rode a classe:

```text
AcessoBackEndApplication
```

O backend deve subir em:

```text
http://localhost:8080
```

Se sua senha do MySQL for diferente, altere em:

```text
backend/AcessoBackEnd/src/main/resources/application.properties
```

### 3. Frontend

Abra o projeto no VS Code e rode o Live Server no arquivo:

```text
index.html
```

Ou diretamente em:

```text
frontend/old-fly-com-acessos/index.html
```

## Acessos iniciais

```text
Admin: admin.oldfly / admin123
Cuidador: cuidador.ana / cuidado123
Idoso: idoso.joao / joao123
```

## Principais rotas do backend

### Login e usuários

```text
POST   /auth/login
GET    /auth/usuarios
POST   /admin
GET    /admin
GET    /admin/{id}
PUT    /admin/{id}
DELETE /admin/{id}
POST   /cuidador
GET    /cuidador
GET    /cuidador/{id}
PUT    /cuidador/{id}
DELETE /cuidador/{id}
POST   /idoso
GET    /idoso
GET    /idoso/{id}
PUT    /idoso/{id}
DELETE /idoso/{id}
```

### Medicamentos e estoque

```text
POST   /medicamentos
GET    /medicamentos
GET    /medicamentos/{id}
PUT    /medicamentos/{id}
DELETE /medicamentos/{id}
GET    /estoque/medicamento/{medicamentoId}
PUT    /estoque/medicamento/{medicamentoId}
```

### Receitas

```text
POST   /receitas
GET    /receitas
GET    /receitas/{id}
PUT    /receitas/{id}
DELETE /receitas/{id}
```
