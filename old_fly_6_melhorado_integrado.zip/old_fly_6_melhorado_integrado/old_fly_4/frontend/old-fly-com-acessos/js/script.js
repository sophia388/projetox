document.addEventListener('DOMContentLoaded', () => {
    const loginScreen = document.getElementById('login-screen');
    const authWrapper = document.querySelector('.auth-wrapper');
    const appAreas = document.querySelectorAll('.app-area');
    const loginForm = document.getElementById('login-form');
    const loginUser = document.getElementById('login-user');
    const loginPass = document.getElementById('login-pass');
    const loginError = document.getElementById('login-error');
    const loginCard = document.querySelector('.login-card:not(.register-card)');
    const registerCard = document.querySelector('.register-card');
    const btnShowRegister = document.getElementById('btn-show-register');
    const btnShowLogin = document.getElementById('btn-show-login');

    const registerForm = document.getElementById('register-form');
    const registerPerfil = document.getElementById('register-perfil');
    const registerNome = document.getElementById('register-nome');
    const registerIdade = document.getElementById('register-idade');
    const registerEmail = document.getElementById('register-email');
    const registerUsuario = document.getElementById('register-usuario');
    const registerSenha = document.getElementById('register-senha');
    const registerCampoIdoso = document.getElementById('register-campo-idoso');
    const registerIdosoId = document.getElementById('register-idoso-id');
    const registerMessage = document.getElementById('register-message');

    const profileName = document.getElementById('profile-name');
    const profileRole = document.getElementById('profile-role');
    const btnLogout = document.getElementById('btn-logout');

    const navDashboard = document.getElementById('nav-dashboard');
    const navReceitas = document.getElementById('nav-receitas');
    const navUsuarios = document.getElementById('nav-usuarios');
    const navSobre = document.getElementById('nav-sobre');

    const viewDashboard = document.getElementById('view-dashboard');
    const viewReceitasVazia = document.getElementById('view-receitas-vazia');
    const viewReceitasForm = document.getElementById('view-receitas-form');
    const viewUsuarios = document.getElementById('view-usuarios');
    const viewSobre = document.getElementById('view-sobre');

    const dispenserGrid = document.getElementById('dispenser-grid');
    const remediosList = document.getElementById('remedios-list');
    const btnNovoMedicamento = document.getElementById('btn-novo-medicamento');
    const medicamentoFormCard = document.getElementById('medicamento-form-card');
    const medicamentoForm = document.getElementById('form-medicamento');
    const medicamentoFormTitle = document.getElementById('medicamento-form-title');
    const medicamentoFormMsg = document.getElementById('medicamento-form-msg');
    const btnCancelarMedicamento = document.getElementById('btn-cancelar-medicamento');
    const medicamentoCor = document.getElementById('medicamento-cor');
    const medicamentoCorAjuda = document.getElementById('medicamento-cor-ajuda');
    const medicamentoEstoque = document.getElementById('medicamento-estoque');
    const medicamentoMinimo = document.getElementById('medicamento-minimo');
    const medicamentoCategoria = document.getElementById('medicamento-categoria');
    const medicamentoTipo = document.getElementById('medicamento-tipo');
    const medicamentoAntibiotico = document.getElementById('medicamento-antibiotico');
    const medicamentoAntibioticoCampos = document.getElementById('medicamento-antibiotico-campos');
    const medicamentoDataInicio = document.getElementById('medicamento-data-inicio');
    const medicamentoDuracao = document.getElementById('medicamento-duracao');
    const medicamentoExclusaoPreview = document.getElementById('medicamento-exclusao-preview');

    const btnNovaReceita = document.getElementById('btn-nova-receita');
    const btnAddPrimeira = document.getElementById('btn-add-primeira');
    const btnCancelar = document.getElementById('btn-cancelar');
    const receitasList = document.getElementById('receitas-list');
    const receitasEmpty = document.getElementById('receitas-empty');
    const receitaForm = document.getElementById('form-receita');
    const receitaFormMsg = document.getElementById('receita-form-msg');

    const adminUsersList = document.getElementById('admin-users-list');
    const adminUserForm = document.getElementById('admin-user-form');
    const adminFormTitle = document.getElementById('admin-form-title');
    const adminFormMsg = document.getElementById('admin-form-msg');
    const adminUserPerfil = document.getElementById('admin-user-perfil');
    const adminCampoIdoso = document.getElementById('admin-campo-idoso');
    const adminUserIdosoId = document.getElementById('admin-user-idoso-id');
    const filtroUsuarios = document.getElementById('filtro-usuarios');
    const btnAdminLimpar = document.getElementById('btn-admin-limpar');

    let usuariosCache = [];
    let medicamentosCache = [];
    let receitasCache = [];

    function escapeHTML(valor) {
        return String(valor ?? '')
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function mostrarToast(mensagem, tipo = 'ok') {
        const toast = document.getElementById('toast');
        if (!toast) return;
        toast.innerText = mensagem;
        toast.className = `toast show ${tipo}`;
        setTimeout(() => toast.className = 'toast', 3000);
    }

    function confirmarAcao(mensagem, callback) {
        const modal = document.getElementById('confirm-modal');
        const texto = document.getElementById('confirm-message');
        const cancelar = document.getElementById('confirm-cancel');
        const confirmar = document.getElementById('confirm-ok');
        if (!modal || !texto || !cancelar || !confirmar) return;

        texto.innerText = mensagem;
        modal.style.display = 'flex';

        const fechar = () => {
            modal.style.display = 'none';
            cancelar.onclick = null;
            confirmar.onclick = null;
        };

        cancelar.onclick = fechar;
        confirmar.onclick = async () => {
            fechar();
            await callback();
        };
    }

    function hideAllViews() {
        [viewDashboard, viewReceitasVazia, viewReceitasForm, viewUsuarios, viewSobre].forEach(view => {
            if (view) view.style.display = 'none';
        });
    }

    function removeActiveNav() {
        [navDashboard, navReceitas, navUsuarios, navSobre].forEach(nav => {
            if (nav) nav.classList.remove('active');
        });
    }

    function showLoginCard() {
        authWrapper.classList.remove('register-mode');
        loginCard.style.display = 'block';
        registerCard.style.display = 'none';
    }

    async function showRegisterCard() {
        authWrapper.classList.add('register-mode');
        loginCard.style.display = 'none';
        registerCard.style.display = 'block';
        await carregarUsuariosCache();
        preencherSelectIdosos(registerIdosoId);
    }

    function showLogin() {
        loginScreen.style.display = 'flex';
        appAreas.forEach(area => area.style.display = 'none');
        showLoginCard();
    }

    async function showApp() {
        loginScreen.style.display = 'none';
        appAreas.forEach(area => area.style.display = '');
        await carregarUsuariosCache();
        updateProfile();
        configurarPermissoes();
        await renderDashboard();
        showDashboard();
    }

    function configurarPermissoes() {
        const loggedUser = getLoggedUser();
        const podeGerenciar = loggedUser && loggedUser.perfil !== 'idoso';
        document.querySelectorAll('.can-manage').forEach(item => {
            item.style.display = podeGerenciar ? '' : 'none';
        });
    }

    function updateProfile() {
        const loggedUser = getLoggedUser();
        const viewingUser = getViewingUser();
        if (!loggedUser || !viewingUser) return;

        const viewingText = loggedUser.perfil === 'admin' && loggedUser.usuario !== viewingUser.usuario
            ? ` vendo: ${viewingUser.nome}`
            : '';

        profileName.innerText = `${loggedUser.nome}${viewingText}`;
        profileRole.innerText = roleLabel(loggedUser.perfil);
        navUsuarios.style.display = loggedUser.perfil === 'admin' ? 'flex' : 'none';
    }

    function showDashboard() {
        removeActiveNav();
        hideAllViews();
        navDashboard.classList.add('active');
        viewDashboard.style.display = 'block';
    }

    function showSobre() {
        removeActiveNav();
        hideAllViews();
        navSobre.classList.add('active');
        viewSobre.style.display = 'block';
    }

    async function carregarUsuariosCache() {
        try {
            usuariosCache = await buscarUsuariosBackend();
        } catch (erro) {
            usuariosCache = fallbackUsers;
        }
        return usuariosCache;
    }

    function preencherSelectIdosos(selectElement, selecionado = 0) {
        if (!selectElement) return;
        const idosos = usuariosCache.filter(user => user.perfil === 'idoso');
        selectElement.innerHTML = '<option value="0">Sem idoso vinculado</option>' + idosos.map(idoso => `
            <option value="${idoso.id}" ${Number(selecionado) === Number(idoso.id) ? 'selected' : ''}>${escapeHTML(idoso.nome)}</option>
        `).join('');
    }

    function atualizarCampoIdosoResponsavel() {
        if (registerCampoIdoso) {
            registerCampoIdoso.style.display = registerPerfil.value === 'cuidador' ? 'block' : 'none';
        }
        if (adminCampoIdoso) {
            adminCampoIdoso.style.display = adminUserPerfil.value === 'cuidador' ? 'block' : 'none';
        }
    }

    function getPrimeiroIdosoId() {
        const viewingUser = getViewingUser();
        if (viewingUser && viewingUser.perfil === 'idoso') return viewingUser.id;
        if (viewingUser && viewingUser.perfil === 'cuidador' && viewingUser.idosoId) return viewingUser.idosoId;
        const idoso = usuariosCache.find(user => user.perfil === 'idoso');
        return idoso ? idoso.id : 0;
    }

    function medicamentoEhAntibiotico(medicamento) {
        return typeof medicamento?.antibiotico === 'boolean'
            ? medicamento.antibiotico
            : ehAntibiotico(medicamento?.categoria);
    }

    function formatarData(dataISO) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(String(dataISO ?? ''))) return 'data não informada';
        const [ano, mes, dia] = dataISO.split('-');
        return `${dia}/${mes}/${ano}`;
    }

    function dataLocalISO(data = new Date()) {
        const ano = data.getFullYear();
        const mes = String(data.getMonth() + 1).padStart(2, '0');
        const dia = String(data.getDate()).padStart(2, '0');
        return `${ano}-${mes}-${dia}`;
    }

    function calcularDataExclusaoPreview(dataInicio, duracaoDias) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(String(dataInicio ?? ''))) return '';
        const [ano, mes, dia] = dataInicio.split('-').map(Number);
        const dataExclusao = new Date(ano, mes - 1, dia);
        dataExclusao.setDate(dataExclusao.getDate() + Number(duracaoDias || 5));
        return dataLocalISO(dataExclusao);
    }

    function statusEstoque(medicamento) {
        return classificarEstoque(
            medicamento.quantidadeAtual,
            medicamento.quantidadeMinima,
            medicamentoEhAntibiotico(medicamento)
        );
    }

    function atualizarCorFormularioMedicamento() {
        const status = classificarEstoque(
            medicamentoEstoque.value,
            medicamentoMinimo.value,
            medicamentoAntibiotico.checked
        );
        medicamentoCor.value = status.cor;
        medicamentoCorAjuda.innerText = `${status.rotulo}: cor definida automaticamente pela quantidade em estoque.`;
    }

    function atualizarConfiguracaoAntibiotico() {
        const antibiotico = medicamentoAntibiotico.checked;
        medicamentoAntibioticoCampos.style.display = antibiotico ? 'flex' : 'none';
        medicamentoDataInicio.disabled = !antibiotico;
        medicamentoDuracao.disabled = !antibiotico;
        medicamentoDataInicio.required = antibiotico;
        medicamentoDuracao.required = antibiotico;

        if (antibiotico) {
            if (!medicamentoDataInicio.value) medicamentoDataInicio.value = dataLocalISO();
            medicamentoTipo.value = 'Programado';
            medicamentoTipo.disabled = true;
            const dataExclusao = calcularDataExclusaoPreview(
                medicamentoDataInicio.value,
                medicamentoDuracao.value
            );
            medicamentoExclusaoPreview.innerText = `Exclusão automática prevista para ${formatarData(dataExclusao)}.`;
            medicamentoExclusaoPreview.style.display = 'block';
        } else {
            medicamentoTipo.disabled = false;
            medicamentoExclusaoPreview.style.display = 'none';
        }

        atualizarCorFormularioMedicamento();
    }

    function tagTipo(tipoUso) {
        if (tipoUso === 'Contínuo') return 'tag-green';
        if (tipoUso === 'Programado') return 'tag-yellow';
        return 'tag-gray';
    }

    async function renderDashboard() {
        try {
            medicamentosCache = await buscarMedicamentosBackend();
        } catch (erro) {
            medicamentosCache = [];
            mostrarToast('Não foi possível carregar os remédios. Verifique se o backend está ligado.', 'erro');
        }

        if (!medicamentosCache.length) {
            dispenserGrid.innerHTML = '<div class="empty-state-card full-width"><p>Nenhum remédio cadastrado no banco.</p></div>';
            remediosList.innerHTML = '';
            return;
        }

        dispenserGrid.innerHTML = medicamentosCache.map(med => {
            const status = statusEstoque(med);
            const cor = status.cor;
            const antibiotico = medicamentoEhAntibiotico(med);
            return `
                <div class="dispenser-card card-${cor}" data-id="${med.id}" aria-label="${escapeHTML(med.nome)}: estoque ${status.rotulo.toLowerCase()}">
                    <span class="badge badge-${cor}">#${med.containerNumero}</span>
                    <div class="inner-shape"><div class="dot"></div></div>
                    <h3>${escapeHTML(med.nome)}</h3>
                    <p>${escapeHTML(med.dosagem)}</p>
                    ${antibiotico ? `<p class="treatment-line">Exclusão: ${formatarData(med.dataExclusao)}</p>` : ''}
                </div>
            `;
        }).join('');

        remediosList.innerHTML = medicamentosCache.map(med => {
            const status = statusEstoque(med);
            const cor = status.cor;
            const antibiotico = medicamentoEhAntibiotico(med);
            return `
                <div class="remedio-item" data-id="${med.id}">
                    <div class="status-dot dot-${cor}"></div>
                    <div class="remedio-info">
                        <div class="remedio-header">
                            <h4>${escapeHTML(med.nome)}</h4>
                            <span class="tag ${tagTipo(med.tipoUso)}">${escapeHTML(med.tipoUso)}</span>
                            ${antibiotico ? `<span class="tag tag-blue">Antibiótico · ${med.duracaoTratamentoDias || 5} dias</span>` : ''}
                            <span class="tag tag-${cor}">${status.rotulo}</span>
                        </div>
                        <p>${escapeHTML(med.categoria)} • ${escapeHTML(med.dosagem)} • Container #${med.containerNumero}</p>
                        <p class="time"><i class="fa-regular fa-clock"></i> ${escapeHTML(med.horario)}</p>
                        <p class="stock-line">Estoque: ${med.quantidadeAtual} un. • Mínimo: ${med.quantidadeMinima} un. • Idoso: ${escapeHTML(med.nomeIdoso)}</p>
                        ${antibiotico ? `<p class="treatment-line"><i class="fa-regular fa-calendar-xmark"></i> Exclusão automática: ${formatarData(med.dataExclusao)}</p>` : ''}
                    </div>
                    <div class="actions can-manage">
                        <button type="button" class="icon-btn btn-editar-medicamento" title="Editar"><i class="fa-solid fa-pen"></i></button>
                        <button type="button" class="icon-btn text-red btn-excluir-medicamento" title="Excluir"><i class="fa-solid fa-trash"></i></button>
                    </div>
                </div>
            `;
        }).join('');

        configurarPermissoes();
        configurarAcoesMedicamentos();
    }

    function abrirFormMedicamento(med = null) {
        medicamentoFormCard.style.display = 'block';
        medicamentoFormTitle.innerText = med ? 'Editar remédio' : 'Cadastrar remédio';
        medicamentoFormMsg.innerText = '';
        preencherSelectIdosos(document.getElementById('medicamento-idoso-id'), med ? med.idosoId : getPrimeiroIdosoId());

        document.getElementById('medicamento-id').value = med ? med.id : '';
        document.getElementById('medicamento-nome').value = med ? med.nome : '';
        document.getElementById('medicamento-dosagem').value = med ? med.dosagem : '';
        medicamentoCategoria.value = med ? med.categoria : '';
        document.getElementById('medicamento-horario').value = med ? med.horario : '';
        medicamentoTipo.value = med
            ? (med.tipoUso === 'Programado' ? 'Programado' : 'Contínuo')
            : 'Contínuo';
        document.getElementById('medicamento-container').value = med ? med.containerNumero : 1;
        medicamentoEstoque.value = med ? med.quantidadeAtual : 0;
        medicamentoMinimo.value = med ? med.quantidadeMinima : 5;
        medicamentoAntibiotico.checked = med ? medicamentoEhAntibiotico(med) : false;
        medicamentoDataInicio.value = med?.dataInicioTratamento || '';
        medicamentoDuracao.value = String(med?.duracaoTratamentoDias || 5);
        atualizarConfiguracaoAntibiotico();
        medicamentoFormCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function fecharFormMedicamento() {
        medicamentoForm.reset();
        document.getElementById('medicamento-id').value = '';
        atualizarConfiguracaoAntibiotico();
        medicamentoFormCard.style.display = 'none';
    }

    function configurarAcoesMedicamentos() {
        document.querySelectorAll('.remedio-item, .dispenser-card').forEach(item => {
            item.style.cursor = 'pointer';
            item.addEventListener('click', (e) => {
                if (e.target.closest('.actions') || e.target.closest('button')) return;
                window.location.href = `paginas/estoque.html?medicamentoId=${item.dataset.id}`;
            });
        });

        document.querySelectorAll('.btn-editar-medicamento').forEach(botao => {
            botao.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = Number(botao.closest('.remedio-item').dataset.id);
                const med = medicamentosCache.find(item => Number(item.id) === id);
                abrirFormMedicamento(med);
            });
        });

        document.querySelectorAll('.btn-excluir-medicamento').forEach(botao => {
            botao.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = Number(botao.closest('.remedio-item').dataset.id);
                confirmarAcao('Deseja excluir este remédio do banco de dados?', async () => {
                    try {
                        await excluirMedicamentoBackend(id);
                        mostrarToast('Remédio excluído com sucesso.');
                        await renderDashboard();
                    } catch (erro) {
                        mostrarToast('Erro ao excluir remédio.', 'erro');
                    }
                });
            });
        });
    }

    async function renderReceitas() {
        try {
            receitasCache = await buscarReceitasBackend();
        } catch (erro) {
            receitasCache = [];
            mostrarToast('Não foi possível carregar as receitas.', 'erro');
        }

        if (!receitasCache.length) {
            receitasList.innerHTML = '';
            receitasEmpty.style.display = 'block';
            return;
        }

        receitasEmpty.style.display = 'none';
        receitasList.innerHTML = receitasCache.map(receita => `
            <div class="receita-card">
                <div class="receita-icon"><i class="fa-solid fa-file-medical"></i></div>
                <div class="receita-info">
                    <h3>${escapeHTML(receita.medico)}</h3>
                    <p><strong>Data:</strong> ${escapeHTML(receita.dataReceita || 'Sem data')}</p>
                    <p><strong>Medicamentos:</strong> ${escapeHTML(receita.medicamentos)}</p>
                    <p><strong>Observações:</strong> ${escapeHTML(receita.observacoes || 'Nenhuma')}</p>
                    <p><strong>Arquivo:</strong> ${escapeHTML(receita.arquivoNome || 'Sem anexo')} • <strong>Idoso:</strong> ${escapeHTML(receita.nomeIdoso)}</p>
                </div>
                <button type="button" class="icon-btn text-red btn-excluir-receita" data-id="${receita.id}" title="Excluir receita"><i class="fa-solid fa-trash"></i></button>
            </div>
        `).join('');

        document.querySelectorAll('.btn-excluir-receita').forEach(botao => {
            botao.addEventListener('click', () => {
                confirmarAcao('Deseja excluir esta receita?', async () => {
                    try {
                        await excluirReceitaBackend(botao.dataset.id);
                        mostrarToast('Receita excluída com sucesso.');
                        await renderReceitas();
                    } catch (erro) {
                        mostrarToast('Erro ao excluir receita.', 'erro');
                    }
                });
            });
        });
    }

    async function renderAdminArea() {
        const loggedUser = getLoggedUser();
        if (!loggedUser || loggedUser.perfil !== 'admin' || !adminUsersList) return;

        await carregarUsuariosCache();
        preencherSelectIdosos(adminUserIdosoId);
        preencherSelectIdosos(document.getElementById('medicamento-idoso-id'));

        const filtro = filtroUsuarios.value || 'todos';
        const usuarios = filtro === 'todos'
            ? usuariosCache
            : usuariosCache.filter(user => user.perfil === filtro);

        if (!usuarios.length) {
            adminUsersList.innerHTML = '<p>Nenhum usuário encontrado para esse filtro.</p>';
            return;
        }

        adminUsersList.innerHTML = usuarios.map(user => `
            <div class="user-card" data-id="${user.id}" data-perfil="${user.perfil}">
                <div class="user-icon"><i class="fa-solid ${user.perfil === 'admin' ? 'fa-user-shield' : user.perfil === 'cuidador' ? 'fa-hand-holding-heart' : 'fa-person-cane'}"></i></div>
                <h3>${escapeHTML(user.nome)}</h3>
                <span class="tag tag-blue-custom">${roleLabel(user.perfil)}</span>
                <p>${escapeHTML(user.descricao)}</p>
                <div class="access-data">
                    <strong>ID:</strong> ${user.id}<br>
                    <strong>Usuário:</strong> ${escapeHTML(user.usuario)}<br>
                    <strong>E-mail:</strong> ${escapeHTML(user.email)}<br>
                    ${user.perfil === 'cuidador' ? `<strong>Idoso vinculado:</strong> ${escapeHTML(user.nomeIdoso || 'Sem vínculo')}<br>` : ''}
                    <strong>Senha:</strong> ********<br>
                    <strong>Acesso:</strong> ${escapeHTML(user.acesso)}
                </div>
                <div class="card-actions">
                    <button type="button" class="btn btn-outline-small btn-editar-usuario">Editar</button>
                    <button type="button" class="btn btn-outline-small danger btn-excluir-usuario">Excluir</button>
                </div>
            </div>
        `).join('');

        document.querySelectorAll('.btn-editar-usuario').forEach(botao => {
            botao.addEventListener('click', () => {
                const card = botao.closest('.user-card');
                const user = usuariosCache.find(item => Number(item.id) === Number(card.dataset.id) && item.perfil === card.dataset.perfil);
                preencherFormularioAdmin(user);
            });
        });

        document.querySelectorAll('.btn-excluir-usuario').forEach(botao => {
            botao.addEventListener('click', () => {
                const card = botao.closest('.user-card');
                const id = Number(card.dataset.id);
                const perfil = card.dataset.perfil;
                confirmarAcao('Deseja excluir este usuário do banco?', async () => {
                    try {
                        await excluirUsuarioBackend(id, perfil);
                        mostrarToast('Usuário excluído com sucesso.');
                        limparFormularioAdmin();
                        await renderAdminArea();
                    } catch (erro) {
                        mostrarToast('Erro ao excluir usuário. Confira vínculos no banco.', 'erro');
                    }
                });
            });
        });
    }

    function preencherFormularioAdmin(user) {
        if (!user) return;
        adminFormTitle.innerText = 'Editar usuário';
        document.getElementById('admin-user-id').value = user.id;
        adminUserPerfil.value = user.perfil;
        document.getElementById('admin-user-nome').value = user.nome;
        document.getElementById('admin-user-idade').value = user.idade || 1;
        document.getElementById('admin-user-email').value = user.email;
        document.getElementById('admin-user-usuario').value = user.usuario;
        document.getElementById('admin-user-senha').value = '';
        atualizarCampoIdosoResponsavel();
        preencherSelectIdosos(adminUserIdosoId, user.idosoId || 0);
        adminFormMsg.innerText = 'Editando usuário. Preencha a senha somente se quiser trocar.';
        adminUserForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function limparFormularioAdmin() {
        adminUserForm.reset();
        document.getElementById('admin-user-id').value = '';
        adminFormTitle.innerText = 'Cadastrar usuário';
        adminFormMsg.innerText = '';
        atualizarCampoIdosoResponsavel();
        preencherSelectIdosos(adminUserIdosoId);
    }

    function configurarOlhoSenha() {
        document.querySelectorAll('.password-toggle').forEach(button => {
            button.addEventListener('click', () => {
                const input = document.getElementById(button.dataset.target);
                const icon = button.querySelector('i');
                if (!input || !icon) return;

                const mostrar = input.type === 'password';
                input.type = mostrar ? 'text' : 'password';
                icon.classList.toggle('fa-eye', !mostrar);
                icon.classList.toggle('fa-eye-slash', mostrar);
            });
        });
    }

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        loginError.innerText = 'Entrando...';

        try {
            const user = await loginBackend(loginUser.value.trim(), loginPass.value.trim());
            if (!user) {
                loginError.innerText = 'Usuário ou senha incorretos.';
                return;
            }

            setLoggedUser(user);
            setViewingUser(user);
            loginError.innerText = '';
            loginForm.reset();
            await showApp();
        } catch (erro) {
            loginError.innerText = 'Erro ao conectar com o backend. Inicie o Spring Boot na porta 8080.';
        }
    });

    registerPerfil.addEventListener('change', atualizarCampoIdosoResponsavel);
    btnShowRegister.addEventListener('click', showRegisterCard);
    btnShowLogin.addEventListener('click', showLoginCard);

    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        registerMessage.style.color = 'var(--green-text)';
        registerMessage.innerText = 'Cadastrando...';

        const usuarioCriado = registerUsuario.value.trim();
        const senhaCriada = registerSenha.value.trim();

        try {
            await cadastrarUsuarioBackend({
                perfil: registerPerfil.value,
                nome: registerNome.value.trim(),
                idade: registerIdade.value,
                email: registerEmail.value.trim(),
                usuario: usuarioCriado,
                senha: senhaCriada,
                adminId: 0,
                idosoId: registerIdosoId ? registerIdosoId.value : 0
            });

            registerMessage.innerText = 'Cadastro realizado. Agora faça login.';
            registerForm.reset();
            loginUser.value = usuarioCriado;
            loginPass.value = senhaCriada;
            atualizarCampoIdosoResponsavel();
            await carregarUsuariosCache();
            showLoginCard();
        } catch (erro) {
            registerMessage.style.color = 'var(--red-text)';
            registerMessage.innerText = 'Erro ao cadastrar. Confira os dados e se o backend está ligado.';
        }
    });

    btnLogout.addEventListener('click', (e) => {
        e.preventDefault();
        clearLoggedUser();
        showLogin();
    });

    navDashboard.addEventListener('click', async (e) => {
        e.preventDefault();
        await renderDashboard();
        showDashboard();
    });

    navReceitas.addEventListener('click', async (e) => {
        e.preventDefault();
        removeActiveNav();
        hideAllViews();
        navReceitas.classList.add('active');
        await renderReceitas();
        viewReceitasVazia.style.display = 'block';
    });

    navUsuarios.addEventListener('click', async (e) => {
        e.preventDefault();
        const loggedUser = getLoggedUser();
        if (!loggedUser || loggedUser.perfil !== 'admin') return;
        removeActiveNav();
        hideAllViews();
        navUsuarios.classList.add('active');
        await renderAdminArea();
        viewUsuarios.style.display = 'block';
    });

    navSobre.addEventListener('click', (e) => {
        e.preventDefault();
        showSobre();
    });

    const showFormReceita = (e) => {
        e.preventDefault();
        hideAllViews();
        receitaFormMsg.innerText = '';
        viewReceitasForm.style.display = 'block';
    };

    btnNovaReceita.addEventListener('click', showFormReceita);
    btnAddPrimeira.addEventListener('click', showFormReceita);

    btnCancelar.addEventListener('click', async (e) => {
        e.preventDefault();
        receitaForm.reset();
        document.getElementById('file-preview').style.display = 'none';
        hideAllViews();
        await renderReceitas();
        viewReceitasVazia.style.display = 'block';
    });

    receitaForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        receitaFormMsg.innerText = 'Salvando...';
        const fileName = document.getElementById('file-name').innerText;
        try {
            await salvarReceitaBackend({
                medico: document.getElementById('receita-medico').value.trim(),
                dataReceita: document.getElementById('receita-data').value,
                medicamentos: document.getElementById('receita-medicamentos').value.trim(),
                observacoes: document.getElementById('receita-observacoes').value.trim(),
                arquivoNome: fileName,
                idosoId: getPrimeiroIdosoId()
            });
            mostrarToast('Receita salva no banco com sucesso.');
            receitaForm.reset();
            document.getElementById('file-preview').style.display = 'none';
            hideAllViews();
            await renderReceitas();
            viewReceitasVazia.style.display = 'block';
        } catch (erro) {
            receitaFormMsg.innerText = 'Erro ao salvar receita no backend.';
        }
    });

    const btnFoto = document.getElementById('btn-foto');
    const btnAnexo = document.getElementById('btn-anexo');
    const inputCamera = document.getElementById('input-camera');
    const inputGallery = document.getElementById('input-gallery');
    const filePreview = document.getElementById('file-preview');
    const fileNameSpan = document.getElementById('file-name');

    const handleFileSelect = (input) => {
        if (input.files && input.files[0]) {
            fileNameSpan.innerText = input.files[0].name;
            filePreview.style.display = 'block';
        }
    };

    btnAnexo.addEventListener('click', () => inputGallery.click());
    btnFoto.addEventListener('click', () => inputCamera.click());
    inputCamera.addEventListener('change', () => handleFileSelect(inputCamera));
    inputGallery.addEventListener('change', () => handleFileSelect(inputGallery));

    btnNovoMedicamento.addEventListener('click', () => abrirFormMedicamento());
    btnCancelarMedicamento.addEventListener('click', fecharFormMedicamento);
    medicamentoEstoque.addEventListener('input', atualizarCorFormularioMedicamento);
    medicamentoMinimo.addEventListener('input', atualizarCorFormularioMedicamento);
    medicamentoAntibiotico.addEventListener('change', atualizarConfiguracaoAntibiotico);
    medicamentoDataInicio.addEventListener('change', atualizarConfiguracaoAntibiotico);
    medicamentoDuracao.addEventListener('change', atualizarConfiguracaoAntibiotico);
    medicamentoCategoria.addEventListener('change', () => {
        if (ehAntibiotico(medicamentoCategoria.value)) {
            medicamentoAntibiotico.checked = true;
            atualizarConfiguracaoAntibiotico();
        }
    });

    medicamentoForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        medicamentoFormMsg.innerText = 'Salvando...';
        const id = document.getElementById('medicamento-id').value;
        try {
            await salvarMedicamentoBackend({
                nome: document.getElementById('medicamento-nome').value.trim(),
                dosagem: document.getElementById('medicamento-dosagem').value.trim(),
                categoria: document.getElementById('medicamento-categoria').value.trim(),
                horario: document.getElementById('medicamento-horario').value.trim(),
                tipoUso: medicamentoTipo.value,
                containerNumero: document.getElementById('medicamento-container').value,
                idosoId: document.getElementById('medicamento-idoso-id').value,
                quantidadeAtual: document.getElementById('medicamento-estoque').value,
                quantidadeMinima: document.getElementById('medicamento-minimo').value,
                antibiotico: medicamentoAntibiotico.checked,
                dataInicioTratamento: medicamentoDataInicio.value || null,
                duracaoTratamentoDias: medicamentoDuracao.value
            }, id || null);
            mostrarToast(id ? 'Remédio atualizado com sucesso.' : 'Remédio cadastrado com sucesso.');
            fecharFormMedicamento();
            await renderDashboard();
        } catch (erro) {
            medicamentoFormMsg.innerText = 'Erro ao salvar remédio. Verifique o backend.';
        }
    });

    adminUserPerfil.addEventListener('change', atualizarCampoIdosoResponsavel);
    filtroUsuarios.addEventListener('change', renderAdminArea);
    btnAdminLimpar.addEventListener('click', limparFormularioAdmin);

    adminUserForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        adminFormMsg.innerText = 'Salvando...';
        const id = document.getElementById('admin-user-id').value;
        const perfil = adminUserPerfil.value;
        const dados = {
            perfil,
            nome: document.getElementById('admin-user-nome').value.trim(),
            idade: document.getElementById('admin-user-idade').value,
            email: document.getElementById('admin-user-email').value.trim(),
            usuario: document.getElementById('admin-user-usuario').value.trim(),
            senha: document.getElementById('admin-user-senha').value.trim(),
            adminId: 0,
            idosoId: adminUserIdosoId ? adminUserIdosoId.value : 0
        };

        if (!id && !dados.senha) {
            adminFormMsg.innerText = 'Informe uma senha para criar o usuário.';
            return;
        }

        try {
            if (id) {
                await atualizarUsuarioBackend(id, perfil, dados);
                mostrarToast('Usuário atualizado com sucesso.');
            } else {
                await cadastrarUsuarioBackend(dados);
                mostrarToast('Usuário cadastrado com sucesso.');
            }
            limparFormularioAdmin();
            await renderAdminArea();
        } catch (erro) {
            adminFormMsg.innerText = 'Erro ao salvar usuário. Confira duplicidade de usuário/e-mail.';
        }
    });

    configurarOlhoSenha();
    atualizarCampoIdosoResponsavel();
    atualizarConfiguracaoAntibiotico();

    const params = new URLSearchParams(window.location.search);
    if ((params.get('dashboard') === '1' || params.get('sobre') === '1') && getLoggedUser()) {
        showApp().then(() => {
            if (params.get('sobre') === '1') showSobre();
        });
    } else {
        clearLoggedUser();
        showLogin();
    }
});
