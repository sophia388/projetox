function mostrarToast(mensagem, tipo = 'ok') {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.innerText = mensagem;
    toast.className = `toast show ${tipo}`;
    setTimeout(() => toast.className = 'toast', 3000);
}

function voltarDashboard() {
    window.location.href = '../index.html?dashboard=1';
}

function escapeHTML(valor) {
    return String(valor ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

document.addEventListener('DOMContentLoaded', async () => {
    const usuarioLogado = getLoggedUser();
    if (!usuarioLogado) {
        window.location.href = '../index.html';
        return;
    }

    const linkDashboard = document.getElementById('link-dashboard');
    const btnVoltarDashboard = document.getElementById('btn-voltar-dashboard');
    const btnSair = document.getElementById('btn-sair-estoque');

    linkDashboard.addEventListener('click', (e) => {
        e.preventDefault();
        voltarDashboard();
    });

    btnVoltarDashboard.addEventListener('click', voltarDashboard);

    btnSair.addEventListener('click', (e) => {
        e.preventDefault();
        clearLoggedUser();
        window.location.href = '../index.html';
    });

    const urlParams = new URLSearchParams(window.location.search);
    const medicamentoId = urlParams.get('medicamentoId');

    if (!medicamentoId) {
        mostrarToast('Medicamento não informado.', 'erro');
        return;
    }

    let medicamento = null;

    const nomeRemedio = document.getElementById('nome-remedio');
    const tipoRemedio = document.getElementById('tipo-remedio');
    const detalhesRemedio = document.getElementById('detalhes-remedio');
    const containerRemedio = document.getElementById('container-remedio');
    const qtdAtual = document.getElementById('qtd-atual');
    const statusEstoque = document.getElementById('status-estoque');
    const infoMedicamento = document.querySelector('.remedio-detalhes .info-card');
    const antibioticNotice = document.getElementById('antibiotic-notice');
    const antibioticTreatmentInfo = document.getElementById('antibiotic-treatment-info');
    const horariosAtuais = document.getElementById('horarios-atuais');
    const inputHorarios = document.getElementById('input-horarios');
    const inputMinimo = document.getElementById('input-minimo');
    const scheduleEditor = document.getElementById('schedule-editor');
    const btnEditarHorarios = document.getElementById('btn-editar-horarios');
    const btnSalvarHorarios = document.getElementById('btn-salvar-horarios');
    const btnCancelarHorarios = document.getElementById('btn-cancelar-horarios');
    const btnAdd = document.getElementById('btn-add-estoque');
    const inputQtd = document.getElementById('input-qtd');

    function medicamentoEhAntibiotico() {
        return typeof medicamento.antibiotico === 'boolean'
            ? medicamento.antibiotico
            : ehAntibiotico(medicamento.categoria);
    }

    function formatarData(dataISO) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(String(dataISO ?? ''))) return 'data não informada';
        const [ano, mes, dia] = dataISO.split('-');
        return `${dia}/${mes}/${ano}`;
    }

    function atualizarStatusUI() {
        const status = classificarEstoque(
            medicamento.quantidadeAtual,
            medicamento.quantidadeMinima,
            medicamentoEhAntibiotico()
        );
        const classesStatus = ['stock-gray', 'stock-red', 'stock-yellow', 'stock-green', 'stock-blue'];

        statusEstoque.innerText = status.rotulo;
        statusEstoque.classList.remove(...classesStatus);
        statusEstoque.classList.add(`stock-${status.cor}`);
        containerRemedio.classList.remove(...classesStatus);
        containerRemedio.classList.add(`stock-${status.cor}`);
        infoMedicamento.classList.remove(...classesStatus);
        infoMedicamento.classList.add(`stock-${status.cor}`);
    }

    function renderMedicamento() {
        nomeRemedio.innerText = medicamento.nome;
        tipoRemedio.innerText = medicamento.tipoUso;
        tipoRemedio.className = `tag ${medicamento.tipoUso === 'Programado' ? 'tag-yellow' : 'tag-green'}`;
        detalhesRemedio.innerText = `${medicamento.categoria} • ${medicamento.dosagem} • Idoso: ${medicamento.nomeIdoso}`;
        containerRemedio.innerText = `#${medicamento.containerNumero}`;
        qtdAtual.innerText = medicamento.quantidadeAtual;
        horariosAtuais.innerHTML = `<i class="fa-regular fa-clock"></i> ${escapeHTML(medicamento.horario)}`;
        inputHorarios.value = medicamento.horario;
        inputMinimo.value = medicamento.quantidadeMinima;
        if (medicamentoEhAntibiotico()) {
            antibioticTreatmentInfo.innerText = `Duração de ${medicamento.duracaoTratamentoDias || 5} dias. Exclusão automática prevista para ${formatarData(medicamento.dataExclusao)}.`;
            antibioticNotice.style.display = 'flex';
        } else {
            antibioticNotice.style.display = 'none';
        }
        atualizarStatusUI();
    }

    async function carregarMedicamento() {
        try {
            medicamento = await buscarMedicamentoBackend(medicamentoId);
            renderMedicamento();
        } catch (erro) {
            mostrarToast('Erro ao carregar medicamento do backend.', 'erro');
        }
    }

    btnEditarHorarios.addEventListener('click', () => {
        scheduleEditor.style.display = 'block';
        inputHorarios.focus();
    });

    btnCancelarHorarios.addEventListener('click', () => {
        scheduleEditor.style.display = 'none';
        renderMedicamento();
    });

    btnSalvarHorarios.addEventListener('click', async () => {
        const novoHorario = inputHorarios.value.trim();
        const novoMinimo = Number(inputMinimo.value || 5);

        if (!novoHorario) {
            mostrarToast('Informe pelo menos um horário.', 'erro');
            return;
        }

        try {
            await salvarMedicamentoBackend({
                ...medicamento,
                horario: novoHorario,
                quantidadeMinima: novoMinimo,
                quantidadeAtual: medicamento.quantidadeAtual,
                idosoId: medicamento.idosoId || 0
            }, medicamento.id);
            await carregarMedicamento();
            scheduleEditor.style.display = 'none';
            mostrarToast('Horários e mínimo atualizados no banco.');
        } catch (erro) {
            mostrarToast('Erro ao atualizar horários.', 'erro');
        }
    });

    btnAdd.addEventListener('click', async () => {
        const valorAdicional = Number(inputQtd.value);
        if (valorAdicional <= 0) {
            mostrarToast('Insira uma quantidade válida.', 'erro');
            return;
        }

        const novoTotal = Number(medicamento.quantidadeAtual || 0) + valorAdicional;

        try {
            medicamento = await atualizarEstoqueBackend(medicamento.id, novoTotal, medicamento.quantidadeMinima);
            renderMedicamento();
            inputQtd.value = '';
            mostrarToast(`${valorAdicional} unidades adicionadas ao estoque.`);
        } catch (erro) {
            mostrarToast('Erro ao atualizar estoque no banco.', 'erro');
        }
    });

    const farmaciasMock = [
        { nome: 'Ultrafarma', preco: 10.99 },
        { nome: 'Drogasil', preco: 12.50 },
        { nome: 'Droga Raia', preco: 13.20 },
        { nome: 'Pague Menos', preco: 14.90 }
    ];

    farmaciasMock.sort((a, b) => a.preco - b.preco);
    document.getElementById('lista-farmacias').innerHTML = farmaciasMock.map(f => `
        <div class="pharmacy-item">
            <span class="pharmacy-name"><i class="fa-solid fa-store"></i> ${f.nome}</span>
            <span class="pharmacy-price">R$ ${f.preco.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
        </div>
    `).join('');

    await carregarMedicamento();
});
