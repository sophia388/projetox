const API_URL = 'http://localhost:8080';

function ehAntibiotico(categoria) {
    return String(categoria ?? '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .includes('antibiotico');
}

function classificarEstoque(quantidadeAtual, quantidadeMinima, referenciaAntibiotico = false) {
    const atualInformado = Number(quantidadeAtual);
    const minimoInformado = Number(quantidadeMinima);
    const atual = Number.isFinite(atualInformado) ? Math.max(0, atualInformado) : 0;
    const minimo = Number.isFinite(minimoInformado) && minimoInformado > 0 ? minimoInformado : 5;

    if (atual === 0) return { cor: 'gray', rotulo: 'Acabou' };
    if (atual <= minimo) return { cor: 'red', rotulo: 'Acabando' };
    if (atual <= minimo * 2) return { cor: 'yellow', rotulo: 'Médio' };
    const antibiotico = typeof referenciaAntibiotico === 'boolean'
        ? referenciaAntibiotico
        : ehAntibiotico(referenciaAntibiotico);
    return antibiotico
        ? { cor: 'blue', rotulo: 'Cheio (antibiótico)' }
        : { cor: 'green', rotulo: 'Suficiente' };
}

const fallbackUsers = [
    {
        id: 1,
        nome: 'Carlos Almeida',
        idade: 40,
        usuario: 'admin.oldfly',
        email: 'admin@oldfly.com',
        perfil: 'admin',
        descricao: 'Administrador geral do sistema',
        acesso: 'Acessa usuários, remédios, receitas e estoque'
    },
    {
        id: 2,
        nome: 'Ana Cuidadora',
        idade: 32,
        usuario: 'cuidador.ana',
        email: 'ana@oldfly.com',
        perfil: 'cuidador',
        descricao: 'Responsável pelo acompanhamento do idoso',
        acesso: 'Pode acompanhar remédios, receitas e estoque',
        idosoId: 3,
        nomeIdoso: 'João Silva'
    },
    {
        id: 3,
        nome: 'João Silva',
        idade: 67,
        usuario: 'idoso.joao',
        email: 'joao@oldfly.com',
        perfil: 'idoso',
        descricao: 'Usuário principal do dispenser',
        acesso: 'Pode visualizar seus próprios remédios e receitas'
    }
];

async function requestBackend(rota, opcoes = {}) {
    const resposta = await fetch(`${API_URL}${rota}`, {
        headers: {
            'Content-Type': 'application/json',
            ...(opcoes.headers || {})
        },
        ...opcoes
    });

    if (!resposta.ok) {
        throw new Error('Erro na comunicação com o backend');
    }

    if (resposta.status === 204) {
        return null;
    }

    const texto = await resposta.text();
    return texto ? JSON.parse(texto) : null;
}

async function loginBackend(usuario, senha) {
    const resposta = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ usuario, senha })
    });

    if (!resposta.ok) return null;
    return resposta.json();
}

async function buscarUsuariosBackend() {
    return requestBackend('/auth/usuarios');
}

function rotaUsuario(perfil) {
    const rotas = {
        admin: '/admin',
        cuidador: '/cuidador',
        idoso: '/idoso'
    };

    return rotas[perfil];
}

function montarCorpoUsuario(dados) {
    const corpo = {
        nome: dados.nome,
        idade: Number(dados.idade),
        usuario: dados.usuario,
        email: dados.email,
        senha: dados.senha || ''
    };

    if (dados.perfil === 'idoso') {
        corpo.adminId = Number(dados.adminId || 0);
    }

    if (dados.perfil === 'cuidador') {
        corpo.adminId = Number(dados.adminId || 0);
        corpo.idosoId = Number(dados.idosoId || 0);
    }

    return corpo;
}

async function cadastrarUsuarioBackend(dados) {
    const rota = rotaUsuario(dados.perfil);
    if (!rota) throw new Error('Tipo de usuário inválido');

    return requestBackend(rota, {
        method: 'POST',
        body: JSON.stringify(montarCorpoUsuario(dados))
    });
}

async function atualizarUsuarioBackend(id, perfil, dados) {
    const rota = rotaUsuario(perfil);
    if (!rota) throw new Error('Tipo de usuário inválido');

    return requestBackend(`${rota}/${id}`, {
        method: 'PUT',
        body: JSON.stringify(montarCorpoUsuario({ ...dados, perfil }))
    });
}

async function excluirUsuarioBackend(id, perfil) {
    const rota = rotaUsuario(perfil);
    if (!rota) throw new Error('Tipo de usuário inválido');

    return requestBackend(`${rota}/${id}`, { method: 'DELETE' });
}

async function buscarMedicamentosBackend() {
    return requestBackend('/medicamentos');
}

async function buscarMedicamentoBackend(id) {
    return requestBackend(`/medicamentos/${id}`);
}

async function salvarMedicamentoBackend(dados, id = null) {
    const antibiotico = typeof dados.antibiotico === 'boolean'
        ? dados.antibiotico
        : ehAntibiotico(dados.categoria);
    const statusEstoque = classificarEstoque(
        dados.quantidadeAtual,
        dados.quantidadeMinima,
        antibiotico
    );
    const corpo = {
        nome: dados.nome,
        dosagem: dados.dosagem,
        categoria: dados.categoria,
        horario: dados.horario,
        tipoUso: dados.tipoUso,
        containerNumero: Number(dados.containerNumero || 1),
        cor: statusEstoque.cor,
        idosoId: Number(dados.idosoId || 0),
        quantidadeAtual: Number(dados.quantidadeAtual || 0),
        quantidadeMinima: Number(dados.quantidadeMinima || 5),
        antibiotico,
        dataInicioTratamento: antibiotico ? (dados.dataInicioTratamento || null) : null,
        duracaoTratamentoDias: antibiotico ? Number(dados.duracaoTratamentoDias || 5) : null
    };

    return requestBackend(id ? `/medicamentos/${id}` : '/medicamentos', {
        method: id ? 'PUT' : 'POST',
        body: JSON.stringify(corpo)
    });
}

async function excluirMedicamentoBackend(id) {
    return requestBackend(`/medicamentos/${id}`, { method: 'DELETE' });
}

async function atualizarEstoqueBackend(id, quantidadeAtual, quantidadeMinima) {
    return requestBackend(`/estoque/medicamento/${id}`, {
        method: 'PUT',
        body: JSON.stringify({
            quantidadeAtual: Number(quantidadeAtual),
            quantidadeMinima: Number(quantidadeMinima)
        })
    });
}

async function buscarReceitasBackend() {
    return requestBackend('/receitas');
}

async function salvarReceitaBackend(dados, id = null) {
    const corpo = {
        medico: dados.medico,
        dataReceita: dados.dataReceita,
        medicamentos: dados.medicamentos,
        observacoes: dados.observacoes,
        arquivoNome: dados.arquivoNome,
        idosoId: Number(dados.idosoId || 0)
    };

    return requestBackend(id ? `/receitas/${id}` : '/receitas', {
        method: id ? 'PUT' : 'POST',
        body: JSON.stringify(corpo)
    });
}

async function excluirReceitaBackend(id) {
    return requestBackend(`/receitas/${id}`, { method: 'DELETE' });
}

function getLoggedUser() {
    const dados = localStorage.getItem('oldfly_logged_user');
    if (!dados) return null;

    try {
        return JSON.parse(dados);
    } catch (erro) {
        clearLoggedUser();
        return null;
    }
}

function setLoggedUser(user) {
    localStorage.setItem('oldfly_logged_user', JSON.stringify(user));
}

function clearLoggedUser() {
    localStorage.removeItem('oldfly_logged_user');
    localStorage.removeItem('oldfly_viewing_user');
}

function getViewingUser() {
    const loggedUser = getLoggedUser();
    if (!loggedUser) return null;

    if (loggedUser.perfil !== 'admin') return loggedUser;

    const dados = localStorage.getItem('oldfly_viewing_user');
    if (!dados) return loggedUser;

    try {
        return JSON.parse(dados);
    } catch (erro) {
        return loggedUser;
    }
}

function setViewingUser(user) {
    localStorage.setItem('oldfly_viewing_user', JSON.stringify(user));
}

function roleLabel(role) {
    const labels = {
        admin: 'Administrador',
        cuidador: 'Cuidador',
        idoso: 'Idoso'
    };

    return labels[role] || role;
}
