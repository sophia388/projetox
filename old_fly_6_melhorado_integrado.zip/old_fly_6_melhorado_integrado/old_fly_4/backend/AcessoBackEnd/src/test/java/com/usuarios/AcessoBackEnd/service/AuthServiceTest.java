package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.dto.LoginDTO;
import com.usuarios.AcessoBackEnd.dto.UsuarioSistemaDTO;
import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.AdminRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioCuidadorRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private AdminRepository adminRepository;

    @Mock
    private UsuarioCuidadorRepository cuidadorRepository;

    @Mock
    private UsuarioIdosoRepository idosoRepository;

    @InjectMocks
    private AuthService service;

    @Test
    void loginDoCuidadorRetornaIdosoVinculado() {
        UsuarioIdoso idoso = new UsuarioIdoso();
        idoso.setId(42);
        idoso.setNome("Maria da Silva");

        UsuarioCuidador cuidador = new UsuarioCuidador();
        cuidador.setId(7);
        cuidador.setNome("Ana Cuidadora");
        cuidador.setUsuario("ana");
        cuidador.setEmail("ana@example.com");
        cuidador.setIdoso(idoso);

        LoginDTO login = new LoginDTO();
        login.setUsuario("ana");
        login.setSenha("segredo");

        when(adminRepository.findByUsuarioAndSenha("ana", "segredo")).thenReturn(Optional.empty());
        when(cuidadorRepository.findByUsuarioAndSenha("ana", "segredo")).thenReturn(Optional.of(cuidador));

        UsuarioSistemaDTO resposta = service.login(login);

        assertEquals(42, resposta.getIdosoId());
        assertEquals("Maria da Silva", resposta.getNomeIdoso());
    }
}
