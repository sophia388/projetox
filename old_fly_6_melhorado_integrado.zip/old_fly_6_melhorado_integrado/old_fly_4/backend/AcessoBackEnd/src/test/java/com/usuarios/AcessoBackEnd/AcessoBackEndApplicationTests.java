package com.usuarios.AcessoBackEnd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = "oldfly.medicamentos.expiracao.enabled=false")
class AcessoBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
