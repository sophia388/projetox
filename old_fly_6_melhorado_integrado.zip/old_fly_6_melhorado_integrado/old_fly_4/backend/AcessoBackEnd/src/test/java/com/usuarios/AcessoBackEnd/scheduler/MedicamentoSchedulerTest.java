package com.usuarios.AcessoBackEnd.scheduler;

import com.usuarios.AcessoBackEnd.entity.Medicamento;
import com.usuarios.AcessoBackEnd.repository.MedicamentoRepository;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class MedicamentoSchedulerTest {

    @Test
    @SuppressWarnings("unchecked")
    void excluiVencidosEInicializaConfiguracaoLegada() {
        MedicamentoRepository repository = mock(MedicamentoRepository.class);
        MedicamentoScheduler scheduler = new MedicamentoScheduler(repository);
        LocalDate hoje = LocalDate.now(ZoneId.of("America/Sao_Paulo"));

        Medicamento expirado = antibiotico(true, hoje.minusDays(5), 5, "Antibiótico");
        Medicamento vigente = antibiotico(true, hoje.minusDays(4), 5, "Antibiótico");
        Medicamento legado = antibiotico(null, null, null, "ANTIBIOTICO");
        Medicamento comumLegado = antibiotico(null, null, null, "Cardiovascular");
        when(repository.findAll()).thenReturn(List.of(expirado, vigente, legado, comumLegado));

        scheduler.verificarMedicamentos();

        ArgumentCaptor<Iterable<Medicamento>> removidos = ArgumentCaptor.forClass(Iterable.class);
        verify(repository).deleteAll(removidos.capture());
        assertEquals(List.of(expirado), removidos.getValue());

        ArgumentCaptor<Iterable<Medicamento>> atualizados = ArgumentCaptor.forClass(Iterable.class);
        verify(repository).saveAll(atualizados.capture());
        List<Medicamento> listaAtualizados = (List<Medicamento>) atualizados.getValue();
        assertTrue(listaAtualizados.contains(legado));
        assertTrue(listaAtualizados.contains(comumLegado));
        assertTrue(legado.isAntibiotico());
        assertEquals(hoje, legado.getDataInicioTratamento());
        assertEquals(5, legado.getDuracaoTratamentoDias());
        assertFalse(comumLegado.isAntibiotico());
    }

    private Medicamento antibiotico(Boolean antibiotico, LocalDate inicio, Integer duracao, String categoria) {
        Medicamento medicamento = new Medicamento();
        medicamento.setAntibiotico(antibiotico);
        medicamento.setDataInicioTratamento(inicio);
        medicamento.setDuracaoTratamentoDias(duracao);
        medicamento.setCategoria(categoria);
        return medicamento;
    }
}
