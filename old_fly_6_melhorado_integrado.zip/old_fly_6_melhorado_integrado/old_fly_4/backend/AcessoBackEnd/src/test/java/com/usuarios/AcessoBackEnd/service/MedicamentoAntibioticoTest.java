package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.dto.MedicamentoDTO;
import com.usuarios.AcessoBackEnd.dto.MedicamentoResponseDTO;
import com.usuarios.AcessoBackEnd.entity.Medicamento;
import com.usuarios.AcessoBackEnd.repository.MedicamentoRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MedicamentoAntibioticoTest {

    @Mock
    private MedicamentoRepository repository;

    @Mock
    private UsuarioIdosoRepository idosoRepository;

    @InjectMocks
    private MedicamentoService service;

    @Test
    void cadastraAntibioticoAzulComExclusaoEmSeteDias() {
        when(repository.save(any(Medicamento.class))).thenAnswer(invocacao -> invocacao.getArgument(0));

        MedicamentoDTO dto = new MedicamentoDTO();
        dto.setNome("Amoxicilina");
        dto.setDosagem("500mg");
        dto.setCategoria("Antibiótico");
        dto.setHorario("08:00");
        dto.setTipoUso("Programado");
        dto.setContainerNumero(1);
        dto.setQuantidadeAtual(11);
        dto.setQuantidadeMinima(5);
        dto.setAntibiotico(true);
        dto.setDataInicioTratamento(LocalDate.of(2026, 8, 17));
        dto.setDuracaoTratamentoDias(7);

        MedicamentoResponseDTO resposta = service.cadastrar(dto);

        assertTrue(resposta.isAntibiotico());
        assertEquals("blue", resposta.getCor());
        assertEquals(7, resposta.getDuracaoTratamentoDias());
        assertEquals(LocalDate.of(2026, 8, 24), resposta.getDataExclusao());
    }
}
