package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.dto.MedicamentoDTO;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class MedicamentoServiceTest {

    @Test
    void classificaCorPelosLimitesDoEstoque() {
        assertEquals("gray", MedicamentoService.classificarCorEstoque(-1, 5));
        assertEquals("gray", MedicamentoService.classificarCorEstoque(0, 5));
        assertEquals("red", MedicamentoService.classificarCorEstoque(1, 5));
        assertEquals("red", MedicamentoService.classificarCorEstoque(5, 5));
        assertEquals("yellow", MedicamentoService.classificarCorEstoque(6, 5));
        assertEquals("yellow", MedicamentoService.classificarCorEstoque(10, 5));
        assertEquals("green", MedicamentoService.classificarCorEstoque(11, 5));
    }

    @Test
    void usaMinimoPadraoQuandoValorForInvalido() {
        assertEquals("red", MedicamentoService.classificarCorEstoque(5, 0));
        assertEquals("yellow", MedicamentoService.classificarCorEstoque(10, -1));
        assertEquals("green", MedicamentoService.classificarCorEstoque(11, 0));
    }

    @Test
    void usaAzulSomenteQuandoAntibioticoEstiverCheio() {
        assertEquals("gray", MedicamentoService.classificarCorEstoque(0, 5, true));
        assertEquals("red", MedicamentoService.classificarCorEstoque(5, 5, true));
        assertEquals("yellow", MedicamentoService.classificarCorEstoque(10, 5, true));
        assertEquals("blue", MedicamentoService.classificarCorEstoque(11, 5, true));
        assertEquals("green", MedicamentoService.classificarCorEstoque(11, 5, false));
    }

    @Test
    void reconheceCategoriaAntibioticoComOuSemAcento() {
        assertEquals("blue", MedicamentoService.classificarCorEstoque(11, 5, "Antibiótico"));
        assertEquals("blue", MedicamentoService.classificarCorEstoque(11, 5, "ANTIBIOTICO"));
    }

    @Test
    void rejeitaDuracaoDeAntibioticoDiferenteDeCincoOuSeteDias() {
        MedicamentoDTO dto = new MedicamentoDTO();
        dto.setNome("Amoxicilina");
        dto.setDosagem("500mg");
        dto.setCategoria("Antibiótico");
        dto.setHorario("08:00");
        dto.setTipoUso("Programado");
        dto.setContainerNumero(1);
        dto.setAntibiotico(true);
        dto.setDuracaoTratamentoDias(6);

        MedicamentoService service = new MedicamentoService();

        assertThrows(IllegalArgumentException.class, () -> service.cadastrar(dto));
    }
}
