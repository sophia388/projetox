package com.usuarios.AcessoBackEnd.controller;

import com.usuarios.AcessoBackEnd.dto.UsuarioIdosoDTO;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.service.UsuarioIdosoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/idoso")
@CrossOrigin("*")
public class UsuarioIdosoController {

    @Autowired
    private UsuarioIdosoService service;

    @PostMapping
    public UsuarioIdoso cadastrar(@RequestBody UsuarioIdosoDTO dto) {
        return service.cadastrar(dto);
    }

    @GetMapping
    public List<UsuarioIdoso> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public UsuarioIdoso buscarPorId(@PathVariable int id) {
        return service.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public UsuarioIdoso atualizar(@PathVariable int id, @RequestBody UsuarioIdosoDTO dto) {
        return service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable int id) {
        service.remover(id);
    }
}
