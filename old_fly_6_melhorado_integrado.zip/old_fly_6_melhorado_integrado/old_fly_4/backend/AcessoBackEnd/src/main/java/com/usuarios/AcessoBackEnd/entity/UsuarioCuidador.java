package com.usuarios.AcessoBackEnd.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;

@Entity
@Table(name = "usuario_cuidador")
public class UsuarioCuidador {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String nome;
    private int idade;

    @Column(unique = true)
    private String usuario;

    @Column(unique = true)
    private String email;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String senha;

    @ManyToOne
    @JoinColumn(name = "idoso_id")
    private UsuarioIdoso idoso;

    @ManyToOne
    @JoinColumn(name = "admin_id")
    private Admin admin;

    public UsuarioCuidador() {
    }

    public UsuarioCuidador(String nome, int idade, String usuario, String email, String senha, UsuarioIdoso idoso, Admin admin) {
        this.nome = nome;
        this.idade = idade;
        this.usuario = usuario;
        this.email = email;
        this.senha = senha;
        this.idoso = idoso;
        this.admin = admin;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public int getIdade() { return idade; }
    public void setIdade(int idade) { this.idade = idade; }
    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
    public UsuarioIdoso getIdoso() { return idoso; }
    public void setIdoso(UsuarioIdoso idoso) { this.idoso = idoso; }
    public Admin getAdmin() { return admin; }
    public void setAdmin(Admin admin) { this.admin = admin; }
}
