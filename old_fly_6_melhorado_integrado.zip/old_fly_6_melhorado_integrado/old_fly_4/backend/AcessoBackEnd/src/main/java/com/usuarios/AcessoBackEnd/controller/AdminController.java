package com.usuarios.AcessoBackEnd.controller;

import com.usuarios.AcessoBackEnd.dto.AdminDTO;
import com.usuarios.AcessoBackEnd.entity.Admin;
import com.usuarios.AcessoBackEnd.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin")
@CrossOrigin("*")
public class AdminController {

    @Autowired
    private AdminService service;

    @PostMapping
    public Admin cadastrar(@RequestBody AdminDTO dto) {
        return service.cadastrar(dto);
    }

    @GetMapping
    public List<Admin> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Admin buscarPorId(@PathVariable int id) {
        return service.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public Admin atualizar(@PathVariable int id, @RequestBody AdminDTO dto) {
        return service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable int id) {
        service.remover(id);
    }
}
