package com.usuarios.AcessoBackEnd.repository;

import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UsuarioIdosoRepository extends JpaRepository<UsuarioIdoso, Integer> {
    Optional<UsuarioIdoso> findByUsuario(String usuario);
    Optional<UsuarioIdoso> findByUsuarioAndSenha(String usuario, String senha);
    List<UsuarioIdoso> findByAdminId(int adminId);
}
