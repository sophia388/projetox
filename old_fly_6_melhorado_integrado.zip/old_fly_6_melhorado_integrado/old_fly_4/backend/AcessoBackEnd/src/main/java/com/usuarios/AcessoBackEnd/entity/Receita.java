package com.usuarios.AcessoBackEnd.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "receita")
public class Receita {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String medico;
    private LocalDate dataReceita;
    private String medicamentos;
    private String observacoes;
    private String arquivoNome;

    @ManyToOne
    @JoinColumn(name = "idoso_id")
    private UsuarioIdoso idoso;

    public Receita() {
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getMedico() { return medico; }
    public void setMedico(String medico) { this.medico = medico; }
    public LocalDate getDataReceita() { return dataReceita; }
    public void setDataReceita(LocalDate dataReceita) { this.dataReceita = dataReceita; }
    public String getMedicamentos() { return medicamentos; }
    public void setMedicamentos(String medicamentos) { this.medicamentos = medicamentos; }
    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
    public String getArquivoNome() { return arquivoNome; }
    public void setArquivoNome(String arquivoNome) { this.arquivoNome = arquivoNome; }
    public UsuarioIdoso getIdoso() { return idoso; }
    public void setIdoso(UsuarioIdoso idoso) { this.idoso = idoso; }
}
