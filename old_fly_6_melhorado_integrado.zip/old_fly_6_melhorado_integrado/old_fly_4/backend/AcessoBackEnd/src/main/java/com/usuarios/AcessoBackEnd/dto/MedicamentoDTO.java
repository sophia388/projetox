package com.usuarios.AcessoBackEnd.dto;

import java.time.LocalDate;

public class MedicamentoDTO {
    private String nome;
    private String dosagem;
    private String categoria;
    private String horario;
    private String tipoUso;
    private int containerNumero;
    private String cor;
    private int idosoId;
    private int quantidadeAtual;
    private int quantidadeMinima;
    private Boolean antibiotico;
    private LocalDate dataInicioTratamento;
    private Integer duracaoTratamentoDias;

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getDosagem() { return dosagem; }
    public void setDosagem(String dosagem) { this.dosagem = dosagem; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public String getHorario() { return horario; }
    public void setHorario(String horario) { this.horario = horario; }
    public String getTipoUso() { return tipoUso; }
    public void setTipoUso(String tipoUso) { this.tipoUso = tipoUso; }
    public int getContainerNumero() { return containerNumero; }
    public void setContainerNumero(int containerNumero) { this.containerNumero = containerNumero; }
    public String getCor() { return cor; }
    public void setCor(String cor) { this.cor = cor; }
    public int getIdosoId() { return idosoId; }
    public void setIdosoId(int idosoId) { this.idosoId = idosoId; }
    public int getQuantidadeAtual() { return quantidadeAtual; }
    public void setQuantidadeAtual(int quantidadeAtual) { this.quantidadeAtual = quantidadeAtual; }
    public int getQuantidadeMinima() { return quantidadeMinima; }
    public void setQuantidadeMinima(int quantidadeMinima) { this.quantidadeMinima = quantidadeMinima; }
    public Boolean getAntibiotico() { return antibiotico; }
    public void setAntibiotico(Boolean antibiotico) { this.antibiotico = antibiotico; }
    public LocalDate getDataInicioTratamento() { return dataInicioTratamento; }
    public void setDataInicioTratamento(LocalDate dataInicioTratamento) { this.dataInicioTratamento = dataInicioTratamento; }
    public Integer getDuracaoTratamentoDias() { return duracaoTratamentoDias; }
    public void setDuracaoTratamentoDias(Integer duracaoTratamentoDias) { this.duracaoTratamentoDias = duracaoTratamentoDias; }
}
