package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.dto.LoginDTO;
import com.usuarios.AcessoBackEnd.dto.UsuarioSistemaDTO;
import com.usuarios.AcessoBackEnd.entity.Admin;
import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.AdminRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioCuidadorRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private UsuarioCuidadorRepository cuidadorRepository;

    @Autowired
    private UsuarioIdosoRepository idosoRepository;

    public UsuarioSistemaDTO login(LoginDTO dto) {
        Optional<Admin> admin = adminRepository.findByUsuarioAndSenha(dto.getUsuario(), dto.getSenha());
        if (admin.isPresent()) {
            return toDTO(admin.get());
        }

        Optional<UsuarioCuidador> cuidador = cuidadorRepository.findByUsuarioAndSenha(dto.getUsuario(), dto.getSenha());
        if (cuidador.isPresent()) {
            return toDTO(cuidador.get());
        }

        Optional<UsuarioIdoso> idoso = idosoRepository.findByUsuarioAndSenha(dto.getUsuario(), dto.getSenha());
        if (idoso.isPresent()) {
            return toDTO(idoso.get());
        }

        return null;
    }

    public List<UsuarioSistemaDTO> listarUsuarios() {
        List<UsuarioSistemaDTO> usuarios = new ArrayList<>();
        adminRepository.findAll().forEach(admin -> usuarios.add(toDTO(admin)));
        cuidadorRepository.findAll().forEach(cuidador -> usuarios.add(toDTO(cuidador)));
        idosoRepository.findAll().forEach(idoso -> usuarios.add(toDTO(idoso)));
        return usuarios;
    }

    private UsuarioSistemaDTO toDTO(Admin admin) {
        return new UsuarioSistemaDTO(
                admin.getId(),
                admin.getNome(),
                admin.getIdade(),
                admin.getUsuario(),
                admin.getEmail(),
                "admin",
                "Administrador geral do sistema",
                "Acessa usuários, remédios, receitas e estoque",
                null,
                null
        );
    }

    private UsuarioSistemaDTO toDTO(UsuarioCuidador cuidador) {
        Integer idosoId = cuidador.getIdoso() != null ? cuidador.getIdoso().getId() : null;
        String nomeIdoso = cuidador.getIdoso() != null ? cuidador.getIdoso().getNome() : null;

        return new UsuarioSistemaDTO(
                cuidador.getId(),
                cuidador.getNome(),
                cuidador.getIdade(),
                cuidador.getUsuario(),
                cuidador.getEmail(),
                "cuidador",
                "Responsável pelo acompanhamento do idoso",
                "Pode acompanhar remédios, receitas e estoque",
                idosoId,
                nomeIdoso
        );
    }

    private UsuarioSistemaDTO toDTO(UsuarioIdoso idoso) {
        return new UsuarioSistemaDTO(
                idoso.getId(),
                idoso.getNome(),
                idoso.getIdade(),
                idoso.getUsuario(),
                idoso.getEmail(),
                "idoso",
                "Usuário principal do dispenser",
                "Pode visualizar seus próprios remédios e receitas",
                null,
                null
        );
    }
}
