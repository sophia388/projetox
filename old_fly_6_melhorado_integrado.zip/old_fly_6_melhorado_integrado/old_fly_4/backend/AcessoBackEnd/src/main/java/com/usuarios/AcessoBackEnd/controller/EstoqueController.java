package com.usuarios.AcessoBackEnd.controller;

import com.usuarios.AcessoBackEnd.dto.EstoqueDTO;
import com.usuarios.AcessoBackEnd.dto.MedicamentoResponseDTO;
import com.usuarios.AcessoBackEnd.service.MedicamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/estoque")
@CrossOrigin("*")
public class EstoqueController {

    @Autowired
    private MedicamentoService medicamentoService;

    @GetMapping("/medicamento/{medicamentoId}")
    public MedicamentoResponseDTO buscarPorMedicamento(@PathVariable int medicamentoId) {
        return medicamentoService.buscarPorId(medicamentoId);
    }

    @PutMapping("/medicamento/{medicamentoId}")
    public MedicamentoResponseDTO atualizarPorMedicamento(@PathVariable int medicamentoId, @RequestBody EstoqueDTO dto) {
        return medicamentoService.atualizarEstoque(medicamentoId, dto);
    }
}
