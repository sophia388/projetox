package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.dto.AdminDTO;
import com.usuarios.AcessoBackEnd.entity.Admin;
import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.AdminRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioCuidadorRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminService {

    @Autowired
    private AdminRepository repository;

    @Autowired
    private UsuarioIdosoRepository idosoRepository;

    @Autowired
    private UsuarioCuidadorRepository cuidadorRepository;

    public Admin cadastrar(AdminDTO dto) {
        Admin admin = new Admin();
        preencher(admin, dto);
        return repository.save(admin);
    }

    public List<Admin> listar() {
        return repository.findAll();
    }

    public Admin buscarPorId(int id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Administrador não encontrado"));
    }

    public Admin atualizar(int id, AdminDTO dto) {
        Admin admin = buscarPorId(id);
        preencher(admin, dto);
        return repository.save(admin);
    }

    public void remover(int id) {
        Admin admin = buscarPorId(id);

        for (UsuarioIdoso idoso : idosoRepository.findByAdminId(id)) {
            idoso.setAdmin(null);
            idosoRepository.save(idoso);
        }

        for (UsuarioCuidador cuidador : cuidadorRepository.findByAdminId(id)) {
            cuidador.setAdmin(null);
            cuidadorRepository.save(cuidador);
        }

        repository.delete(admin);
    }

    private void preencher(Admin admin, AdminDTO dto) {
        admin.setNome(dto.getNome());
        admin.setIdade(dto.getIdade());
        admin.setUsuario(dto.getUsuario() == null || dto.getUsuario().isBlank() ? dto.getEmail() : dto.getUsuario());
        admin.setEmail(dto.getEmail());
        if (dto.getSenha() != null && !dto.getSenha().isBlank()) {
            admin.setSenha(dto.getSenha());
        }
    }
}
