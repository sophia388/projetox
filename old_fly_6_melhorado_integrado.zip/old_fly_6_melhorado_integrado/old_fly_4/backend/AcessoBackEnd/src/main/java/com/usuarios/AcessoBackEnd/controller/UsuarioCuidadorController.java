package com.usuarios.AcessoBackEnd.controller;

import com.usuarios.AcessoBackEnd.dto.UsuarioCuidadorDTO;
import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import com.usuarios.AcessoBackEnd.service.UsuarioCuidadorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cuidador")
@CrossOrigin("*")
public class UsuarioCuidadorController {

    @Autowired
    private UsuarioCuidadorService service;

    @PostMapping
    public UsuarioCuidador cadastrar(@RequestBody UsuarioCuidadorDTO dto) {
        return service.cadastrar(dto);
    }

    @GetMapping
    public List<UsuarioCuidador> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public UsuarioCuidador buscarPorId(@PathVariable int id) {
        return service.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public UsuarioCuidador atualizar(@PathVariable int id, @RequestBody UsuarioCuidadorDTO dto) {
        return service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable int id) {
        service.remover(id);
    }
}
