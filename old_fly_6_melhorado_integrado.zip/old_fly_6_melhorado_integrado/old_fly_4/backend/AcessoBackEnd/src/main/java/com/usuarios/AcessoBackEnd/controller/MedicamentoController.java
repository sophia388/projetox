package com.usuarios.AcessoBackEnd.controller;

import com.usuarios.AcessoBackEnd.dto.EstoqueDTO;
import com.usuarios.AcessoBackEnd.dto.MedicamentoDTO;
import com.usuarios.AcessoBackEnd.dto.MedicamentoResponseDTO;
import com.usuarios.AcessoBackEnd.service.MedicamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/medicamentos")
@CrossOrigin("*")
public class MedicamentoController {

    @Autowired
    private MedicamentoService service;

    @PostMapping
    public MedicamentoResponseDTO cadastrar(@RequestBody MedicamentoDTO dto) {
        return service.cadastrar(dto);
    }

    @GetMapping
    public List<MedicamentoResponseDTO> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public MedicamentoResponseDTO buscarPorId(@PathVariable int id) {
        return service.buscarPorId(id);
    }

    @GetMapping("/idoso/{idosoId}")
    public List<MedicamentoResponseDTO> listarPorIdoso(@PathVariable int idosoId) {
        return service.listarPorIdoso(idosoId);
    }

    @PutMapping("/{id}")
    public MedicamentoResponseDTO atualizar(@PathVariable int id, @RequestBody MedicamentoDTO dto) {
        return service.atualizar(id, dto);
    }

    @PutMapping("/{id}/estoque")
    public MedicamentoResponseDTO atualizarEstoque(@PathVariable int id, @RequestBody EstoqueDTO dto) {
        return service.atualizarEstoque(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable int id) {
        service.remover(id);
    }
}
