package com.usuarios.AcessoBackEnd.scheduler;

import com.usuarios.AcessoBackEnd.entity.Medicamento;
import com.usuarios.AcessoBackEnd.repository.MedicamentoRepository;
import com.usuarios.AcessoBackEnd.service.MedicamentoRegras;
import jakarta.transaction.Transactional;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

@Component
@ConditionalOnProperty(
        name = "oldfly.medicamentos.expiracao.enabled",
        havingValue = "true",
        matchIfMissing = true
)
public class MedicamentoScheduler {

    private static final ZoneId FUSO_HORARIO = ZoneId.of("America/Sao_Paulo");

    private final MedicamentoRepository repository;

    public MedicamentoScheduler(MedicamentoRepository repository) {
        this.repository = repository;
    }

    @Scheduled(
            initialDelayString = "${oldfly.medicamentos.expiracao.atraso-inicial-ms:1000}",
            fixedDelayString = "${oldfly.medicamentos.expiracao.intervalo-ms:60000}"
    )
    @Transactional
    public void verificarMedicamentos() {
        LocalDate hoje = LocalDate.now(FUSO_HORARIO);
        List<Medicamento> atualizados = new ArrayList<>();
        List<Medicamento> expirados = new ArrayList<>();

        for (Medicamento medicamento : repository.findAll()) {
            boolean alterado = false;
            if (medicamento.getAntibiotico() == null) {
                medicamento.setAntibiotico(MedicamentoRegras.ehAntibiotico(medicamento.getCategoria()));
                alterado = true;
            }
            if (!medicamento.isAntibiotico()) {
                if (alterado) atualizados.add(medicamento);
                continue;
            }

            if (medicamento.getDataInicioTratamento() == null) {
                medicamento.setDataInicioTratamento(hoje);
                alterado = true;
            }
            if (!MedicamentoRegras.duracaoPermitida(medicamento.getDuracaoTratamentoDias())) {
                medicamento.setDuracaoTratamentoDias(5);
                alterado = true;
            }

            LocalDate dataExclusao = MedicamentoRegras.calcularDataExclusao(
                    medicamento.getDataInicioTratamento(),
                    medicamento.getDuracaoTratamentoDias()
            );

            if (!dataExclusao.isAfter(hoje)) {
                expirados.add(medicamento);
            } else if (alterado) {
                atualizados.add(medicamento);
            }
        }

        if (!atualizados.isEmpty()) repository.saveAll(atualizados);
        if (!expirados.isEmpty()) repository.deleteAll(expirados);
    }
}
