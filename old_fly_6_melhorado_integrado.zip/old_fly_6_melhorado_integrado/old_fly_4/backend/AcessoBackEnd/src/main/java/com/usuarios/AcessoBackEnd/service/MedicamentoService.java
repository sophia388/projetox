package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.dto.EstoqueDTO;
import com.usuarios.AcessoBackEnd.dto.MedicamentoDTO;
import com.usuarios.AcessoBackEnd.dto.MedicamentoResponseDTO;
import com.usuarios.AcessoBackEnd.entity.Estoque;
import com.usuarios.AcessoBackEnd.entity.Medicamento;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.MedicamentoRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MedicamentoService {

    private static final ZoneId FUSO_HORARIO = ZoneId.of("America/Sao_Paulo");

    @Autowired
    private MedicamentoRepository repository;

    @Autowired
    private UsuarioIdosoRepository idosoRepository;

    public MedicamentoResponseDTO cadastrar(MedicamentoDTO dto) {
        Medicamento medicamento = new Medicamento();
        preencher(medicamento, dto);
        return toDTO(repository.save(medicamento));
    }

    public List<MedicamentoResponseDTO> listar() {
        return repository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<MedicamentoResponseDTO> listarPorIdoso(int idosoId) {
        return repository.findByIdosoId(idosoId).stream().map(this::toDTO).collect(Collectors.toList());
    }

    public Medicamento buscarEntidade(int id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Medicamento não encontrado"));
    }

    public MedicamentoResponseDTO buscarPorId(int id) {
        return toDTO(buscarEntidade(id));
    }

    public MedicamentoResponseDTO atualizar(int id, MedicamentoDTO dto) {
        Medicamento medicamento = buscarEntidade(id);
        preencher(medicamento, dto);
        return toDTO(repository.save(medicamento));
    }

    public MedicamentoResponseDTO atualizarEstoque(int id, EstoqueDTO dto) {
        Medicamento medicamento = buscarEntidade(id);
        Estoque estoque = medicamento.getEstoque();
        if (estoque == null) {
            estoque = new Estoque();
            medicamento.setEstoque(estoque);
        }
        int quantidadeAtual = Math.max(0, dto.getQuantidadeAtual());
        int quantidadeMinima = normalizarQuantidadeMinima(dto.getQuantidadeMinima());
        estoque.setQuantidadeAtual(quantidadeAtual);
        estoque.setQuantidadeMinima(quantidadeMinima);
        estoque.setDataAtualizacao(LocalDateTime.now());
        medicamento.setCor(MedicamentoRegras.classificarCorEstoque(
                quantidadeAtual, quantidadeMinima, medicamentoEhAntibiotico(medicamento)));
        return toDTO(repository.save(medicamento));
    }

    public void remover(int id) {
        repository.delete(buscarEntidade(id));
    }

    private void preencher(Medicamento medicamento, MedicamentoDTO dto) {
        UsuarioIdoso idoso = dto.getIdosoId() > 0 ? idosoRepository.findById(dto.getIdosoId()).orElse(null) : null;
        medicamento.setNome(dto.getNome());
        medicamento.setDosagem(dto.getDosagem());
        medicamento.setCategoria(dto.getCategoria());
        medicamento.setHorario(dto.getHorario());
        medicamento.setTipoUso(validarTipoUso(dto.getTipoUso()));
        medicamento.setContainerNumero(dto.getContainerNumero());
        medicamento.setIdoso(idoso);
        configurarTratamentoAntibiotico(medicamento, dto);

        Estoque estoque = medicamento.getEstoque();
        if (estoque == null) {
            estoque = new Estoque();
            medicamento.setEstoque(estoque);
        }
        int quantidadeAtual = Math.max(0, dto.getQuantidadeAtual());
        int quantidadeMinima = normalizarQuantidadeMinima(dto.getQuantidadeMinima());
        estoque.setQuantidadeAtual(quantidadeAtual);
        estoque.setQuantidadeMinima(quantidadeMinima);
        estoque.setDataAtualizacao(LocalDateTime.now());
        medicamento.setCor(MedicamentoRegras.classificarCorEstoque(
                quantidadeAtual, quantidadeMinima, medicamentoEhAntibiotico(medicamento)));
    }

    private MedicamentoResponseDTO toDTO(Medicamento medicamento) {
        Estoque estoque = medicamento.getEstoque();
        int quantidadeAtual = estoque != null ? Math.max(0, estoque.getQuantidadeAtual()) : 0;
        int quantidadeMinima = estoque != null ? normalizarQuantidadeMinima(estoque.getQuantidadeMinima()) : 5;
        LocalDateTime dataAtualizacao = estoque != null ? estoque.getDataAtualizacao() : null;
        Integer idosoId = medicamento.getIdoso() != null ? medicamento.getIdoso().getId() : null;
        String nomeIdoso = medicamento.getIdoso() != null ? medicamento.getIdoso().getNome() : "Sem vínculo";
        boolean antibiotico = medicamentoEhAntibiotico(medicamento);
        LocalDate dataInicioTratamento = antibiotico
                ? (medicamento.getDataInicioTratamento() != null
                    ? medicamento.getDataInicioTratamento()
                    : LocalDate.now(FUSO_HORARIO))
                : null;
        Integer duracaoTratamentoDias = antibiotico
                ? (MedicamentoRegras.duracaoPermitida(medicamento.getDuracaoTratamentoDias())
                    ? medicamento.getDuracaoTratamentoDias()
                    : 5)
                : null;
        LocalDate dataExclusao = antibiotico
                ? MedicamentoRegras.calcularDataExclusao(dataInicioTratamento, duracaoTratamentoDias)
                : null;

        return new MedicamentoResponseDTO(
                medicamento.getId(),
                medicamento.getNome(),
                medicamento.getDosagem(),
                medicamento.getCategoria(),
                medicamento.getHorario(),
                normalizarTipoUsoParaResposta(medicamento.getTipoUso()),
                medicamento.getContainerNumero(),
                MedicamentoRegras.classificarCorEstoque(
                        quantidadeAtual, quantidadeMinima, antibiotico),
                idosoId,
                nomeIdoso,
                quantidadeAtual,
                quantidadeMinima,
                dataAtualizacao,
                antibiotico,
                dataInicioTratamento,
                duracaoTratamentoDias,
                dataExclusao
        );
    }

    private int normalizarQuantidadeMinima(int quantidadeMinima) {
        return quantidadeMinima > 0 ? quantidadeMinima : 5;
    }

    static String classificarCorEstoque(int quantidadeAtual, int quantidadeMinima) {
        return MedicamentoRegras.classificarCorEstoque(quantidadeAtual, quantidadeMinima, null);
    }

    static String classificarCorEstoque(int quantidadeAtual, int quantidadeMinima, String categoria) {
        return MedicamentoRegras.classificarCorEstoque(quantidadeAtual, quantidadeMinima, categoria);
    }

    static String classificarCorEstoque(int quantidadeAtual, int quantidadeMinima, boolean antibiotico) {
        return MedicamentoRegras.classificarCorEstoque(quantidadeAtual, quantidadeMinima, antibiotico);
    }

    private String validarTipoUso(String tipoUso) {
        String tipo = tipoUso == null ? "" : tipoUso.trim();
        if ("Contínuo".equalsIgnoreCase(tipo) || "Continuo".equalsIgnoreCase(tipo)) return "Contínuo";
        if ("Programado".equalsIgnoreCase(tipo)) return "Programado";
        throw new IllegalArgumentException("Tipo de uso deve ser Contínuo ou Programado");
    }

    private String normalizarTipoUsoParaResposta(String tipoUso) {
        try {
            return validarTipoUso(tipoUso);
        } catch (IllegalArgumentException erro) {
            return "Programado";
        }
    }

    private void configurarTratamentoAntibiotico(Medicamento medicamento, MedicamentoDTO dto) {
        boolean antibiotico = dto.getAntibiotico() != null
                ? dto.getAntibiotico()
                : medicamentoEhAntibiotico(medicamento);
        medicamento.setAntibiotico(antibiotico);

        if (!antibiotico) {
            medicamento.setDataInicioTratamento(null);
            medicamento.setDuracaoTratamentoDias(null);
            return;
        }

        Integer duracaoInformada = dto.getDuracaoTratamentoDias();
        if (duracaoInformada != null && !MedicamentoRegras.duracaoPermitida(duracaoInformada)) {
            throw new IllegalArgumentException("A duração do antibiótico deve ser de 5 ou 7 dias");
        }

        LocalDate dataInicio = dto.getDataInicioTratamento();
        if (dataInicio != null) {
            medicamento.setDataInicioTratamento(dataInicio);
        } else if (medicamento.getDataInicioTratamento() == null) {
            medicamento.setDataInicioTratamento(LocalDate.now(FUSO_HORARIO));
        }

        if (duracaoInformada != null) {
            medicamento.setDuracaoTratamentoDias(duracaoInformada);
        } else if (!MedicamentoRegras.duracaoPermitida(medicamento.getDuracaoTratamentoDias())) {
            medicamento.setDuracaoTratamentoDias(5);
        }
    }

    private boolean medicamentoEhAntibiotico(Medicamento medicamento) {
        return medicamento.getAntibiotico() != null
                ? medicamento.isAntibiotico()
                : MedicamentoRegras.ehAntibiotico(medicamento.getCategoria());
    }
}
