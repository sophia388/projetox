package com.usuarios.AcessoBackEnd.dto;

import java.time.LocalDate;

public class ReceitaResponseDTO {
    private int id;
    private String medico;
    private LocalDate dataReceita;
    private String medicamentos;
    private String observacoes;
    private String arquivoNome;
    private Integer idosoId;
    private String nomeIdoso;

    public ReceitaResponseDTO(int id, String medico, LocalDate dataReceita, String medicamentos, String observacoes, String arquivoNome, Integer idosoId, String nomeIdoso) {
        this.id = id;
        this.medico = medico;
        this.dataReceita = dataReceita;
        this.medicamentos = medicamentos;
        this.observacoes = observacoes;
        this.arquivoNome = arquivoNome;
        this.idosoId = idosoId;
        this.nomeIdoso = nomeIdoso;
    }

    public int getId() { return id; }
    public String getMedico() { return medico; }
    public LocalDate getDataReceita() { return dataReceita; }
    public String getMedicamentos() { return medicamentos; }
    public String getObservacoes() { return observacoes; }
    public String getArquivoNome() { return arquivoNome; }
    public Integer getIdosoId() { return idosoId; }
    public String getNomeIdoso() { return nomeIdoso; }
}
