package com.usuarios.AcessoBackEnd.controller;

import com.usuarios.AcessoBackEnd.dto.LoginDTO;
import com.usuarios.AcessoBackEnd.dto.UsuarioSistemaDTO;
import com.usuarios.AcessoBackEnd.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/auth")
@CrossOrigin("*")
public class AuthController {

    @Autowired
    private AuthService service;

    @PostMapping("/login")
    public ResponseEntity<UsuarioSistemaDTO> login(@RequestBody LoginDTO dto) {
        UsuarioSistemaDTO usuario = service.login(dto);

        if (usuario == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        return ResponseEntity.ok(usuario);
    }

    @GetMapping("/usuarios")
    public List<UsuarioSistemaDTO> listarUsuarios() {
        return service.listarUsuarios();
    }
}
