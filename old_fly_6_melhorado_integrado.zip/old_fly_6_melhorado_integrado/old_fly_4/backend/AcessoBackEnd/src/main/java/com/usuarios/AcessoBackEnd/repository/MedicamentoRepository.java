package com.usuarios.AcessoBackEnd.repository;

import com.usuarios.AcessoBackEnd.entity.Medicamento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MedicamentoRepository extends JpaRepository<Medicamento, Integer> {
    List<Medicamento> findByIdosoId(int idosoId);
}
