package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.dto.UsuarioCuidadorDTO;
import com.usuarios.AcessoBackEnd.entity.Admin;
import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.AdminRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioCuidadorRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioCuidadorService {

    @Autowired
    private UsuarioCuidadorRepository repository;

    @Autowired
    private UsuarioIdosoRepository idosoRepository;

    @Autowired
    private AdminRepository adminRepository;

    public UsuarioCuidador cadastrar(UsuarioCuidadorDTO dto) {
        UsuarioCuidador cuidador = new UsuarioCuidador();
        preencher(cuidador, dto);
        return repository.save(cuidador);
    }

    public List<UsuarioCuidador> listar() {
        return repository.findAll();
    }

    public UsuarioCuidador buscarPorId(int id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Cuidador não encontrado"));
    }

    public UsuarioCuidador atualizar(int id, UsuarioCuidadorDTO dto) {
        UsuarioCuidador cuidador = buscarPorId(id);
        preencher(cuidador, dto);
        return repository.save(cuidador);
    }

    public void remover(int id) {
        repository.delete(buscarPorId(id));
    }

    private void preencher(UsuarioCuidador cuidador, UsuarioCuidadorDTO dto) {
        UsuarioIdoso idoso = dto.getIdosoId() > 0 ? idosoRepository.findById(dto.getIdosoId()).orElse(null) : null;
        Admin admin = dto.getAdminId() > 0 ? adminRepository.findById(dto.getAdminId()).orElse(null) : null;
        cuidador.setNome(dto.getNome());
        cuidador.setIdade(dto.getIdade());
        cuidador.setUsuario(dto.getUsuario() == null || dto.getUsuario().isBlank() ? dto.getEmail() : dto.getUsuario());
        cuidador.setEmail(dto.getEmail());
        if (dto.getSenha() != null && !dto.getSenha().isBlank()) {
            cuidador.setSenha(dto.getSenha());
        }
        cuidador.setIdoso(idoso);
        cuidador.setAdmin(admin);
    }
}
