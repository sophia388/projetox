package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.dto.UsuarioIdosoDTO;
import com.usuarios.AcessoBackEnd.entity.Admin;
import com.usuarios.AcessoBackEnd.entity.Medicamento;
import com.usuarios.AcessoBackEnd.entity.Receita;
import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.AdminRepository;
import com.usuarios.AcessoBackEnd.repository.MedicamentoRepository;
import com.usuarios.AcessoBackEnd.repository.ReceitaRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioCuidadorRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioIdosoService {

    @Autowired
    private UsuarioIdosoRepository repository;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private UsuarioCuidadorRepository cuidadorRepository;

    @Autowired
    private MedicamentoRepository medicamentoRepository;

    @Autowired
    private ReceitaRepository receitaRepository;

    public UsuarioIdoso cadastrar(UsuarioIdosoDTO dto) {
        UsuarioIdoso idoso = new UsuarioIdoso();
        preencher(idoso, dto);
        return repository.save(idoso);
    }

    public List<UsuarioIdoso> listar() {
        return repository.findAll();
    }

    public UsuarioIdoso buscarPorId(int id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Idoso não encontrado"));
    }

    public UsuarioIdoso atualizar(int id, UsuarioIdosoDTO dto) {
        UsuarioIdoso idoso = buscarPorId(id);
        preencher(idoso, dto);
        return repository.save(idoso);
    }

    public void remover(int id) {
        UsuarioIdoso idoso = buscarPorId(id);

        for (UsuarioCuidador cuidador : cuidadorRepository.findByIdosoId(id)) {
            cuidador.setIdoso(null);
            cuidadorRepository.save(cuidador);
        }

        for (Medicamento medicamento : medicamentoRepository.findByIdosoId(id)) {
            medicamento.setIdoso(null);
            medicamentoRepository.save(medicamento);
        }

        for (Receita receita : receitaRepository.findByIdosoId(id)) {
            receita.setIdoso(null);
            receitaRepository.save(receita);
        }

        repository.delete(idoso);
    }

    private void preencher(UsuarioIdoso idoso, UsuarioIdosoDTO dto) {
        Admin admin = dto.getAdminId() > 0 ? adminRepository.findById(dto.getAdminId()).orElse(null) : null;
        idoso.setNome(dto.getNome());
        idoso.setIdade(dto.getIdade());
        idoso.setUsuario(dto.getUsuario() == null || dto.getUsuario().isBlank() ? dto.getEmail() : dto.getUsuario());
        idoso.setEmail(dto.getEmail());
        if (dto.getSenha() != null && !dto.getSenha().isBlank()) {
            idoso.setSenha(dto.getSenha());
        }
        idoso.setAdmin(admin);
    }
}
