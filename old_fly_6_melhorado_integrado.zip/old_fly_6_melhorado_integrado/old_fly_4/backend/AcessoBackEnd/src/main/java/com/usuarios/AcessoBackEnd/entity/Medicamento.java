package com.usuarios.AcessoBackEnd.entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "medicamento")
public class Medicamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String nome;
    private String dosagem;
    private String categoria;
    private String horario;
    private String tipoUso;
    private int containerNumero;
    private String cor;
    private Boolean antibiotico;
    private LocalDate dataInicioTratamento;
    private Integer duracaoTratamentoDias;

    @ManyToOne
    @JoinColumn(name = "idoso_id")
    private UsuarioIdoso idoso;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "estoque_id")
    private Estoque estoque;

    public Medicamento() {
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getDosagem() { return dosagem; }
    public void setDosagem(String dosagem) { this.dosagem = dosagem; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public String getHorario() { return horario; }
    public void setHorario(String horario) { this.horario = horario; }
    public String getTipoUso() { return tipoUso; }
    public void setTipoUso(String tipoUso) { this.tipoUso = tipoUso; }
    public int getContainerNumero() { return containerNumero; }
    public void setContainerNumero(int containerNumero) { this.containerNumero = containerNumero; }
    public String getCor() { return cor; }
    public void setCor(String cor) { this.cor = cor; }
    public Boolean getAntibiotico() { return antibiotico; }
    public boolean isAntibiotico() { return Boolean.TRUE.equals(antibiotico); }
    public void setAntibiotico(Boolean antibiotico) { this.antibiotico = antibiotico; }
    public LocalDate getDataInicioTratamento() { return dataInicioTratamento; }
    public void setDataInicioTratamento(LocalDate dataInicioTratamento) { this.dataInicioTratamento = dataInicioTratamento; }
    public Integer getDuracaoTratamentoDias() { return duracaoTratamentoDias; }
    public void setDuracaoTratamentoDias(Integer duracaoTratamentoDias) { this.duracaoTratamentoDias = duracaoTratamentoDias; }
    public UsuarioIdoso getIdoso() { return idoso; }
    public void setIdoso(UsuarioIdoso idoso) { this.idoso = idoso; }
    public Estoque getEstoque() { return estoque; }
    public void setEstoque(Estoque estoque) { this.estoque = estoque; }
}
