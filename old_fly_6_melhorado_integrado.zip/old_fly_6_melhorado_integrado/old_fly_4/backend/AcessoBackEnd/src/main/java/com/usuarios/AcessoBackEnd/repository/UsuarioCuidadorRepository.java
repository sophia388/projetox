package com.usuarios.AcessoBackEnd.repository;

import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UsuarioCuidadorRepository extends JpaRepository<UsuarioCuidador, Integer> {
    Optional<UsuarioCuidador> findByUsuario(String usuario);
    Optional<UsuarioCuidador> findByUsuarioAndSenha(String usuario, String senha);
    List<UsuarioCuidador> findByIdosoId(int idosoId);
    List<UsuarioCuidador> findByAdminId(int adminId);
}
