package com.usuarios.AcessoBackEnd.repository;

import com.usuarios.AcessoBackEnd.entity.Estoque;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstoqueRepository extends JpaRepository<Estoque, Integer> {
}
