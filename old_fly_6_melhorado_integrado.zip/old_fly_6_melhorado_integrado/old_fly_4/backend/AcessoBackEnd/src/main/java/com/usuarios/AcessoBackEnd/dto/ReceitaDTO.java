package com.usuarios.AcessoBackEnd.dto;

public class ReceitaDTO {
    private String medico;
    private String dataReceita;
    private String medicamentos;
    private String observacoes;
    private String arquivoNome;
    private int idosoId;

    public String getMedico() { return medico; }
    public void setMedico(String medico) { this.medico = medico; }
    public String getDataReceita() { return dataReceita; }
    public void setDataReceita(String dataReceita) { this.dataReceita = dataReceita; }
    public String getMedicamentos() { return medicamentos; }
    public void setMedicamentos(String medicamentos) { this.medicamentos = medicamentos; }
    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
    public String getArquivoNome() { return arquivoNome; }
    public void setArquivoNome(String arquivoNome) { this.arquivoNome = arquivoNome; }
    public int getIdosoId() { return idosoId; }
    public void setIdosoId(int idosoId) { this.idosoId = idosoId; }
}
