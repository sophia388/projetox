package com.usuarios.AcessoBackEnd.service;

import com.usuarios.AcessoBackEnd.dto.ReceitaDTO;
import com.usuarios.AcessoBackEnd.dto.ReceitaResponseDTO;
import com.usuarios.AcessoBackEnd.entity.Receita;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.ReceitaRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReceitaService {

    @Autowired
    private ReceitaRepository repository;

    @Autowired
    private UsuarioIdosoRepository idosoRepository;

    public ReceitaResponseDTO cadastrar(ReceitaDTO dto) {
        Receita receita = new Receita();
        preencher(receita, dto);
        return toDTO(repository.save(receita));
    }

    public List<ReceitaResponseDTO> listar() {
        return repository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public ReceitaResponseDTO buscarPorId(int id) {
        return toDTO(buscarEntidade(id));
    }

    public ReceitaResponseDTO atualizar(int id, ReceitaDTO dto) {
        Receita receita = buscarEntidade(id);
        preencher(receita, dto);
        return toDTO(repository.save(receita));
    }

    public void remover(int id) {
        repository.delete(buscarEntidade(id));
    }

    private Receita buscarEntidade(int id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("Receita não encontrada"));
    }

    private void preencher(Receita receita, ReceitaDTO dto) {
        UsuarioIdoso idoso = dto.getIdosoId() > 0 ? idosoRepository.findById(dto.getIdosoId()).orElse(null) : null;
        receita.setMedico(dto.getMedico());
        receita.setMedicamentos(dto.getMedicamentos());
        receita.setObservacoes(dto.getObservacoes());
        receita.setArquivoNome(dto.getArquivoNome());
        receita.setIdoso(idoso);
        if (dto.getDataReceita() != null && !dto.getDataReceita().isBlank()) {
            receita.setDataReceita(LocalDate.parse(dto.getDataReceita()));
        }
    }

    private ReceitaResponseDTO toDTO(Receita receita) {
        Integer idosoId = receita.getIdoso() != null ? receita.getIdoso().getId() : null;
        String nomeIdoso = receita.getIdoso() != null ? receita.getIdoso().getNome() : "Sem vínculo";
        return new ReceitaResponseDTO(
                receita.getId(),
                receita.getMedico(),
                receita.getDataReceita(),
                receita.getMedicamentos(),
                receita.getObservacoes(),
                receita.getArquivoNome(),
                idosoId,
                nomeIdoso
        );
    }
}
