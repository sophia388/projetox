package com.usuarios.AcessoBackEnd.controller;

import com.usuarios.AcessoBackEnd.dto.ReceitaDTO;
import com.usuarios.AcessoBackEnd.dto.ReceitaResponseDTO;
import com.usuarios.AcessoBackEnd.service.ReceitaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/receitas")
@CrossOrigin("*")
public class ReceitaController {

    @Autowired
    private ReceitaService service;

    @PostMapping
    public ReceitaResponseDTO cadastrar(@RequestBody ReceitaDTO dto) {
        return service.cadastrar(dto);
    }

    @GetMapping
    public List<ReceitaResponseDTO> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public ReceitaResponseDTO buscarPorId(@PathVariable int id) {
        return service.buscarPorId(id);
    }

    @PutMapping("/{id}")
    public ReceitaResponseDTO atualizar(@PathVariable int id, @RequestBody ReceitaDTO dto) {
        return service.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void remover(@PathVariable int id) {
        service.remover(id);
    }
}
