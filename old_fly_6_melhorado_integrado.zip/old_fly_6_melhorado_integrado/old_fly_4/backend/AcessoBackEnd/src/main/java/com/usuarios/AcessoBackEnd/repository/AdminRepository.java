package com.usuarios.AcessoBackEnd.repository;

import com.usuarios.AcessoBackEnd.entity.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AdminRepository extends JpaRepository<Admin, Integer> {
    Optional<Admin> findByUsuario(String usuario);
    Optional<Admin> findByUsuarioAndSenha(String usuario, String senha);
}
