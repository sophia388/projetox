package com.usuarios.AcessoBackEnd.config;

import com.usuarios.AcessoBackEnd.entity.Admin;
import com.usuarios.AcessoBackEnd.entity.Estoque;
import com.usuarios.AcessoBackEnd.entity.Medicamento;
import com.usuarios.AcessoBackEnd.entity.Receita;
import com.usuarios.AcessoBackEnd.entity.UsuarioCuidador;
import com.usuarios.AcessoBackEnd.entity.UsuarioIdoso;
import com.usuarios.AcessoBackEnd.repository.AdminRepository;
import com.usuarios.AcessoBackEnd.repository.MedicamentoRepository;
import com.usuarios.AcessoBackEnd.repository.ReceitaRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioCuidadorRepository;
import com.usuarios.AcessoBackEnd.repository.UsuarioIdosoRepository;
import com.usuarios.AcessoBackEnd.service.MedicamentoRegras;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Component
public class DadosIniciais implements CommandLineRunner {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private UsuarioIdosoRepository idosoRepository;

    @Autowired
    private UsuarioCuidadorRepository cuidadorRepository;

    @Autowired
    private MedicamentoRepository medicamentoRepository;

    @Autowired
    private ReceitaRepository receitaRepository;

    @Override
    public void run(String... args) {
        Admin admin = adminRepository.findByUsuario("admin.oldfly").orElseGet(() -> {
            Admin novoAdmin = new Admin();
            novoAdmin.setNome("Carlos Almeida");
            novoAdmin.setIdade(40);
            novoAdmin.setUsuario("admin.oldfly");
            novoAdmin.setEmail("admin@oldfly.com");
            novoAdmin.setSenha("admin123");
            return adminRepository.save(novoAdmin);
        });

        UsuarioIdoso idoso = idosoRepository.findByUsuario("idoso.joao").orElseGet(() -> {
            UsuarioIdoso novoIdoso = new UsuarioIdoso();
            novoIdoso.setNome("João Silva");
            novoIdoso.setIdade(67);
            novoIdoso.setUsuario("idoso.joao");
            novoIdoso.setEmail("joao@oldfly.com");
            novoIdoso.setSenha("joao123");
            novoIdoso.setAdmin(admin);
            return idosoRepository.save(novoIdoso);
        });

        cuidadorRepository.findByUsuario("cuidador.ana").orElseGet(() -> {
            UsuarioCuidador novoCuidador = new UsuarioCuidador();
            novoCuidador.setNome("Ana Cuidadora");
            novoCuidador.setIdade(32);
            novoCuidador.setUsuario("cuidador.ana");
            novoCuidador.setEmail("ana@oldfly.com");
            novoCuidador.setSenha("cuidado123");
            novoCuidador.setIdoso(idoso);
            novoCuidador.setAdmin(admin);
            return cuidadorRepository.save(novoCuidador);
        });

        if (medicamentoRepository.count() == 0) {
            criarMedicamento("Losartana", "50mg", "Cardiovascular", "08:00, 20:00", "Contínuo", 1, "red", 4, 10, idoso);
            criarMedicamento("Metformina", "500mg", "Diabetes", "07:00, 12:00, 18:00", "Contínuo", 2, "green", 18, 8, idoso);
            criarMedicamento("Vitamina D", "100mg", "Vitamina", "08:00", "Programado", 3, "green", 30, 5, idoso);
            criarMedicamento("Amoxicilina", "875mg", "Antibiótico", "08:00, 20:00", "Programado", 4, "blue", 18, 6, idoso);
        }

        if (receitaRepository.count() == 0) {
            Receita receita = new Receita();
            receita.setMedico("Dra. Helena Martins");
            receita.setDataReceita(LocalDate.now());
            receita.setMedicamentos("Losartana, Metformina");
            receita.setObservacoes("Receita inicial cadastrada para teste do sistema.");
            receita.setArquivoNome("receita_teste.jpg");
            receita.setIdoso(idoso);
            receitaRepository.save(receita);
        }
    }

    private void criarMedicamento(String nome, String dosagem, String categoria, String horario, String tipoUso, int containerNumero, String cor, int quantidadeAtual, int quantidadeMinima, UsuarioIdoso idoso) {
        Estoque estoque = new Estoque();
        estoque.setQuantidadeAtual(quantidadeAtual);
        estoque.setQuantidadeMinima(quantidadeMinima);
        estoque.setDataAtualizacao(LocalDateTime.now());

        Medicamento medicamento = new Medicamento();
        medicamento.setNome(nome);
        medicamento.setDosagem(dosagem);
        medicamento.setCategoria(categoria);
        medicamento.setHorario(horario);
        medicamento.setTipoUso(tipoUso);
        medicamento.setContainerNumero(containerNumero);
        medicamento.setCor(cor);
        medicamento.setIdoso(idoso);
        medicamento.setEstoque(estoque);
        boolean antibiotico = MedicamentoRegras.ehAntibiotico(categoria);
        medicamento.setAntibiotico(antibiotico);
        if (antibiotico) {
            medicamento.setDataInicioTratamento(LocalDate.now());
            medicamento.setDuracaoTratamentoDias(7);
        }

        medicamentoRepository.save(medicamento);
    }
}
