package com.usuarios.AcessoBackEnd.repository;

import com.usuarios.AcessoBackEnd.entity.Receita;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReceitaRepository extends JpaRepository<Receita, Integer> {
    List<Receita> findByIdosoId(int idosoId);
}
