package com.usuarios.AcessoBackEnd.service;

import java.text.Normalizer;
import java.time.LocalDate;
import java.util.Locale;

public final class MedicamentoRegras {

    private MedicamentoRegras() {
    }

    public static boolean ehAntibiotico(String categoria) {
        if (categoria == null || categoria.isBlank()) return false;

        String categoriaNormalizada = Normalizer.normalize(categoria, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT);
        return categoriaNormalizada.contains("antibiotico");
    }

    public static String classificarCorEstoque(int quantidadeAtual, int quantidadeMinima, String categoria) {
        return classificarCorEstoque(quantidadeAtual, quantidadeMinima, ehAntibiotico(categoria));
    }

    public static String classificarCorEstoque(int quantidadeAtual, int quantidadeMinima, boolean antibiotico) {
        int atual = Math.max(0, quantidadeAtual);
        int minimo = quantidadeMinima > 0 ? quantidadeMinima : 5;

        if (atual == 0) return "gray";
        if (atual <= minimo) return "red";
        if ((long) atual <= (long) minimo * 2) return "yellow";
        return antibiotico ? "blue" : "green";
    }

    public static boolean duracaoPermitida(Integer duracaoDias) {
        return duracaoDias != null && (duracaoDias == 5 || duracaoDias == 7);
    }

    public static LocalDate calcularDataExclusao(LocalDate dataInicio, int duracaoDias) {
        return dataInicio.plusDays(duracaoDias);
    }
}
