package com.usuarios.AcessoBackEnd.dto;

import java.time.LocalDateTime;
import java.time.LocalDate;

public class MedicamentoResponseDTO {
    private int id;
    private String nome;
    private String dosagem;
    private String categoria;
    private String horario;
    private String tipoUso;
    private int containerNumero;
    private String cor;
    private Integer idosoId;
    private String nomeIdoso;
    private int quantidadeAtual;
    private int quantidadeMinima;
    private LocalDateTime dataAtualizacao;
    private boolean antibiotico;
    private LocalDate dataInicioTratamento;
    private Integer duracaoTratamentoDias;
    private LocalDate dataExclusao;

    public MedicamentoResponseDTO(int id, String nome, String dosagem, String categoria, String horario,
                                  String tipoUso, int containerNumero, String cor, Integer idosoId,
                                  String nomeIdoso, int quantidadeAtual, int quantidadeMinima,
                                  LocalDateTime dataAtualizacao, boolean antibiotico,
                                  LocalDate dataInicioTratamento, Integer duracaoTratamentoDias,
                                  LocalDate dataExclusao) {
        this.id = id;
        this.nome = nome;
        this.dosagem = dosagem;
        this.categoria = categoria;
        this.horario = horario;
        this.tipoUso = tipoUso;
        this.containerNumero = containerNumero;
        this.cor = cor;
        this.idosoId = idosoId;
        this.nomeIdoso = nomeIdoso;
        this.quantidadeAtual = quantidadeAtual;
        this.quantidadeMinima = quantidadeMinima;
        this.dataAtualizacao = dataAtualizacao;
        this.antibiotico = antibiotico;
        this.dataInicioTratamento = dataInicioTratamento;
        this.duracaoTratamentoDias = duracaoTratamentoDias;
        this.dataExclusao = dataExclusao;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getDosagem() { return dosagem; }
    public String getCategoria() { return categoria; }
    public String getHorario() { return horario; }
    public String getTipoUso() { return tipoUso; }
    public int getContainerNumero() { return containerNumero; }
    public String getCor() { return cor; }
    public Integer getIdosoId() { return idosoId; }
    public String getNomeIdoso() { return nomeIdoso; }
    public int getQuantidadeAtual() { return quantidadeAtual; }
    public int getQuantidadeMinima() { return quantidadeMinima; }
    public LocalDateTime getDataAtualizacao() { return dataAtualizacao; }
    public boolean isAntibiotico() { return antibiotico; }
    public LocalDate getDataInicioTratamento() { return dataInicioTratamento; }
    public Integer getDuracaoTratamentoDias() { return duracaoTratamentoDias; }
    public LocalDate getDataExclusao() { return dataExclusao; }
}
