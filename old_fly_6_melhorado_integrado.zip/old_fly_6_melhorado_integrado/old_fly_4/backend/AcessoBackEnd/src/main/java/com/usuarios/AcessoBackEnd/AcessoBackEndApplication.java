package com.usuarios.AcessoBackEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class AcessoBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcessoBackEndApplication.class, args);
	}

}
