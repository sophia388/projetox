CREATE DATABASE IF NOT EXISTS sistema_usuarios;
USE sistema_usuarios;

-- O Spring Boot cria e atualiza as tabelas automaticamente com spring.jpa.hibernate.ddl-auto=update.
